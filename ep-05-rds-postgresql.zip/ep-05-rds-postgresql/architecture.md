# Episode 05 Architecture

Two stores, chosen per access pattern rather than per preference. The handler routes;
each repository owns exactly one of them.

```mermaid
flowchart LR
    C["curl"] --> G["API Gateway v2"]
    G --> L["Lambda: flocicart-api"]
    L -->|"/products"| RD["catalogDdb.mjs"]
    L -->|"/orders"| RP["ordersPg.mjs"]
    RD --> D[("DynamoDB<br/>flocicart-products")]
    RP --> P[("RDS PostgreSQL<br/>flocicart-pg / orders")]
```

DynamoDB is serverless and addressed by name. PostgreSQL is an instance with a host and
port that RDS assigns, so `deploy.sh` has to discover that address and inject it into the
function's environment.
