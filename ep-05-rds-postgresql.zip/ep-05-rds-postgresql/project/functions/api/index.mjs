// The FlociCart API Lambda, now talking to two very different stores.
//
// Products live in DynamoDB, orders live in PostgreSQL, and the handler cannot tell -
// that is the payoff of putting each store behind a repository.

import { createProduct, listProducts } from "../../src/repositories/catalogDdb.mjs";
import { initOrdersTable, createOrder, listOrders } from "../../src/repositories/ordersPg.mjs";
import { ValidationError } from "../../src/errors.mjs";

// Module scope survives between warm invocations, so the schema check runs once per
// container instead of once per request.
let ordersReady;

// DynamoDB tables are created by a script; a SQL schema is created by the app that owns
// it. Doing it lazily keeps the deploy order simple - no migration step to run first.
function ensureOrdersTable() {
  if (!ordersReady) {
    // Cache the promise, not the result: two concurrent requests then share one CREATE.
    ordersReady = initOrdersTable().catch((err) => {
      ordersReady = undefined; // let the next request retry instead of failing forever
      throw err;
    });
  }
  return ordersReady;
}

const json = (statusCode, payload) => ({
  statusCode,
  headers: { "content-type": "application/json" },
  body: JSON.stringify(payload)
});

const parseBody = (event) => {
  try {
    return JSON.parse(event?.body || "{}");
  } catch {
    throw new ValidationError("Request body must be valid JSON");
  }
};

export const handler = async (event) => {
  const method = event?.requestContext?.http?.method || "INVOKE";
  const path = event?.rawPath || "/";

  console.log("request", JSON.stringify({ method, path }));

  try {
    if (method === "GET" && path === "/health") {
      return json(200, { ok: true, service: "flocicart-api", now: new Date().toISOString() });
    }

    if (method === "POST" && path === "/products") {
      const product = await createProduct(parseBody(event));
      return json(201, { ok: true, product });
    }

    if (method === "GET" && path === "/products") {
      const items = await listProducts();
      return json(200, { items, count: items.length });
    }

    if (method === "POST" && path === "/orders") {
      await ensureOrdersTable();
      const order = await createOrder(parseBody(event));
      return json(201, { ok: true, order });
    }

    if (method === "GET" && path === "/orders") {
      await ensureOrdersTable();
      const items = await listOrders();
      return json(200, { items, count: items.length });
    }

    return json(404, { message: "Not Found", method, path });
  } catch (err) {
    if (err instanceof ValidationError) {
      return json(400, { message: err.message });
    }

    // A database that is unreachable is not the caller's fault and is usually temporary,
    // so it gets 503 and a hint, while everything else stays an opaque 500.
    if (["ECONNREFUSED", "ETIMEDOUT", "ENOTFOUND"].includes(err?.code)) {
      console.error("database unreachable", err.message);
      return json(503, { message: "Order storage is unavailable" });
    }

    console.error("unhandled", err);
    return json(500, { message: "Internal Server Error" });
  }
};
