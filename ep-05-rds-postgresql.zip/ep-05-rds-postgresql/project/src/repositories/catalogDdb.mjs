// Product catalog persistence, backed by DynamoDB.
//
// Keeping storage behind a repository means the handler never sees DynamoDB's attribute
// value format ({ S: "..." }) - and it is why this episode can add a second store without
// touching the routing code.

import { PutItemCommand, ScanCommand } from "@aws-sdk/client-dynamodb";
import { ddb } from "../config/awsClients.mjs";
import { CATALOG_TABLE } from "../config/resources.mjs";
import { ValidationError } from "../errors.mjs";

// DynamoDB rejects empty strings in a key and stores numbers as strings, so validate
// here rather than discovering it as a 500 at request time.
function validate({ productId, name, price }) {
  if (typeof productId !== "string" || productId.trim() === "") {
    throw new ValidationError("productId is required and must be a non-empty string");
  }
  if (typeof name !== "string" || name.trim() === "") {
    throw new ValidationError("name is required and must be a non-empty string");
  }
  if (typeof price !== "number" || !Number.isFinite(price) || price < 0) {
    throw new ValidationError("price is required and must be a non-negative number");
  }
  return { productId: productId.trim(), name: name.trim(), price };
}

export async function createProduct(input) {
  const product = validate(input);

  await ddb.send(
    new PutItemCommand({
      TableName: CATALOG_TABLE,
      // PutItem overwrites an existing item with the same key, which makes this an upsert.
      Item: {
        productId: { S: product.productId },
        name: { S: product.name },
        price: { N: String(product.price) }
      }
    })
  );

  return product;
}

export async function listProducts() {
  // Scan reads the whole table. Fine for a demo catalog, but on a real table you would
  // use Query against a key or an index - Scan cost grows with the data, not the result.
  const out = await ddb.send(new ScanCommand({ TableName: CATALOG_TABLE }));

  return (out.Items || []).map((item) => ({
    productId: item.productId?.S,
    name: item.name?.S,
    price: Number(item.price?.N)
  }));
}
