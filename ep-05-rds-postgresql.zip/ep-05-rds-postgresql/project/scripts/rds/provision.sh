#!/usr/bin/env bash
# Provisions the PostgreSQL instance that stores orders, and reports its address.
#
# Unlike DynamoDB, RDS is not serverless: you ask for an instance, wait for it to come up,
# and then connect over a normal Postgres socket. That wait is the whole point of this
# script - the address does not exist until the instance is available.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws

wait_for_floci

if floci_aws rds describe-db-instances --db-instance-identifier "$DB_INSTANCE_ID" >/dev/null 2>&1; then
  echo "DB instance ${DB_INSTANCE_ID} already exists."
else
  echo "Creating DB instance ${DB_INSTANCE_ID}..."
  floci_aws rds create-db-instance \
    --db-instance-identifier "$DB_INSTANCE_ID" \
    --db-instance-class db.t3.micro \
    --engine postgres \
    --master-username "$PGUSER" \
    --master-user-password "$PGPASSWORD" \
    --allocated-storage 20 >/dev/null
fi

echo "Waiting for ${DB_INSTANCE_ID} to become available..."
floci_aws rds wait db-instance-available --db-instance-identifier "$DB_INSTANCE_ID" 2>/dev/null || true

if ! discover_pg; then
  echo "Could not read the endpoint for ${DB_INSTANCE_ID}." >&2
  echo "Inspect it with: aws rds describe-db-instances --endpoint-url ${EP}" >&2
  exit 1
fi

save_state pg-host "$PG_ADDRESS"
save_state pg-port "$PG_PORT"

echo
echo "DB instance ready."
echo "PGHOST=$PG_ADDRESS"
echo "PGPORT=$PG_PORT"
echo
echo "deploy.sh injects these into the Lambda automatically - you only need to export"
echo "them yourself if you want to connect with psql from this machine."
