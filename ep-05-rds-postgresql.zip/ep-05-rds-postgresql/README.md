# Ep 05 - PostgreSQL Orders Layer

Difficulty: intermediate · Git tag: `ep-05-rds-postgresql` · Starts from: `ep-04-dynamodb`

## Where we left off

Episode 04 stored products in DynamoDB. Orders need something DynamoDB is bad at.

## What this episode adds

- An RDS PostgreSQL instance, provisioned and waited on properly
- An `orders` table created lazily by the app that owns the schema
- `POST /orders` and `GET /orders` alongside the existing product routes
- Duplicate-id and unreachable-database handling (400 and 503, not 500)

## DynamoDB or PostgreSQL?

| | DynamoDB (products) | PostgreSQL (orders) |
| --- | --- | --- |
| Access pattern | Fetch by known key | Filter, join, aggregate, report |
| Schema | Per-item, flexible | Declared up front, enforced |
| Scaling | Automatic, key-based | Instance sized by you |
| Cost of a bad query | Scan reads the whole table | The planner uses an index |

The rule of thumb the episode lands on: key-value lookups go to DynamoDB, anything you
would want to write a `GROUP BY` against goes to SQL.

## Run instructions

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run ddb:create-table
npm run rds:provision     # prints the assigned PGHOST/PGPORT
npm run lambda:deploy     # discovers and injects them into the function
npm run api:create
```

Order matters: `deploy.sh` reads the database address, so provision before you deploy.
If you provision *after* deploying, just run `npm run lambda:deploy` again.

Then exercise both stores:

```bash
API_URL=$(npm run --silent api:url)

curl -s -X POST "$API_URL/products" -H 'content-type: application/json' \
  -d '{"productId":"p1","name":"Keyboard","price":99}' | jq .

curl -s -X POST "$API_URL/orders" -H 'content-type: application/json' \
  -d '{"orderId":"o1","productId":"p1","quantity":2}' | jq .

curl -s "$API_URL/orders" | jq .
```

```json
{
  "items": [
    { "order_id": "o1", "product_id": "p1", "quantity": 2, "created_at": "2026-01-01T00:00:00.000Z" }
  ],
  "count": 1
}
```

Posting `o1` a second time returns 400, not a 500:

```json
{ "message": "Order o1 already exists" }
```

## Cleanup

```bash
npm run cleanup      # deletes the DB instance, table, API, Lambda, logs and local state
npm run floci:down   # stop the emulator
```

## Common errors

| Error | Fix |
| --- | --- |
| `{"message":"Order storage is unavailable"}` | The Lambda has no PG address. Run `npm run rds:provision`, then `npm run lambda:deploy`. |
| `Warning: flocicart-pg not found - /orders will fail.` | Deploy ran before provisioning. Provision, then redeploy. |
| `password authentication failed for user "postgres"` | `PGUSER`/`PGPASSWORD` in your shell differ from what provisioning used. Keep them consistent or re-provision. |
| `Could not read the endpoint for flocicart-pg` | The instance never became available. Check `npm run floci:logs`. RDS support varies by Floci version [VERIFY]. |

## What is next

Episode 06 puts Redis in front of the product reads with a cache-aside pattern.
