# Ep 07 - SQS Async Jobs

Difficulty: intermediate · Git tag: `ep-07-sqs` · Starts from: `ep-06-elasticache-redis`

## Where we left off

Episode 06 made reads fast. Writes still do everything inline, so `POST /orders` is only
as fast as the slowest thing it triggers.

## What this episode adds

- An `orders-queue` with a **dead-letter queue** and a redrive policy
- The Lambda as producer: store the order, enqueue the rest, return 201
- A standalone worker process as consumer, with retries and graceful shutdown
- `sqs:status` to see backlog, in-flight and failed messages

## The three rules this worker follows

1. **Acknowledge last.** Deleting the message is the acknowledgement, so it happens only
   after the work succeeded. Delete first and a crash silently loses the job.
2. **Do not delete on failure.** The message becomes visible again after the visibility
   timeout and is retried automatically.
3. **Give up eventually.** After 3 receives the redrive policy moves the message to the
   dead-letter queue, so one unprocessable message cannot block the queue forever.

## Run instructions

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run ddb:create-table
npm run rds:provision
npm run cache:provision
npm run sqs:create-queue
npm run lambda:deploy
npm run api:create
```

```text
Queue:            http://localhost:4566/000000000000/orders-queue
Dead-letter:      http://localhost:4566/000000000000/orders-queue-dlq
Retries before DLQ: 3
```

### Terminal 1 - the worker

```bash
npm run worker
```

```text
Worker started. Polling http://localhost:4566/000000000000/orders-queue
Press Ctrl+C to stop.
```

### Terminal 2 - place an order

```bash
cd project
export AWS_ENDPOINT_URL=http://localhost:4566
API_URL=$(npm run --silent api:url)

curl -s -X POST "$API_URL/orders" -H 'content-type: application/json' \
  -d '{"orderId":"o2","productId":"p1","quantity":1}' | jq .
```

```json
{
  "ok": true,
  "order": { "order_id": "o2", "product_id": "p1", "quantity": 1, "created_at": "..." },
  "queued": true
}
```

Terminal 1 prints the job within a second or two:

```text
processed { order_id: 'o2', product_id: 'p1', quantity: 1, created_at: '...' }
```

Check the queue at any time:

```bash
npm run sqs:status
```

```text
orders-queue: 0 waiting, 0 in flight
orders-queue-dlq: 0 waiting, 0 in flight
```

## Why `queued` can be false

The order is already durable in PostgreSQL before the enqueue happens. If SQS is briefly
unavailable, returning 500 would tell the customer their order failed when it did not, so
the API returns 201 with `queued: false` and logs the failure instead.

## Cleanup

```bash
npm run cleanup      # deletes both queues plus everything from earlier episodes
npm run floci:down
```

## Common errors

| Error | Fix |
| --- | --- |
| `QueueDoesNotExist` | Run `npm run sqs:create-queue`, then `npm run lambda:deploy`. |
| `"queued": false` in the response | The Lambda could not reach SQS. Check `npm run lambda:logs`, then redeploy. |
| Worker prints nothing | It is long-polling an empty queue. Place an order in the other terminal. |
| Messages pile up in the DLQ | Processing threw 3 times for those messages. Read them with `aws sqs receive-message` against the DLQ URL. |
| Worker exits immediately | Its `AWS_ENDPOINT_URL` is unset, so it looked for a real AWS queue. Export it in that terminal too. |

## What is next

Episode 08 adds SNS so one event can fan out to several subscribers instead of one queue.
