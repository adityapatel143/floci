# Shared helpers for every shell script in this episode.
# Source it, do not execute it:  source scripts/lib/floci.sh

# One endpoint for all services; override AWS_ENDPOINT_URL to point at real AWS.
EP="${AWS_ENDPOINT_URL:-http://localhost:4566}"

# The AWS CLI refuses to sign a request without credentials, even fake ones.
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-us-east-1}"
export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-test}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-test}"

# Resource names, kept in sync with src/config/resources.mjs.
FUNCTION_NAME="${LAMBDA_FUNCTION:-flocicart-api}"
SMOKE_BUCKET="${SMOKE_BUCKET:-flocicart-ep01-smoke}"
HTTP_API_NAME="${HTTP_API_NAME:-flocicart-http}"
HTTP_API_STAGE="${HTTP_API_STAGE:-dev}"
CATALOG_TABLE="${CATALOG_TABLE:-flocicart-products}"
DB_INSTANCE_ID="${DB_INSTANCE_ID:-flocicart-pg}"
CACHE_CLUSTER_ID="${CACHE_CLUSTER_ID:-flocicart-redis}"
ORDERS_QUEUE_NAME="${ORDERS_QUEUE_NAME:-orders-queue}"
ORDERS_DLQ_NAME="${ORDERS_DLQ_NAME:-orders-queue-dlq}"

# Demo credentials only. On real AWS these would come from Secrets Manager - Episode 11
# covers doing this properly.
PGUSER="${PGUSER:-postgres}"
PGPASSWORD="${PGPASSWORD:-postgres}"
PGDATABASE="${PGDATABASE:-postgres}"

ACCOUNT_ID="000000000000"
LAMBDA_ARN="arn:aws:lambda:${AWS_DEFAULT_REGION}:${ACCOUNT_ID}:function:${FUNCTION_NAME}"
FLOCI_CONTAINER="${FLOCI_CONTAINER:-flocicart-floci}"

# Generated ids and discovered endpoints land here so later commands do not have to
# recreate a resource just to learn its address. Git-ignored; cleanup.sh removes it.
STATE_DIR=".floci"

save_state() {
  mkdir -p "$STATE_DIR"
  printf '%s' "$2" >"$STATE_DIR/$1"
}

read_state() {
  cat "$STATE_DIR/$1" 2>/dev/null || true
}

# `aws` with the endpoint override already applied, so no script repeats it.
floci_aws() {
  aws --endpoint-url "$EP" "$@"
}

require_cmd() {
  for cmd in "$@"; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      echo "Missing required command: $cmd" >&2
      exit 1
    fi
  done
}

# The endpoint a Lambda must use to call back into Floci.
#
# Our shell uses http://localhost:4566, but the function runs in its own container where
# "localhost" is the function itself - so it needs Floci's address on the Docker network.
lambda_facing_endpoint() {
  local ip
  ip="$(docker inspect -f \
    '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' \
    "$FLOCI_CONTAINER" 2>/dev/null | head -n1)"

  if [ -n "$ip" ]; then
    printf 'http://%s:4566\n' "$ip"
  else
    printf '%s\n' "$EP"
  fi
}

# Reads the database address RDS assigned, into PG_ADDRESS / PG_PORT.
discover_pg() {
  local info
  info="$(floci_aws rds describe-db-instances \
    --db-instance-identifier "$DB_INSTANCE_ID" \
    --query 'DBInstances[0].Endpoint.[Address,Port]' \
    --output text 2>/dev/null || true)"

  PG_ADDRESS="$(awk '{print $1}' <<<"$info")"
  PG_PORT="$(awk '{print $2}' <<<"$info")"

  if [ -z "$PG_ADDRESS" ] || [ "$PG_ADDRESS" = "None" ]; then
    return 1
  fi
  return 0
}

# Reads the cache node address ElastiCache assigned, into REDIS_ADDRESS / REDIS_PORT.
# Support varies by Floci version, so callers must handle failure.
discover_redis() {
  local info
  info="$(floci_aws elasticache describe-replication-groups \
    --replication-group-id "$CACHE_CLUSTER_ID" \
    --query 'ReplicationGroups[0].ConfigurationEndpoint.[Address,Port]' \
    --output text 2>/dev/null || true)"

  REDIS_ADDRESS="$(awk '{print $1}' <<<"$info")"
  REDIS_PORT="$(awk '{print $2}' <<<"$info")"

  if [ -z "$REDIS_ADDRESS" ] || [ "$REDIS_ADDRESS" = "None" ]; then
    return 1
  fi

  # Floci reports "localhost" here, but Lambda runs in its own container, where that
  # would mean the function itself rather than the Valkey/Redis container.
  if [ "$REDIS_ADDRESS" = "localhost" ]; then
    REDIS_ADDRESS="floci-valkey-${CACHE_CLUSTER_ID}"
  fi
  return 0
}

# Looks up the queue URL SQS assigned, into ORDERS_QUEUE_URL.
discover_queue() {
  ORDERS_QUEUE_URL="$(floci_aws sqs get-queue-url \
    --queue-name "$ORDERS_QUEUE_NAME" \
    --query QueueUrl --output text 2>/dev/null || true)"

  if [ -z "$ORDERS_QUEUE_URL" ] || [ "$ORDERS_QUEUE_URL" = "None" ]; then
    return 1
  fi
  return 0
}

# Floci accepts TCP connections slightly before it can serve API calls, so poll a real
# call instead of the port.
wait_for_floci() {
  local attempts="${1:-30}"
  for ((i = 1; i <= attempts; i++)); do
    if floci_aws sts get-caller-identity >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
  done
  echo "Floci did not become ready at $EP after ${attempts}s." >&2
  echo "Check it with: docker compose logs -f floci" >&2
  exit 1
}

# A freshly created HTTP API is briefly unroutable and answers 404 "Invalid API id
# specified", so poll the stage URL until it actually serves the Lambda.
wait_for_http_api() {
  local url="$1"
  local attempts="${2:-30}"
  for ((i = 1; i <= attempts; i++)); do
    if curl -fsS -o /dev/null "${url}/health" 2>/dev/null; then
      return 0
    fi
    sleep 1
  done
  echo "HTTP API did not start serving ${url} after ${attempts}s." >&2
  exit 1
}
