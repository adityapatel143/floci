// Consumes order jobs from SQS, outside the request path.
//
// This is a plain long-running Node process - no Lambda, no framework. The loop below is
// all "async processing" really is: receive, work, acknowledge, repeat.
//
// Run it in its own terminal:  npm run worker

import { pullOrderJobs, ackOrderJob, getOrdersQueueUrl } from "../src/queues/ordersQueue.mjs";

let running = true;

// Ctrl+C sets the flag instead of killing the process mid-message, so the job in flight
// finishes and gets acknowledged rather than being redelivered to the next worker.
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => {
    console.log(`\n${signal} received - finishing current batch, then stopping.`);
    running = false;
  });
}

async function processOrder(payload) {
  // Stand-in for the real work: charging a card, sending a confirmation email, updating
  // stock. All the things that would make a POST /orders feel slow if done inline.
  console.log("processed", payload);
}

const queueUrl = await getOrdersQueueUrl();
console.log(`Worker started. Polling ${queueUrl}`);
console.log("Press Ctrl+C to stop.\n");

while (running) {
  let messages;

  try {
    messages = await pullOrderJobs();
  } catch (err) {
    // A transient SQS error must not kill the worker; back off briefly and retry.
    console.error("receive failed:", err.message);
    await new Promise((resolve) => setTimeout(resolve, 2000));
    continue;
  }

  for (const message of messages) {
    const attempt = Number(message.Attributes?.ApproximateReceiveCount || 1);

    try {
      const payload = JSON.parse(message.Body || "{}");
      await processOrder(payload);
      // Acknowledge only after the work succeeded. Deleting first would silently drop
      // the job if processing then threw.
      await ackOrderJob(message.ReceiptHandle);
    } catch (err) {
      // Do NOT delete: leaving the message alone lets SQS redeliver it after the
      // visibility timeout. After maxReceiveCount attempts the redrive policy moves it
      // to the dead-letter queue, so one bad message cannot block the queue forever.
      console.error(`message failed (attempt ${attempt}):`, err.message);
    }
  }
}

console.log("Worker stopped.");
