// Central place where every AWS SDK v3 client is pointed at Floci instead of real AWS.
//
// The only thing that makes these clients "local" is the `endpoint` override below.
// Remove it and the exact same code talks to a real AWS account.

import { S3Client } from "@aws-sdk/client-s3";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SQSClient } from "@aws-sdk/client-sqs";

// Defaults mirror .env.example so the scripts still run if you forget to export anything.
// Inside a Lambda container, AWS_ENDPOINT_URL is injected by the deploy script and points
// at Floci's container IP, because "localhost" there would mean the Lambda itself.
export const endpoint = process.env.AWS_ENDPOINT_URL || "http://localhost:4566";
export const region = process.env.AWS_DEFAULT_REGION || "us-east-1";

// Floci checks that a signature is present, not that the key is real, so dummy values work.
const credentials = {
  accessKeyId: process.env.AWS_ACCESS_KEY_ID || "test",
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "test"
};

const shared = { endpoint, region, credentials };

export const s3 = new S3Client({
  ...shared,
  // Virtual-host style URLs (bucket.localhost) do not resolve locally.
  forcePathStyle: true
});

export const ddb = new DynamoDBClient(shared);
export const sqs = new SQSClient(shared);
