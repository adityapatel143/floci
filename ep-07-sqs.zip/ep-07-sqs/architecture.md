# Episode 07 Architecture

The request path gets shorter. The Lambda stores the order and drops a job on the queue;
a separate process does the slow work whenever it gets to it.

```mermaid
flowchart LR
    C["curl"] --> G["API Gateway v2"]
    G --> L["Lambda: flocicart-api<br/>(producer)"]
    L --> P[("RDS PostgreSQL<br/>orders")]
    L -->|"SendMessage"| Q["SQS: orders-queue"]
    Q -->|"ReceiveMessage<br/>long poll"| W["workers/ordersWorker.mjs<br/>(consumer)"]
    W -->|"DeleteMessage = ack"| Q
    Q -.->|"after 3 failed receives"| DLQ["SQS: orders-queue-dlq"]
    L --> D[("DynamoDB")]
    L --> R[("Redis")]
```

The dashed arrow is the safety valve: a message the worker can never process ends up in
the dead-letter queue instead of being redelivered forever.
