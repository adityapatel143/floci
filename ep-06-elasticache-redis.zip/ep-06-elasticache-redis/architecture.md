# Episode 06 Architecture

Reads get a cache in front of them. Writes get an invalidation behind them - that arrow
back to Redis is what keeps the cached list honest.

```mermaid
flowchart LR
    C["curl"] --> G["API Gateway v2"]
    G --> L["Lambda: flocicart-api"]
    L -->|"GET /products"| S["productsCached.mjs"]
    S -->|"1. read key"| R[("Redis<br/>flocicart-redis")]
    S -->|"2. on miss"| D[("DynamoDB<br/>flocicart-products")]
    S -.->|"3. backfill, TTL 60s"| R
    L -->|"POST /products"| S
    S -.->|"DEL key"| R
    L -->|"/orders"| P[("RDS PostgreSQL")]
```

If Redis is unreachable or was never configured, the service returns `source=db-no-cache`
and reads DynamoDB directly. Correctness never depends on the cache being up.
