#!/usr/bin/env bash
# Shows the cache doing its job: cold read, warm read, then a write that invalidates it.
#
# The point is the `source` field, not the millisecond count - on a local emulator the
# times are small and noisy, but the hit/miss transitions are exact.
set -euo pipefail

cd "$(dirname "$0")/.."
source scripts/lib/floci.sh

require_cmd curl jq

API_URL="$(read_state api-url)"
if [ -z "$API_URL" ]; then
  echo "No API URL saved. Run ./scripts/apigw/create-http-api.sh first." >&2
  exit 1
fi

timed_get() {
  local label="$1"
  local start end body
  start=$(date +%s%N)
  body="$(curl -fsS "${API_URL}/products")"
  end=$(date +%s%N)
  printf '%-22s %-14s %4s ms\n' \
    "$label" \
    "source=$(jq -r '.source' <<<"$body")" \
    "$(((end - start) / 1000000))"
}

echo "Seeding one product..."
curl -fsS -X POST "${API_URL}/products" \
  -H 'content-type: application/json' \
  -d '{"productId":"bench-1","name":"Bench Item","price":10}' >/dev/null

echo
timed_get "1. cold (miss)"
timed_get "2. warm (hit)"
timed_get "3. warm (hit)"

echo
echo "Writing a product - this deletes the cached list..."
curl -fsS -X POST "${API_URL}/products" \
  -H 'content-type: application/json' \
  -d '{"productId":"bench-2","name":"Second Item","price":20}' >/dev/null

echo
timed_get "4. after write (miss)"
timed_get "5. warm again (hit)"

echo
echo "source=db-no-cache on every line means Redis was not discoverable - see the README."
