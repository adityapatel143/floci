#!/usr/bin/env bash
# Removes everything this episode created inside Floci, without stopping the container.
#
# Every step is tolerant of "already gone" so the script is safe to run at any time.
set -euo pipefail

cd "$(dirname "$0")/.."
source scripts/lib/floci.sh

require_cmd aws

if ! floci_aws sts get-caller-identity >/dev/null 2>&1; then
  echo "Floci is not running, so there is nothing to clean up."
  rm -rf dist "$STATE_DIR"
  exit 0
fi

# Delete from the outside in: API, then function, then the stores behind it.
echo "Deleting HTTP APIs named: ${HTTP_API_NAME}"
API_IDS=$(floci_aws apigatewayv2 get-apis \
  --query "Items[?Name=='${HTTP_API_NAME}'].ApiId" --output text 2>/dev/null || true)
FOUND=0
for id in $API_IDS; do
  if [ "$id" != "None" ]; then
    floci_aws apigatewayv2 delete-api --api-id "$id" >/dev/null && echo "  deleted $id"
    FOUND=1
  fi
done
if [ "$FOUND" -eq 0 ]; then
  echo "  (none)"
fi

echo "Deleting Lambda function: ${FUNCTION_NAME}"
floci_aws lambda delete-function --function-name "$FUNCTION_NAME" >/dev/null 2>&1 ||
  echo "  (not deployed)"

echo "Deleting log group: /aws/lambda/${FUNCTION_NAME}"
floci_aws logs delete-log-group --log-group-name "/aws/lambda/${FUNCTION_NAME}" >/dev/null 2>&1 ||
  echo "  (no logs)"

echo "Deleting cache cluster: ${CACHE_CLUSTER_ID}"
floci_aws elasticache delete-replication-group --replication-group-id "$CACHE_CLUSTER_ID" >/dev/null 2>&1 ||
  echo "  (not present)"

echo "Deleting DB instance: ${DB_INSTANCE_ID}"
floci_aws rds delete-db-instance \
  --db-instance-identifier "$DB_INSTANCE_ID" \
  --skip-final-snapshot >/dev/null 2>&1 ||
  echo "  (not present)"

echo "Deleting DynamoDB table: ${CATALOG_TABLE}"
if floci_aws dynamodb delete-table --table-name "$CATALOG_TABLE" >/dev/null 2>&1; then
  floci_aws dynamodb wait table-not-exists --table-name "$CATALOG_TABLE" 2>/dev/null || true
  echo "  deleted"
else
  echo "  (not present)"
fi

echo "Deleting bucket: ${SMOKE_BUCKET}"
floci_aws s3 rb "s3://${SMOKE_BUCKET}" --force >/dev/null 2>&1 ||
  echo "  (not present)"

echo "Removing local build output and saved ids"
rm -rf dist "$STATE_DIR"

echo "Cleanup complete. Run 'npm run floci:down' to stop the emulator too."
