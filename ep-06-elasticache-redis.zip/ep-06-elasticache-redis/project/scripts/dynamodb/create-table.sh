#!/usr/bin/env bash
# Creates the product catalog table, and waits until it can actually accept writes.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws

wait_for_floci

if floci_aws dynamodb describe-table --table-name "$CATALOG_TABLE" >/dev/null 2>&1; then
  echo "Table ${CATALOG_TABLE} already exists."
else
  echo "Creating table ${CATALOG_TABLE}..."
  floci_aws dynamodb create-table \
    --table-name "$CATALOG_TABLE" \
    --attribute-definitions AttributeName=productId,AttributeType=S \
    --key-schema AttributeName=productId,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST >/dev/null
fi

# A table exists before it is usable; writing to a CREATING table fails, so block here
# rather than letting the first curl return a confusing 500.
echo "Waiting for ${CATALOG_TABLE} to become ACTIVE..."
floci_aws dynamodb wait table-exists --table-name "$CATALOG_TABLE"

echo "Table ${CATALOG_TABLE} ready."
