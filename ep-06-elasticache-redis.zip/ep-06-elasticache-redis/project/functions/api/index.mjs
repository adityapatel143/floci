// The FlociCart API Lambda, now reading the catalog through a cache.
//
// Note what did not change: the routes and the response shapes. Adding a cache is a
// swap of one collaborator (`listProducts` -> `getProductsCached`), which is only
// possible because reads already went through a seam.

import { createProductAndInvalidate, getProductsCached } from "../../src/services/productsCached.mjs";
import { initOrdersTable, createOrder, listOrders } from "../../src/repositories/ordersPg.mjs";
import { ValidationError } from "../../src/errors.mjs";

// Module scope survives between warm invocations, so the schema check runs once per
// container instead of once per request.
let ordersReady;

function ensureOrdersTable() {
  if (!ordersReady) {
    // Cache the promise, not the result: two concurrent requests then share one CREATE.
    ordersReady = initOrdersTable().catch((err) => {
      ordersReady = undefined; // let the next request retry instead of failing forever
      throw err;
    });
  }
  return ordersReady;
}

const json = (statusCode, payload) => ({
  statusCode,
  headers: { "content-type": "application/json" },
  body: JSON.stringify(payload)
});

const parseBody = (event) => {
  try {
    return JSON.parse(event?.body || "{}");
  } catch {
    throw new ValidationError("Request body must be valid JSON");
  }
};

export const handler = async (event) => {
  const method = event?.requestContext?.http?.method || "INVOKE";
  const path = event?.rawPath || "/";

  console.log("request", JSON.stringify({ method, path }));

  try {
    if (method === "GET" && path === "/health") {
      return json(200, { ok: true, service: "flocicart-api", now: new Date().toISOString() });
    }

    if (method === "POST" && path === "/products") {
      const product = await createProductAndInvalidate(parseBody(event));
      return json(201, { ok: true, product });
    }

    if (method === "GET" && path === "/products") {
      // Response includes `source` so you can watch cache hits happen.
      const out = await getProductsCached();
      return json(200, { ...out, count: out.items.length });
    }

    if (method === "POST" && path === "/orders") {
      await ensureOrdersTable();
      const order = await createOrder(parseBody(event));
      return json(201, { ok: true, order });
    }

    if (method === "GET" && path === "/orders") {
      await ensureOrdersTable();
      const items = await listOrders();
      return json(200, { items, count: items.length });
    }

    return json(404, { message: "Not Found", method, path });
  } catch (err) {
    if (err instanceof ValidationError) {
      return json(400, { message: err.message });
    }

    if (["ECONNREFUSED", "ETIMEDOUT", "ENOTFOUND"].includes(err?.code)) {
      console.error("dependency unreachable", err.message);
      return json(503, { message: "A backing store is unavailable" });
    }

    console.error("unhandled", err);
    return json(500, { message: "Internal Server Error" });
  }
};
