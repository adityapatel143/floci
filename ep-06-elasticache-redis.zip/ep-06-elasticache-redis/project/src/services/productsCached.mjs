// Cache-aside reads for the product catalog.
//
// Cache-aside means the application owns the cache: read it, and only on a miss go to the
// database and put the result back. The cache never talks to DynamoDB itself, so it can
// disappear at any moment without breaking correctness.
//
// The `source` field in the response exists purely so the episode can show which path a
// request took. Real APIs would not leak that.

import { redis, cacheTtlSeconds } from "../cache/redis.mjs";
import { listProducts, createProduct } from "../repositories/catalogDdb.mjs";

const KEY = "flocicart:products:list";

export async function getProductsCached() {
  if (!redis) {
    const items = await listProducts();
    return { source: "db-no-cache", items };
  }

  try {
    const cached = await redis.get(KEY);
    if (cached) {
      return { source: "cache", items: JSON.parse(cached) };
    }

    const items = await listProducts();
    // EX sets a TTL. Without one, a cache miss that is never invalidated would serve
    // stale data forever.
    await redis.set(KEY, JSON.stringify(items), "EX", cacheTtlSeconds);
    return { source: "db", items };
  } catch (err) {
    // A cache outage should degrade catalog reads to DynamoDB, not fail the request.
    console.error("cache read failed, falling back to db", err.message);
    const items = await listProducts();
    return { source: "db-no-cache", items };
  }
}

// Writes go through here so the cached list cannot outlive the data it describes.
// Without this, adding a product would be invisible for up to cacheTtlSeconds - the
// classic cache-aside bug.
export async function createProductAndInvalidate(input) {
  const product = await createProduct(input);

  if (redis) {
    try {
      // Delete rather than update: the next reader rebuilds the list from the source of
      // truth, so two concurrent writers cannot leave a merged, wrong list behind.
      await redis.del(KEY);
    } catch (err) {
      // The write already succeeded. Losing the invalidation only means stale reads
      // until the TTL expires, which is not worth failing the request over.
      console.error("cache invalidation failed", err.message);
    }
  }

  return product;
}
