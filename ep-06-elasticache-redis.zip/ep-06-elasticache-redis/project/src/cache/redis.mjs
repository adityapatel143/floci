// Redis connection for the cache-aside layer.
//
// The cache is deliberately optional. If REDIS_HOST was never injected, or the node is
// unreachable, `redis` is null and the app falls back to reading the database directly -
// a cache outage should slow the catalog down, not take it offline.

import Redis from "ioredis";

const redisHost = process.env.REDIS_HOST;
const redisPort = Number(process.env.REDIS_PORT || 6379);

export const redis = redisHost
  ? new Redis({
      host: redisHost,
      port: redisPort,
      // Every setting below exists to make failure fast. Inside a Lambda, a client that
      // patiently retries just burns the request's time budget and then fails anyway.
      connectTimeout: 300,
      maxRetriesPerRequest: 1,
      // Without this, commands issued while disconnected queue up silently and hang.
      enableOfflineQueue: false,
      // null = never reconnect. The request falls back to the database instead.
      retryStrategy: () => null
    })
  : null;

// ioredis emits 'error' on connection problems; with no listener Node would treat it as
// an unhandled exception and kill the container.
redis?.on("error", (err) => {
  console.error("redis error", err.message);
});

// Short by design: a stale catalog for up to a minute is acceptable, and the write path
// also invalidates the key, so this is only a backstop against missed invalidations.
export const cacheTtlSeconds = 60;
