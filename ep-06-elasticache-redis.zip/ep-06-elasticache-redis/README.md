# Ep 06 - Redis Cache-Aside Layer

Difficulty: intermediate · Git tag: `ep-06-elasticache-redis` · Starts from: `ep-05-rds-postgresql`

## Where we left off

Episode 05 had two stores. Every `GET /products` still scanned DynamoDB from scratch.

## What this episode adds

- An ElastiCache Redis node, provisioned and discovered
- Cache-aside reads for `GET /products`, with the path taken reported as `source`
- **Cache invalidation on write** - without it, a new product stays invisible for a minute
- A graceful no-cache fallback, so a Redis outage slows the API instead of breaking it
- `scripts/bench-cache.sh` to watch hits, misses and invalidation in sequence

## Cache-aside in one paragraph

The application owns the cache. Read the key; on a hit, return it. On a miss, read the
database, write the result back with a TTL, return it. On a write, delete the key so the
next reader rebuilds it. Redis never talks to DynamoDB, which is why losing the cache can
never lose data.

## Run instructions

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run ddb:create-table
npm run rds:provision
npm run cache:provision   # prints REDIS_HOST/REDIS_PORT if discoverable
npm run lambda:deploy     # injects whatever was discovered
npm run api:create
```

Provision before you deploy - `deploy.sh` reads the addresses. If you provision later,
just redeploy.

## Live demo

```bash
npm run cache:bench
```

```text
Seeding one product...

1. cold (miss)         source=db          31 ms
2. warm (hit)          source=cache        8 ms
3. warm (hit)          source=cache        7 ms

Writing a product - this deletes the cached list...

4. after write (miss)  source=db          27 ms
5. warm again (hit)    source=cache        8 ms
```

Line 4 is the part worth pausing on: the write invalidated the key, so the list rebuilt
immediately instead of serving a stale catalog until the 60s TTL expired.

## When Redis is not discoverable

Node-level ElastiCache endpoints are not exposed by every Floci build [VERIFY]. If
`cache:provision` reports that, every response shows `source=db-no-cache` and the API
keeps working. That is the designed fallback, not a broken setup - it is the same code
path you would take if a production cache node went down.

## Cleanup

```bash
npm run cleanup      # deletes cache cluster, DB instance, table, API, Lambda and state
npm run floci:down
```

## Common errors

| Error | Fix |
| --- | --- |
| Every response says `source=db-no-cache` | `REDIS_HOST` was never injected. Run `npm run cache:provision`, then `npm run lambda:deploy`. |
| New products do not appear in `GET /products` | Invalidation is not running. Make sure the write goes through `createProductAndInvalidate`, then redeploy. |
| `redis error connect ETIMEDOUT` in the logs | The node address is not reachable from the Lambda's container. The request still succeeds via the fallback. |
| `Cannot read properties of null (reading 'get')` | Something used `redis` without the null check - the client is intentionally null when unconfigured. |

## What is next

Episode 07 moves slow work off the request path with an SQS queue and a worker.
