// Names of the AWS resources this episode creates.
// Shared so every script and the cleanup step can never drift apart.

export const SMOKE_BUCKET = process.env.SMOKE_BUCKET || "flocicart-ep01-smoke";
export const LAMBDA_FUNCTION = process.env.LAMBDA_FUNCTION || "flocicart-api";
export const HTTP_API_NAME = process.env.HTTP_API_NAME || "flocicart-http";
export const HTTP_API_STAGE = process.env.HTTP_API_STAGE || "dev";
export const CATALOG_TABLE = process.env.CATALOG_TABLE || "flocicart-products";
