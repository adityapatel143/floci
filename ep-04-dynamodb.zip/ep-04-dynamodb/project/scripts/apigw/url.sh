#!/usr/bin/env bash
# Prints the base URL of the HTTP API created by create-http-api.sh.
#
# Exists so you can curl the API without re-running the create script just to see the id:
#   curl -s "$(./scripts/apigw/url.sh)/products" | jq .
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

API_URL="$(read_state api-url)"

if [ -z "$API_URL" ]; then
  echo "No API URL saved. Run ./scripts/apigw/create-http-api.sh first." >&2
  exit 1
fi

printf '%s\n' "$API_URL"
