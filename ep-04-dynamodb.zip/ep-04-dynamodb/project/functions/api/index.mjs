// The FlociCart API Lambda, now backed by a real datastore.
//
// The handler stays a thin router: it turns an HTTP event into a repository call and a
// repository result into a response. All DynamoDB detail lives in the repository.

import { createProduct, listProducts, ValidationError } from "../../src/repositories/catalogDdb.mjs";

const json = (statusCode, payload) => ({
  statusCode,
  headers: { "content-type": "application/json" },
  body: JSON.stringify(payload)
});

// A malformed body is a client mistake, so it must not surface as a 500.
const parseBody = (event) => {
  try {
    return JSON.parse(event?.body || "{}");
  } catch {
    throw new ValidationError("Request body must be valid JSON");
  }
};

export const handler = async (event) => {
  const method = event?.requestContext?.http?.method || "INVOKE";
  const path = event?.rawPath || "/";

  console.log("request", JSON.stringify({ method, path }));

  try {
    if (method === "GET" && path === "/health") {
      return json(200, { ok: true, service: "flocicart-api", now: new Date().toISOString() });
    }

    if (method === "POST" && path === "/products") {
      const product = await createProduct(parseBody(event));
      return json(201, { ok: true, product });
    }

    if (method === "GET" && path === "/products") {
      const items = await listProducts();
      return json(200, { items, count: items.length });
    }

    return json(404, { message: "Not Found", method, path });
  } catch (err) {
    if (err instanceof ValidationError) {
      return json(400, { message: err.message });
    }

    // Anything else is our bug or a broken dependency: log the detail for the operator,
    // return a generic message so internals are not exposed to the caller.
    console.error("unhandled", err);
    return json(500, { message: "Internal Server Error" });
  }
};
