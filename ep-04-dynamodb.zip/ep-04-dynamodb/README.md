# Ep 04 - DynamoDB CRUD from Lambda

Difficulty: intermediate · Git tag: `ep-04-dynamodb` · Starts from: `ep-03-apigw-v2`

## Where we left off

Episode 03 put an HTTP API in front of the Lambda, but every response was invented on the spot.

## What this episode adds

- A `flocicart-products` DynamoDB table (partition key `productId`)
- A repository layer so the handler never touches DynamoDB's attribute-value format
- `POST /products` and `GET /products` with real input validation
- Proper status codes: 201, 400 for bad input, 404 for unknown routes, 500 for real failures

## Order of operations

The table must exist before the Lambda serves traffic, and the Lambda must exist before
the API can integrate with it:

```text
create-table  ->  lambda:deploy  ->  api:create
```

## Files in this episode

| Path | Purpose |
| --- | --- |
| `project/scripts/dynamodb/create-table.sh` | Creates the table and waits for ACTIVE |
| `project/src/repositories/catalogDdb.mjs` | Put/Scan plus input validation |
| `project/functions/api/index.mjs` | Thin router over the repository |

## Run instructions

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run ddb:create-table
npm run lambda:deploy
npm run api:create
```

Then exercise the API:

```bash
API_URL=$(npm run --silent api:url)

curl -s -X POST "$API_URL/products" \
  -H 'content-type: application/json' \
  -d '{"productId":"p1","name":"Keyboard","price":99}' | jq .

curl -s "$API_URL/products" | jq .
```

```json
{ "ok": true, "product": { "productId": "p1", "name": "Keyboard", "price": 99 } }
{ "items": [ { "productId": "p1", "name": "Keyboard", "price": 99 } ], "count": 1 }
```

Bad input is rejected before it reaches DynamoDB:

```bash
curl -s -X POST "$API_URL/products" -H 'content-type: application/json' -d '{"name":"No id"}' | jq .
# { "message": "productId is required and must be a non-empty string" }
```

## Why the Lambda gets a different endpoint

The shell talks to Floci on `http://localhost:4566`. Inside the Lambda's own container,
`localhost` is the Lambda - so `deploy.sh` looks up Floci's container IP and injects that
as `AWS_ENDPOINT_URL` for the function. Without it, every DynamoDB call from the handler
would hang or be refused.

## Cleanup

```bash
npm run cleanup      # delete the API, Lambda, logs, table, bucket, dist/ and .floci/
npm run floci:down   # stop the emulator
```

## Common errors

| Error | Fix |
| --- | --- |
| `ResourceNotFoundException: Requested resource not found` | The table does not exist. Run `npm run ddb:create-table`. |
| `Internal Server Error` on `POST /products` | Check `npm run lambda:logs` - usually the function cannot reach Floci. Redeploy so the container endpoint is re-injected. |
| `ValidationException: One or more parameter values were invalid` | An empty string in a key attribute. The repository now rejects this with a 400 first. |
| `{"message":"Not Found"}` | Unknown route. Only `/health`, `POST /products` and `GET /products` exist. |

## What is next

Episode 05 adds PostgreSQL for orders and compares it with DynamoDB.
