# Episode 04 Architecture

The first persistent store. Requests stop being echoes and start reading and writing real
rows, but only the repository knows that the store is DynamoDB.

```mermaid
flowchart LR
    C["curl"] --> G["API Gateway v2"]
    G --> L["Lambda: flocicart-api<br/>(router)"]
    L --> R["catalogDdb.mjs<br/>(repository)"]
    R --> D[("DynamoDB<br/>flocicart-products<br/>PK: productId")]
    L --> CW["CloudWatch Logs"]
```

The Lambda reaches DynamoDB via Floci's container IP, not `localhost` - inside the
function's container, `localhost` would be the function itself.
