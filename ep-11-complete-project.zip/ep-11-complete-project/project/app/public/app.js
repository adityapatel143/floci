// The storefront. A plain static file - no build step, no framework - because the point
// of the episode is where it is served from, not what it is written in.
//
// FLOCICART_API_BASE comes from config.js, which upload.sh generates with the real API
// URL. The API id changes whenever the API is recreated, so it cannot be hardcoded here.
//
// Full CRUD for both products and orders, plus a cache-state and timing readout on each
// list, read from the `meta` block the API attaches to every JSON response.

const apiBase = window.FLOCICART_API_BASE;

const el = (id) => document.getElementById(id);
const dom = {
  toasts: el("toasts"),
  health: el("api-health"),
  themeToggle: el("theme-toggle"),
  productsBody: el("products-body"),
  productsMeta: el("products-meta"),
  productsSearch: el("products-search"),
  productForm: el("product-form"),
  ordersBody: el("orders-body"),
  ordersMeta: el("orders-meta"),
  ordersSearch: el("orders-search"),
  orderForm: el("order-form"),
  confirm: el("confirm-dialog"),
  confirmTitle: el("confirm-title"),
  confirmText: el("confirm-text"),
  pipelineCard: el("pipeline-card"),
  pipelineOrderId: el("pipeline-order-id"),
  pipelineStatus: el("pipeline-status")
};

// Single client-side copy of server state. Every render reads from here, so the table and
// the stats can never disagree with each other. The *Meta entries hold the last response
// metadata so a re-render (search, filter) does not wipe the badges.
const state = {
  products: [],
  orders: [],
  productFilter: "",
  orderFilter: "",
  productsMeta: null,
  ordersMeta: null
};

const money = new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" });
const escapeHtml = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

/* ------------------------------- feedback -------------------------------- */

function toast(message, kind = "info") {
  const node = document.createElement("div");
  node.className = `toast ${kind}`;
  node.textContent = message;
  dom.toasts.append(node);
  setTimeout(() => {
    node.classList.add("leaving");
    setTimeout(() => node.remove(), 200);
  }, kind === "error" ? 5000 : 2800);
}

/* -------------------------------- fetch ---------------------------------- */

// One place that knows how to talk to the API, so error handling is not repeated at
// every call site. A rejected fetch (rather than a non-2xx status) is almost always CORS
// or a dead endpoint, so it is reported as such instead of as a bare "TypeError".
//
// Returns { data, meta }: `meta.serverMs` is the handler's own time as measured in
// Lambda, `meta.totalMs` is the full round trip as measured here. The gap between them
// is API Gateway, TLS and network - which is the useful signal when a call feels slow.
async function api(path, { method = "GET", body } = {}) {
  // performance.now() is monotonic - unlike Date.now() it cannot go backwards if the
  // system clock is adjusted mid-request.
  const startedAt = performance.now();
  let res;
  try {
    res = await fetch(`${apiBase}${path}`, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined
    });
  } catch (err) {
    throw new Error(`Request failed: ${err.message}. Check the API is up and allows this origin.`);
  }

  const text = await res.text();
  const totalMs = Math.round(performance.now() - startedAt);
  const data = text ? JSON.parse(text) : {};
  if (!res.ok) throw new Error(data.message || `${res.status} ${res.statusText}`);

  return { data, meta: { ...(data.meta || {}), totalMs } };
}

/* ------------------------------ rendering -------------------------------- */

const skeleton = (cols) =>
  `<tr class="skeleton">${"<td><span></span></td>".repeat(cols)}</tr>`;

// Cache state is only meaningful for the product list: it is the one read that goes
// through Redis. Orders come from Postgres and single products bypass the cache
// deliberately, so those show timings only rather than a misleading "MISS".
function metaBadges(meta) {
  if (!meta) return "";

  const label = meta.source === "cache" ? "CACHE HIT"
              : meta.source === "origin" ? "CACHE MISS"
              : null;
  const cls = meta.source === "cache" ? "badge-hit"
            : meta.source === "origin" ? "badge-miss"
            : "badge-neutral";

  const parts = [];
  if (label) parts.push(`<span class="badge ${cls}">${label}</span>`);
  if (meta.serverMs != null) {
    parts.push(`<span class="badge badge-neutral">${meta.serverMs} ms server</span>`);
  }
  parts.push(`<span class="badge badge-neutral">${meta.totalMs} ms total</span>`);
  return parts.join(" ");
}

function renderProducts() {
  const q = state.productFilter.toLowerCase();
  const rows = state.products.filter(
    (p) => !q || `${p.productId} ${p.name}`.toLowerCase().includes(q)
  );

  dom.productsBody.innerHTML = rows.length
    ? rows
        .map(
          (p) => `
      <tr data-id="${escapeHtml(p.productId)}">
        <td class="mono">${escapeHtml(p.productId)}</td>
        <td>${escapeHtml(p.name)}</td>
        <td class="num">${money.format(Number(p.price) || 0)}</td>
        <td class="actions">
          <button class="btn btn-ghost btn-icon" data-action="edit-product">Edit</button>
          <button class="btn btn-ghost btn-icon danger" data-action="delete-product">Delete</button>
        </td>
      </tr>`
        )
        .join("")
    : `<tr><td colspan="4" class="empty">${
        state.products.length ? "No products match that search." : "No products yet - add one above."
      }</td></tr>`;

  // innerHTML, not textContent, because the badges are markup. Everything interpolated
  // is a number or a fixed string from our own code - no user input reaches it.
  dom.productsMeta.innerHTML =
    `${rows.length} of ${state.products.length} shown ${metaBadges(state.productsMeta)}`;

  syncProductOptions();
  renderStats();
}

function renderOrders() {
  const q = state.orderFilter.toLowerCase();
  const byId = new Map(state.products.map((p) => [p.productId, p.name]));
  const rows = state.orders.filter(
    (o) => !q || `${o.order_id} ${o.product_id}`.toLowerCase().includes(q)
  );

  dom.ordersBody.innerHTML = rows.length
    ? rows
        .map((o) => {
          const name = byId.get(o.product_id);
          return `
      <tr data-id="${escapeHtml(o.order_id)}">
        <td class="mono">${escapeHtml(o.order_id)}</td>
        <td>${escapeHtml(name || o.product_id)}${
            name ? ` <span class="mono">${escapeHtml(o.product_id)}</span>` : ""
          }</td>
        <td class="num">${o.quantity}</td>
        <td class="mono">${new Date(o.created_at).toLocaleString()}</td>
        <td class="actions">
          <button class="btn btn-ghost btn-icon" data-action="edit-order">Edit</button>
          <button class="btn btn-ghost btn-icon danger" data-action="delete-order">Delete</button>
        </td>
      </tr>`;
        })
        .join("")
    : `<tr><td colspan="5" class="empty">${
        state.orders.length ? "No orders match that search." : "No orders yet - place one above."
      }</td></tr>`;

  dom.ordersMeta.innerHTML =
    `${rows.length} of ${state.orders.length} shown ${metaBadges(state.ordersMeta)}`;

  renderStats();
}

function renderStats() {
  const units = state.orders.reduce((sum, o) => sum + Number(o.quantity || 0), 0);
  const value = state.products.reduce((sum, p) => sum + Number(p.price || 0), 0);
  el("stat-products").textContent = state.products.length;
  el("stat-orders").textContent = state.orders.length;
  el("stat-units").textContent = units;
  el("stat-value").textContent = money.format(value);
}

// The order form's product picker mirrors the catalog, but keeps whatever was already
// selected so a reload mid-edit does not silently change the product being ordered.
function syncProductOptions() {
  const select = dom.orderForm.elements.productId;
  const previous = select.value;
  select.innerHTML = state.products.length
    ? state.products
        .map(
          (p) =>
            `<option value="${escapeHtml(p.productId)}">${escapeHtml(p.name)} (${escapeHtml(p.productId)})</option>`
        )
        .join("")
    : `<option value="" disabled selected>No products yet</option>`;
  if (previous && state.products.some((p) => p.productId === previous)) select.value = previous;
}

/* -------------------------------- loading -------------------------------- */

async function loadProducts({ skeletonFirst = false } = {}) {
  if (skeletonFirst) dom.productsBody.innerHTML = skeleton(4);
  try {
    const { data, meta } = await api("/products");
    state.products = data.items || [];
    state.productsMeta = meta;
    renderProducts();
    renderOrders(); // order rows show product names, so they depend on the catalog
  } catch (err) {
    state.productsMeta = null;
    dom.productsBody.innerHTML = `<tr><td colspan="4" class="empty">${escapeHtml(err.message)}</td></tr>`;
    toast(err.message, "error");
  }
}

async function loadOrders({ skeletonFirst = false } = {}) {
  if (skeletonFirst) dom.ordersBody.innerHTML = skeleton(5);
  try {
    const { data, meta } = await api("/orders");
    state.orders = data.items || [];
    state.ordersMeta = meta;
    renderOrders();
  } catch (err) {
    state.ordersMeta = null;
    dom.ordersBody.innerHTML = `<tr><td colspan="5" class="empty">${escapeHtml(err.message)}</td></tr>`;
    toast(err.message, "error");
  }
}

async function checkHealth() {
  try {
    await api("/health");
    dom.health.textContent = "API online";
    dom.health.className = "pill pill-ok";
  } catch {
    dom.health.textContent = "API unreachable";
    dom.health.className = "pill pill-bad";
  }
}

/* ------------------------------ form modes ------------------------------- */

// Create and update share one form. `mode` carries which one is active, and the ID field
// is locked while editing because the id is the primary key on the server.
function setFormMode(form, mode, values = {}) {
  const idField = form === dom.productForm ? "productId" : "orderId";
  const submit = form.querySelector('button[type="submit"]');
  const cancel = form.querySelector('[data-action^="cancel"]');

  form.elements.mode.value = mode;
  form.elements[idField].readOnly = mode === "edit";
  cancel.classList.toggle("hidden", mode !== "edit");
  submit.textContent = mode === "edit" ? "Save changes" : submit.dataset.label;

  if (mode === "edit") {
    for (const [key, value] of Object.entries(values)) {
      if (form.elements[key]) form.elements[key].value = value;
    }
    form.scrollIntoView({ behavior: "smooth", block: "center" });
    form.elements[form === dom.productForm ? "name" : "quantity"].focus();
  } else {
    form.reset();
    form.elements.mode.value = "create";
    if (form === dom.orderForm) form.elements.quantity.value = "1";
    syncProductOptions();
  }
}

async function submitting(form, fn) {
  const buttons = form.querySelectorAll("button");
  buttons.forEach((b) => (b.disabled = true));
  try {
    await fn();
  } catch (err) {
    toast(err.message, "error");
  } finally {
    buttons.forEach((b) => (b.disabled = false));
  }
}

function confirmDelete(title, text) {
  dom.confirmTitle.textContent = title;
  dom.confirmText.textContent = text;
  dom.confirm.showModal();
  return new Promise((resolve) =>
    dom.confirm.addEventListener("close", () => resolve(dom.confirm.returnValue === "confirm"), {
      once: true
    })
  );
}

/* ------------------------------ order pipeline ----------------------------- */

// Reflects real per-stage status, read from GET /orders/:orderId/pipeline (written by
// four different Lambdas as the order genuinely moves through the system) - not a
// guessed timeline. "placed" and "db" are already known synchronously from the POST
// response (a 201 IS the proof), so those never need polling; "queue" is the same
// (the API already reports queued:true/false). Everything after that only happens
// asynchronously, so it is polled for.
const PIPELINE_STAGE_LABELS = {
  db: "Saved to the database",
  queue: "Added to the processing queue",
  worker: "Order worker picked it up",
  fanout: "Event broadcast to every subscriber",
  notifications: "Notification sent",
  analytics: "Analytics recorded"
};

// Which arrow (by index) leads into a given stage, for the "flowing dot" animation.
const PIPELINE_ARROW_INDEX = { queue: 0, worker: 1, fanout: 2, notifications: 3, analytics: 3 };

const ASYNC_PIPELINE_STAGES = ["worker", "fanout", "notifications", "analytics"];

const pipelineArrows = [...document.querySelectorAll("#pipeline .pipeline-arrow")];
const pipelineSubstageEls = {};
for (const node of document.querySelectorAll("#pipeline [data-substage]")) {
  (pipelineSubstageEls[node.dataset.substage] ||= []).push(node);
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function setSubstageStatus(key, status) {
  for (const node of pipelineSubstageEls[key] || []) {
    node.classList.remove("is-active", "is-done", "is-failed");
    if (status) node.classList.add(`is-${status}`);
  }
}

function flashArrow(index) {
  const arrow = pipelineArrows[index];
  if (!arrow) return;
  arrow.classList.add("is-flowing");
  setTimeout(() => arrow.classList.remove("is-flowing"), 550);
}

// Bumped on every new order and on dismiss, so a still-polling earlier order can never
// keep updating a panel that now belongs to a different order (or is closed).
let pipelineRun = 0;

async function playOrderPipeline(orderId, { queued }) {
  const runId = ++pipelineRun;

  dom.pipelineOrderId.textContent = orderId;
  dom.pipelineCard.hidden = false;
  for (const key of Object.keys(pipelineSubstageEls)) setSubstageStatus(key, null);

  // Already known synchronously - the 201 response is the real result, so there is
  // nothing to poll for either of these two.
  setSubstageStatus("placed", "done");
  setSubstageStatus("db", "done");

  if (!queued) {
    flashArrow(PIPELINE_ARROW_INDEX.queue);
    setSubstageStatus("queue", "failed");
    dom.pipelineStatus.textContent = "Order saved, but it could not be queued for processing.";
    return;
  }
  flashArrow(PIPELINE_ARROW_INDEX.queue);
  setSubstageStatus("queue", "done");

  // "active" here means genuinely waiting on that Lambda right now - shown as pulsing
  // until real data says otherwise, not just "next in the sequence".
  ASYNC_PIPELINE_STAGES.forEach((key) => setSubstageStatus(key, "active"));
  dom.pipelineStatus.textContent = "Waiting for the order worker to pick it up\u2026";

  const lastStatus = {};
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const pollMs = reduced ? 150 : 700;
  const maxAttempts = 20; // ~14s of polling before giving up and saying so

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (runId !== pipelineRun) return; // superseded by a newer order, or dismissed
    await sleep(pollMs);
    if (runId !== pipelineRun) return;

    let stages;
    try {
      const { data } = await api(`/orders/${encodeURIComponent(orderId)}/pipeline`);
      stages = data.stages || {};
    } catch {
      continue; // a transient poll failure is not the same as the order itself failing
    }

    let allDone = true;
    for (const key of ASYNC_PIPELINE_STAGES) {
      const status = stages[key]?.status;
      if (status !== lastStatus[key]) {
        lastStatus[key] = status;
        if (status) {
          flashArrow(PIPELINE_ARROW_INDEX[key]);
          setSubstageStatus(key, status === "ok" ? "done" : "failed");
          dom.pipelineStatus.textContent =
            status === "ok"
              ? `${PIPELINE_STAGE_LABELS[key]}.`
              : `${PIPELINE_STAGE_LABELS[key]} failed: ${stages[key].error || "unknown error"} \u2013 it will retry.`;
        }
      }
      if (status !== "ok") allDone = false;
    }

    if (allDone) {
      dom.pipelineStatus.textContent = "Done - order fully processed.";
      return;
    }
  }

  if (runId !== pipelineRun) return;
  // A stage that stayed unseen the whole time reverts to idle rather than pulsing
  // forever; one that failed and never recovered stays visibly red either way.
  for (const key of ASYNC_PIPELINE_STAGES) {
    if (lastStatus[key] === undefined) setSubstageStatus(key, null);
  }
  dom.pipelineStatus.textContent =
    "Still waiting on some steps after 14s - check the worker Lambda logs if this doesn't finish.";
}

function dismissPipeline() {
  pipelineRun++; // stop any in-flight polling from touching a now-hidden panel
  dom.pipelineCard.hidden = true;
}

/* ------------------------------- handlers -------------------------------- */

dom.productForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.target;
  const data = Object.fromEntries(new FormData(form));
  const payload = {
    productId: data.productId.trim(),
    name: data.name.trim(),
    price: Number(data.price)
  };

  submitting(form, async () => {
    if (data.mode === "edit") {
      await api(`/products/${encodeURIComponent(payload.productId)}`, { method: "PUT", body: payload });
      toast(`Updated ${payload.productId}`, "ok");
    } else {
      await api("/products", { method: "POST", body: payload });
      toast(`Added ${payload.productId}`, "ok");
    }
    setFormMode(form, "create");
    await loadProducts();
  });
});

dom.orderForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.target;
  const data = Object.fromEntries(new FormData(form));
  const payload = {
    orderId: data.orderId.trim(),
    productId: data.productId,
    quantity: Number(data.quantity)
  };

  if (!payload.productId) return toast("Add a product before ordering.", "error");

  submitting(form, async () => {
    if (data.mode === "edit") {
      await api(`/orders/${encodeURIComponent(payload.orderId)}`, {
        method: "PUT",
        body: { productId: payload.productId, quantity: payload.quantity }
      });
      toast(`Updated ${payload.orderId}`, "ok");
    } else {
      const { data: out } = await api("/orders", { method: "POST", body: payload });
      // The API returns queued:false when the order was stored but the job could not be
      // enqueued. That is a warning, not a failure - the order exists either way.
      toast(
        out.queued === false
          ? `Order ${payload.orderId} stored, but background processing was not queued.`
          : `Order ${payload.orderId} placed`,
        out.queued === false ? "error" : "ok"
      );
      // The pipeline panel itself shows the queue failure case (see playOrderPipeline),
      // rather than being skipped - that is real, useful information too.
      playOrderPipeline(payload.orderId, { queued: out.queued !== false });
    }
    setFormMode(form, "create");
    await loadOrders();
  });
});

// One delegated listener per table rather than a listener per row, so re-rendering the
// tbody never leaks handlers.
dom.productsBody.addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  const row = button.closest("tr");
  const id = row.dataset.id;
  const product = state.products.find((p) => p.productId === id);
  if (!product) return;

  if (button.dataset.action === "edit-product") {
    setFormMode(dom.productForm, "edit", {
      productId: product.productId,
      name: product.name,
      price: product.price
    });
    return;
  }

  if (await confirmDelete("Delete product?", `${product.name} (${id}) will be removed from the catalog.`)) {
    row.classList.add("is-busy");
    try {
      await api(`/products/${encodeURIComponent(id)}`, { method: "DELETE" });
      toast(`Deleted ${id}`, "ok");
      await loadProducts();
    } catch (err) {
      row.classList.remove("is-busy");
      toast(err.message, "error");
    }
  }
});

dom.ordersBody.addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  const row = button.closest("tr");
  const id = row.dataset.id;
  const order = state.orders.find((o) => o.order_id === id);
  if (!order) return;

  if (button.dataset.action === "edit-order") {
    setFormMode(dom.orderForm, "edit", {
      orderId: order.order_id,
      productId: order.product_id,
      quantity: order.quantity
    });
    return;
  }

  if (await confirmDelete("Delete order?", `Order ${id} will be permanently removed.`)) {
    row.classList.add("is-busy");
    try {
      await api(`/orders/${encodeURIComponent(id)}`, { method: "DELETE" });
      toast(`Deleted ${id}`, "ok");
      await loadOrders();
    } catch (err) {
      row.classList.remove("is-busy");
      toast(err.message, "error");
    }
  }
});

document.addEventListener("click", (event) => {
  const action = event.target.closest("[data-action]")?.dataset.action;
  if (action === "refresh-products") loadProducts({ skeletonFirst: true });
  if (action === "refresh-orders") loadOrders({ skeletonFirst: true });
  if (action === "cancel-product-edit") setFormMode(dom.productForm, "create");
  if (action === "cancel-order-edit") setFormMode(dom.orderForm, "create");
  if (action === "dismiss-pipeline") dismissPipeline();
});

// Filtering is client-side against already-loaded rows: no request per keystroke.
dom.productsSearch.addEventListener("input", (e) => {
  state.productFilter = e.target.value.trim();
  renderProducts();
});
dom.ordersSearch.addEventListener("input", (e) => {
  state.orderFilter = e.target.value.trim();
  renderOrders();
});

document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (dom.productForm.elements.mode.value === "edit") setFormMode(dom.productForm, "create");
  if (dom.orderForm.elements.mode.value === "edit") setFormMode(dom.orderForm, "create");
});

dom.themeToggle.addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  localStorage.setItem("flocicart-theme", next);
});

/* --------------------------------- boot ---------------------------------- */

async function main() {
  document.documentElement.dataset.theme =
    localStorage.getItem("flocicart-theme") ||
    (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");

  if (!apiBase) {
    dom.health.textContent = "No API base";
    dom.health.className = "pill pill-bad";
    const message =
      "No API base configured. Run scripts/apigw/create-http-api.sh, then scripts/s3/upload.sh.";
    dom.productsBody.innerHTML = `<tr><td colspan="4" class="empty">${message}</td></tr>`;
    dom.ordersBody.innerHTML = `<tr><td colspan="5" class="empty">${message}</td></tr>`;
    toast(message, "error");
    return;
  }

  dom.productsBody.innerHTML = skeleton(4);
  dom.ordersBody.innerHTML = skeleton(5);
  await Promise.all([checkHealth(), loadProducts(), loadOrders()]);
}

main();
