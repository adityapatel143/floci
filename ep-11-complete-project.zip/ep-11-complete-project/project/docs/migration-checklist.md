# Migration Checklist

1. AWS identity and region
- `cp .env.aws.example .env`, fill in `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`,
	`AWS_DEFAULT_REGION` (or `AWS_SESSION_TOKEN` for temporary/SSO credentials instead).
	Every script loads `.env` on its own now - nothing to `export`.
- Do not add an `AWS_ENDPOINT_URL` line to `.env` - its mere presence is what every
	script uses to mean "target Floci instead".
- Run `npm run preflight:aws` and confirm it passes.

2. Core names and identifiers
- Everything below is optional and defaults to the names in `scripts/lib/floci.sh` -
	only set one in `.env` if that name is already taken in your account:
	`LAMBDA_FUNCTION`, `WORKER_FUNCTION_NAME`, `HTTP_API_NAME`, `CATALOG_TABLE`,
	`DB_INSTANCE_ID`, `CACHE_CLUSTER_ID`, `ORDERS_QUEUE_NAME`, `ORDERS_DLQ_NAME`,
	`ORDER_EVENTS_TOPIC`, `NOTIFICATIONS_QUEUE_NAME`, `ANALYTICS_QUEUE_NAME`,
	`WEB_BUCKET`, `APP_ROLE_NAME`.
- `WEB_BUCKET` is the one exception worth knowing about: S3 bucket names are unique
	across every AWS account, not one fixed name here, so it defaults to
	`flocicart-web-<your-account-id>` (resolved automatically via STS every time, not
	cached - a cached id would risk going stale after switching between Floci and real
	AWS) instead of a plain constant - this is what lets 20 students deploy the same
	unmodified project without colliding on one global bucket name. Only set
	`WEB_BUCKET` yourself if that generated name is somehow still taken.
- For the DNS step, `apply-cloudfront-record.sh` takes its own variables instead:
	`ZONE_ID`, `APP_DOMAIN`, `CLOUDFRONT_DOMAIN` (see step 6).

3. IAM role and policy
- Run `./scripts/iam/setup.sh` to create/update the Lambda execution role.
- Nothing to export: it prints the role ARN and saves it to `.floci/role-arn`; `lambda/deploy.sh` looks it up by name (`APP_ROLE_NAME`) again at deploy time, so it always uses the current role even if the ARN changes.
- Review the generated role policy scope (`infra/iam/flocicart-app-policy.json`) before production rollout.

4. Data and messaging resources
- Provision S3, DynamoDB, SQS, SNS, RDS, and ElastiCache via bootstrap.
- For RDS/Redis, verify endpoint readiness before traffic cutover.

5. API and app wiring
- Deploy Lambda and API Gateway via bootstrap.
- Confirm `API_BASE` from `dist/bootstrap.env`.
- Set frontend `window.FLOCICART_API_BASE` to production API URL.
- Order processing is a second Lambda (`functions/ordersWorker`), deployed and wired to
	the orders queue by `./scripts/lambda/deploy-worker.sh` (also part of bootstrap) - no
	`npm run worker` terminal to keep running in production.

6. DNS and distribution
- Create/confirm the CloudFront distribution (`npm run cdn:create`).
- Do not run `dns:setup` against real AWS: it always creates a brand-new hosted zone, which is the wrong tool if you already own the zone for your domain.
- Point your existing zone at the distribution instead, with `./scripts/route53/apply-cloudfront-record.sh` (needs `ZONE_ID`, `APP_DOMAIN`, `CLOUDFRONT_DOMAIN` - see step 2). It only adds one record and leaves the rest of the zone alone.

7. CI and operational controls
- Configure GitHub secrets/variables used by `.github/workflows/flocicart-ci.yml`.
- Use manual `workflow_dispatch` for AWS smoke runs.
- Add CloudWatch alarms, budgets, and retention policies.

8. Promotion model
- Separate staging and production accounts or environments.
- Version artifacts and use change approvals for production promotion.

9. Tearing down
- `npm run cleanup` deletes every resource this stack creates, on Floci or real AWS,
	depending on `AWS_ENDPOINT_URL` - the same script, the same resource list.
- Against real AWS it refuses to run unless you also set `CONFIRM_DELETE_REAL_AWS=yes`,
	so an empty `AWS_ENDPOINT_URL` can never delete production resources by accident.
- CloudFront will not delete until disabled and redeployed (5-20 minutes) - re-run
	cleanup after that finishes. RDS/ElastiCache keep billing briefly after cleanup
	returns, since AWS deletes them asynchronously.
- If you pointed a zone you already own at the distribution with
	`apply-cloudfront-record.sh`, cleanup does not remove that record - it only ever
	touches a hosted zone it created itself. Remove the CNAME by hand once the
	distribution is gone.

