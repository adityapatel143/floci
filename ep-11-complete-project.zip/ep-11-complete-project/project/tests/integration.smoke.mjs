// Integration smoke test: exercises the deployed stack over HTTP, the same way a client
// would. Nothing is mocked - if this passes, the stack is genuinely wired up.
//
// Run with:  npm run test:integration
//
// It is deliberately a *smoke* test: broad and shallow. It answers "is the system alive
// and connected", not "is every branch of the code correct".

import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";
import "../src/config/loadEnv.mjs";
import { ListBucketsCommand } from "@aws-sdk/client-s3";
import { s3 } from "../src/config/awsClients.mjs";
import { WEB_BUCKET } from "../src/config/resources.mjs";

// The API URL is generated at bootstrap time, so it is read rather than hardcoded.
// .floci/api-url is written by the API script; dist/bootstrap.env by the bootstrap.
function resolveApiBase() {
  if (process.env.API_BASE) {
    return process.env.API_BASE;
  }

  if (existsSync(".floci/api-url")) {
    return readFileSync(".floci/api-url", "utf8").trim();
  }

  if (existsSync("dist/bootstrap.env")) {
    const match = readFileSync("dist/bootstrap.env", "utf8").match(/^API_BASE=(.*)$/m);
    if (match) {
      return match[1].trim();
    }
  }

  return "";
}

const apiBase = resolveApiBase();
assert.ok(apiBase, "No API base found. Run `npm run bootstrap` first, or set API_BASE.");

// Ids are unique per run so the suite can run repeatedly against the same stack without
// colliding with the primary keys it wrote last time.
const runId = Date.now().toString();
const productId = `p13-${runId}`;
const orderId = `o13-${runId}`;

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// A just-created API is briefly unroutable and a cold Lambda can return 502, so retry
// the transient cases. Anything else fails immediately - retrying a 400 is pointless.
async function requestJson(method, path, body, attempts = 20) {
  let lastStatus = 0;
  let lastText = "";

  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    const res = await fetch(`${apiBase}${path}`, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined
    });

    lastStatus = res.status;
    lastText = await res.text();

    if (res.ok) {
      return lastText ? JSON.parse(lastText) : {};
    }

    const transient =
      res.status === 502 ||
      (res.status === 404 && lastText.includes("Invalid API id specified"));

    if (!transient || attempt === attempts) {
      break;
    }

    await delay(1000);
  }

  assert.fail(`${method} ${path} failed: ${lastStatus} ${lastText}`);
}

test("static site bucket exists", async () => {
  const out = await s3.send(new ListBucketsCommand({}));
  const names = (out.Buckets || []).map((b) => b.Name);
  assert.ok(names.includes(WEB_BUCKET), `expected bucket ${WEB_BUCKET}, got ${names}`);
});

test("API is reachable", async () => {
  const health = await requestJson("GET", "/health");
  assert.equal(health.ok, true);
});

test("POST /products writes to DynamoDB", async () => {
  const created = await requestJson("POST", "/products", {
    productId,
    name: "Smoke Product",
    price: 42
  });
  assert.equal(created.ok, true);
  assert.equal(created.product.productId, productId);
});

test("POST /products rejects bad input with 400", async () => {
  const res = await fetch(`${apiBase}/products`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name: "no id" })
  });
  // Validation is part of the contract, so a regression here should fail the build.
  assert.equal(res.status, 400);
});

test("GET /products returns the product just written", async () => {
  const products = await requestJson("GET", "/products");
  assert.ok(Array.isArray(products.items));
  assert.ok(products.items.some((item) => item.productId === productId));
});

test("POST /orders writes to PostgreSQL and enqueues", async () => {
  const created = await requestJson("POST", "/orders", { orderId, productId, quantity: 1 });
  assert.equal(created.ok, true);
  assert.equal(created.queued, true, "order was stored but not enqueued - check SQS");
});

test("GET /orders returns the order just written", async () => {
  const orders = await requestJson("GET", "/orders");
  assert.ok(Array.isArray(orders.items));
  assert.ok(orders.items.some((item) => item.order_id === orderId));
});

test("unknown routes return 404", async () => {
  const res = await fetch(`${apiBase}/definitely-not-a-route`);
  assert.equal(res.status, 404);
});
