// Consumes order jobs from SQS and publishes an event when each one is done.
//
// The worker is now both a consumer (SQS) and a publisher (SNS). It has no idea who
// listens to the event it publishes - notifications and analytics are subscribed to the
// topic, not wired into this file.
//
// This is now the LOCAL-ONLY / optional path: it exists so you can watch order
// processing happen live against Floci without deploying anything. On real AWS (and
// optionally on Floci too), scripts/lambda/deploy-worker.sh deploys the same logic as
// its own Lambda, triggered directly by SQS - no terminal needs to stay open, and
// nothing here needs to change to get that.
//
// Run it in its own terminal:  npm run worker

import "../src/config/loadEnv.mjs";
import { pullOrderJobs, ackOrderJob, getOrdersQueueUrl } from "../src/queues/ordersQueue.mjs";
import { publishOrderPlaced } from "../src/events/orderEvents.mjs";

let running = true;

// Ctrl+C sets the flag instead of killing the process mid-message, so the job in flight
// finishes and gets acknowledged rather than being redelivered to the next worker.
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => {
    console.log(`\n${signal} received - finishing current batch, then stopping.`);
    running = false;
  });
}

async function processOrder(payload) {
  // Stand-in for the real work: charging a card, updating stock, and so on.
  console.log("processed", payload);

  // Published after the work succeeded, so subscribers only ever see completed orders.
  const messageId = await publishOrderPlaced(payload);
  console.log("published order.placed", messageId);
}

const queueUrl = await getOrdersQueueUrl();
console.log(`Worker started. Polling ${queueUrl}`);
console.log("Press Ctrl+C to stop.\n");

while (running) {
  let messages;

  try {
    messages = await pullOrderJobs();
  } catch (err) {
    // A transient SQS error must not kill the worker; back off briefly and retry.
    console.error("receive failed:", err.message);
    await new Promise((resolve) => setTimeout(resolve, 2000));
    continue;
  }

  for (const message of messages) {
    const attempt = Number(message.Attributes?.ApproximateReceiveCount || 1);

    try {
      const payload = JSON.parse(message.Body || "{}");
      await processOrder(payload);
      // Acknowledge only after both the work and the publish succeeded.
      await ackOrderJob(message.ReceiptHandle);
    } catch (err) {
      // Do NOT delete: SQS redelivers after the visibility timeout, and the redrive
      // policy moves the message to the DLQ after 3 attempts.
      console.error(`message failed (attempt ${attempt}):`, err.message);
    }
  }
}

console.log("Worker stopped.");
