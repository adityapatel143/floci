// Domain errors the handler maps onto HTTP status codes. Keeping them here means the
// repositories never need to know they are being called from Lambda.

export class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = "ValidationError";
  }
}

// Lets an update or delete against a missing row surface as 404 rather than 500.
export class NotFoundError extends Error {
  constructor(message) {
    super(message);
    this.name = "NotFoundError";
  }
}
