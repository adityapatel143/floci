// Cache-aside layer in front of the catalog repository, backed by ElastiCache/Redis.
//
// Two rules hold this together:
//   1. The cache is optional. `redis` is null when REDIS_HOST was never injected, and
//      every command is wrapped so an unreachable node degrades to a database read
//      rather than a 500. A cache outage must never become an outage.
//   2. Every write invalidates. Without that, GET /products keeps serving a catalog
//      that no longer matches DynamoDB until the TTL expires.
//
// getProductsCached reports which of the two paths served the request as `source`, which
// the handler lifts into the response `meta` so the storefront can show HIT or MISS.

import { redis, cacheTtlSeconds } from "../cache/redis.mjs";
import {
  createProduct,
  deleteProduct,
  getProduct,
  listProducts,
  updateProduct
} from "../repositories/catalogDdb.mjs";

const LIST_KEY = "products:all";

// ioredis is configured to fail fast (connectTimeout 300ms, no offline queue, no retry),
// so a dead node rejects almost immediately - but it still rejects, and an unhandled
// rejection here would fail a request the database could have served. Swallow and log.
async function safe(operation, fn, fallback = null) {
  if (!redis) return fallback;
  try {
    return await fn();
  } catch (err) {
    console.error(`cache ${operation} failed`, err.message);
    return fallback;
  }
}

export async function invalidateProducts() {
  await safe("invalidate", () => redis.del(LIST_KEY));
}

export async function getProductsCached() {
  const cached = await safe("get", () => redis.get(LIST_KEY));

  if (cached) {
    try {
      return { items: JSON.parse(cached), source: "cache" };
    } catch {
      // A key that will not parse is worse than no key: drop it and read through.
      console.error("cache get failed", "cached value was not valid JSON");
      await invalidateProducts();
    }
  }

  const items = await listProducts();

  // SET with EX in one command, so the key can never be written without a TTL - the
  // backstop that bounds staleness if an invalidation is ever lost.
  await safe("set", () => redis.set(LIST_KEY, JSON.stringify(items), "EX", cacheTtlSeconds));

  return { items, source: "origin" };
}

// Single-item reads go straight to DynamoDB: a GetItem on the primary key is already a
// single-digit-millisecond call, so caching it would add invalidation risk for no gain.
export const getProductById = (productId) => getProduct(productId);

// The invalidate-after-write ordering is deliberate. Invalidating first would leave a
// window where a concurrent read repopulates the key from the pre-write state and then
// holds it for the full TTL.
export async function createProductAndInvalidate(input) {
  const product = await createProduct(input);
  await invalidateProducts();
  return product;
}

export async function updateProductAndInvalidate(productId, input) {
  const product = await updateProduct(productId, input);
  await invalidateProducts();
  return product;
}

export async function deleteProductAndInvalidate(productId) {
  const product = await deleteProduct(productId);
  await invalidateProducts();
  return product;
}
