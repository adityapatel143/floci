// Tracks real per-order progress across every Lambda an order passes through, so the
// storefront's pipeline UI can show what actually happened instead of a fixed timeline.
//
// One top-level attribute per stage, not a nested map: UpdateItem can SET a top-level
// attribute on an item that does not exist yet (it creates the item), but SET-ing into
// a nested map path requires that map to already exist - and whichever stage writes
// first will not find one.

import { GetItemCommand, UpdateItemCommand } from "@aws-sdk/client-dynamodb";
import { ddb } from "../config/awsClients.mjs";
import { ORDER_PIPELINE_TABLE } from "../config/resources.mjs";

const STAGES = ["db", "queue", "worker", "fanout", "notifications", "analytics"];

// Best-effort telemetry: every caller wraps this in its own catch, because a write
// failure here must never break real order processing.
export async function recordStage(orderId, stage, status, errorMessage) {
  if (!orderId || !STAGES.includes(stage)) return;

  const value = {
    M: {
      status: { S: status },
      at: { S: new Date().toISOString() },
      ...(errorMessage ? { error: { S: String(errorMessage).slice(0, 500) } } : {})
    }
  };

  await ddb.send(
    new UpdateItemCommand({
      TableName: ORDER_PIPELINE_TABLE,
      Key: { orderId: { S: orderId } },
      UpdateExpression: "SET #stage = :value",
      ExpressionAttributeNames: { "#stage": stage },
      ExpressionAttributeValues: { ":value": value }
    })
  );
}

function fromAttr(attr) {
  if (!attr?.M) return null;
  return {
    status: attr.M.status?.S,
    at: attr.M.at?.S,
    ...(attr.M.error?.S ? { error: attr.M.error.S } : {})
  };
}

// Missing stages just mean "not reached yet", not an error - a freshly placed order
// legitimately has no worker/fan-out records until those Lambdas run.
export async function getPipeline(orderId) {
  const out = await ddb.send(
    new GetItemCommand({ TableName: ORDER_PIPELINE_TABLE, Key: { orderId: { S: orderId } } })
  );

  const item = out.Item || {};
  const stages = {};
  for (const stage of STAGES) {
    const value = fromAttr(item[stage]);
    if (value) stages[stage] = value;
  }
  return stages;
}
