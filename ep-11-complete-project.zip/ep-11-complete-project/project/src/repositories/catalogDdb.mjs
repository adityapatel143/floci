// Product catalog persistence, backed by DynamoDB.
//
// Caching is layered on top in src/services/productsCached.mjs, so this file stays the
// single source of truth. Covers the full CRUD surface: create, read one, read all,
// update and delete.

import {
  DeleteItemCommand,
  GetItemCommand,
  PutItemCommand,
  ScanCommand,
  UpdateItemCommand
} from "@aws-sdk/client-dynamodb";
import { ddb } from "../config/awsClients.mjs";
import { CATALOG_TABLE } from "../config/resources.mjs";
import { NotFoundError, ValidationError } from "../errors.mjs";

// DynamoDB rejects empty strings in a key and stores numbers as strings, so validate
// here rather than discovering it as a 500 at request time.
function validate({ productId, name, price }) {
  if (typeof productId !== "string" || productId.trim() === "") {
    throw new ValidationError("productId is required and must be a non-empty string");
  }
  if (typeof name !== "string" || name.trim() === "") {
    throw new ValidationError("name is required and must be a non-empty string");
  }
  if (typeof price !== "number" || !Number.isFinite(price) || price < 0) {
    throw new ValidationError("price is required and must be a non-negative number");
  }
  return { productId: productId.trim(), name: name.trim(), price };
}

function requireId(productId) {
  if (typeof productId !== "string" || productId.trim() === "") {
    throw new ValidationError("productId is required and must be a non-empty string");
  }
  return productId.trim();
}

const toProduct = (item) =>
  item ? { productId: item.productId?.S, name: item.name?.S, price: Number(item.price?.N) } : null;

export async function createProduct(input) {
  const product = validate(input);

  await ddb
    .send(
      new PutItemCommand({
        TableName: CATALOG_TABLE,
        // PutItem overwrites an existing item with the same key, which makes it an upsert.
        // attribute_not_exists turns it back into a strict create, so POST /products can
        // report a duplicate id as the caller's mistake instead of silently replacing a row.
        ConditionExpression: "attribute_not_exists(productId)",
        Item: {
          productId: { S: product.productId },
          name: { S: product.name },
          price: { N: String(product.price) }
        }
      })
    )
    .catch((err) => {
      if (err?.name === "ConditionalCheckFailedException") {
        throw new ValidationError(`Product ${product.productId} already exists`);
      }
      throw err;
    });

  return product;
}

export async function getProduct(productId) {
  const id = requireId(productId);

  const out = await ddb.send(
    new GetItemCommand({ TableName: CATALOG_TABLE, Key: { productId: { S: id } } })
  );

  const product = toProduct(out.Item);
  if (!product) throw new NotFoundError(`Product ${id} not found`);
  return product;
}

export async function listProducts() {
  // Scan reads the whole table. Fine for a demo catalog, but on a real table you would
  // use Query against a key or an index.
  const out = await ddb.send(new ScanCommand({ TableName: CATALOG_TABLE }));

  return (out.Items || []).map(toProduct);
}

export async function updateProduct(productId, input) {
  const id = requireId(productId);
  // The id in the path wins; a mismatched id in the body cannot move the item.
  const product = validate({ ...input, productId: id });

  const out = await ddb
    .send(
      new UpdateItemCommand({
        TableName: CATALOG_TABLE,
        Key: { productId: { S: id } },
        // Without this, UpdateItem would happily create the item it was asked to update.
        ConditionExpression: "attribute_exists(productId)",
        UpdateExpression: "SET #n = :name, price = :price",
        // "name" is a DynamoDB reserved word, so it has to go through an alias.
        ExpressionAttributeNames: { "#n": "name" },
        ExpressionAttributeValues: {
          ":name": { S: product.name },
          ":price": { N: String(product.price) }
        },
        ReturnValues: "ALL_NEW"
      })
    )
    .catch((err) => {
      if (err?.name === "ConditionalCheckFailedException") {
        throw new NotFoundError(`Product ${id} not found`);
      }
      throw err;
    });

  return toProduct(out.Attributes);
}

export async function deleteProduct(productId) {
  const id = requireId(productId);

  const out = await ddb
    .send(
      new DeleteItemCommand({
        TableName: CATALOG_TABLE,
        Key: { productId: { S: id } },
        // DeleteItem is idempotent and succeeds on a missing key; the condition is what
        // lets the API answer 404 for a delete of something that was never there.
        ConditionExpression: "attribute_exists(productId)",
        ReturnValues: "ALL_OLD"
      })
    )
    .catch((err) => {
      if (err?.name === "ConditionalCheckFailedException") {
        throw new NotFoundError(`Product ${id} not found`);
      }
      throw err;
    });

  return toProduct(out.Attributes);
}
