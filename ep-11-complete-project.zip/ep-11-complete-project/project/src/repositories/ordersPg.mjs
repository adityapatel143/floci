// Order persistence, backed by PostgreSQL on RDS.
//
// Covers the full CRUD surface. Unlike the catalog there is no cache in front of this:
// orders are read back immediately after a write, so a stale read would be visible.

import pg from "pg";
import { NotFoundError, ValidationError } from "../errors.mjs";

const { Pool } = pg;

// A pool, not a client, and created at module scope on purpose: Lambda reuses the module
// between warm invocations, so connections survive instead of being reopened per request.
const pool = new Pool({
  host: process.env.PGHOST || "127.0.0.1",
  port: Number(process.env.PGPORT || 5432),
  user: process.env.PGUSER || "postgres",
  password: process.env.PGPASSWORD || "postgres",
  database: process.env.PGDATABASE || "postgres",
  max: 2,
  idleTimeoutMillis: 10_000,
  // Fail fast instead of letting API Gateway time out with no explanation.
  connectionTimeoutMillis: 5_000,
  // Real RDS enforces SSL by default (rds.force_ssl) and rejects a plaintext connection
  // with "no pg_hba.conf entry ... no encryption"; Floci's Postgres requires neither SSL
  // nor a certificate to validate against. rejectUnauthorized:false accepts RDS's
  // certificate without validating the chain - fine for this demo, but production
  // should verify it against the Amazon RDS CA bundle instead.
  ssl: process.env.AWS_ENDPOINT_URL ? false : { rejectUnauthorized: false }
});

// An idle pool client that errors emits on the pool itself; without a listener Node
// treats it as an unhandled error and exits.
pool.on("error", (err) => {
  console.error("pg pool error", err.message);
});

// One list of columns, so every query returns the same shape to the frontend.
const COLUMNS = "order_id, product_id, quantity, created_at";

export async function initOrdersTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      order_id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL,
      quantity INTEGER NOT NULL CHECK (quantity > 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

function validate({ orderId, productId, quantity }) {
  if (typeof orderId !== "string" || orderId.trim() === "") {
    throw new ValidationError("orderId is required and must be a non-empty string");
  }
  if (typeof productId !== "string" || productId.trim() === "") {
    throw new ValidationError("productId is required and must be a non-empty string");
  }
  if (!Number.isInteger(quantity) || quantity <= 0) {
    throw new ValidationError("quantity is required and must be a positive integer");
  }
  return { orderId: orderId.trim(), productId: productId.trim(), quantity };
}

function requireOrderId(orderId) {
  if (typeof orderId !== "string" || orderId.trim() === "") {
    throw new ValidationError("orderId is required and must be a non-empty string");
  }
  return orderId.trim();
}

export async function createOrder(input) {
  const order = validate(input);

  try {
    // Parameterised query: the values never become part of the SQL text.
    const out = await pool.query(
      `INSERT INTO orders (order_id, product_id, quantity)
       VALUES ($1, $2, $3)
       RETURNING ${COLUMNS}`,
      [order.orderId, order.productId, order.quantity]
    );
    return out.rows[0];
  } catch (err) {
    // 23505 = unique_violation. A duplicate id is the caller's mistake, not a server fault.
    if (err?.code === "23505") {
      throw new ValidationError(`Order ${order.orderId} already exists`);
    }
    throw err;
  }
}

export async function getOrder(orderId) {
  const id = requireOrderId(orderId);

  const out = await pool.query(`SELECT ${COLUMNS} FROM orders WHERE order_id = $1`, [id]);
  if (out.rowCount === 0) throw new NotFoundError(`Order ${id} not found`);
  return out.rows[0];
}

export async function listOrders() {
  const out = await pool.query(
    `SELECT ${COLUMNS}
     FROM orders
     ORDER BY created_at DESC
     LIMIT 100`
  );
  return out.rows;
}

// A partial update: only the fields present in `input` are touched, so PUT with just a
// quantity does not blank out the product. created_at is never rewritten - it records
// when the order was placed, not when it was last edited.
export async function updateOrder(orderId, input = {}) {
  const id = requireOrderId(orderId);

  const sets = [];
  const values = [];

  if (input.productId !== undefined) {
    if (typeof input.productId !== "string" || input.productId.trim() === "") {
      throw new ValidationError("productId must be a non-empty string");
    }
    values.push(input.productId.trim());
    sets.push(`product_id = $${values.length}`);
  }

  if (input.quantity !== undefined) {
    if (!Number.isInteger(input.quantity) || input.quantity <= 0) {
      throw new ValidationError("quantity must be a positive integer");
    }
    values.push(input.quantity);
    sets.push(`quantity = $${values.length}`);
  }

  if (sets.length === 0) {
    throw new ValidationError("Provide at least one of productId or quantity to update");
  }

  values.push(id);
  const out = await pool.query(
    `UPDATE orders SET ${sets.join(", ")}
     WHERE order_id = $${values.length}
     RETURNING ${COLUMNS}`,
    values
  );

  if (out.rowCount === 0) throw new NotFoundError(`Order ${id} not found`);
  return out.rows[0];
}

export async function deleteOrder(orderId) {
  const id = requireOrderId(orderId);

  const out = await pool.query(`DELETE FROM orders WHERE order_id = $1 RETURNING ${COLUMNS}`, [id]);
  if (out.rowCount === 0) throw new NotFoundError(`Order ${id} not found`);
  return out.rows[0];
}
