// Publishes domain events to SNS.
//
// The difference from SQS in one line: a queue message goes to exactly one consumer, an
// SNS message goes to every subscriber. The publisher below does not know or care how
// many that is - subscribers are added with a CLI command, not a code change.

import { PublishCommand, ListTopicsCommand } from "@aws-sdk/client-sns";
import { sns } from "../config/awsClients.mjs";
import { ORDER_EVENTS_TOPIC } from "../config/resources.mjs";

// The ARN is assigned by SNS, so it must be looked up rather than guessed. Deploy
// scripts inject ORDER_EVENTS_TOPIC_ARN directly (see scripts/lambda/deploy-worker.sh),
// so this lookup is normally a cold-start-only fallback, not something called on every
// invocation. It uses ListTopics (read-only), not CreateTopic: an application function
// should never have permission to create the infrastructure it depends on - the topic
// is provisioned once, by scripts/sns/setup.sh.
let topicArnPromise;

export function getOrderEventsTopicArn() {
  if (process.env.ORDER_EVENTS_TOPIC_ARN) {
    return Promise.resolve(process.env.ORDER_EVENTS_TOPIC_ARN);
  }

  if (!topicArnPromise) {
    topicArnPromise = sns
      .send(new ListTopicsCommand({}))
      .then((out) => {
        const topic = out.Topics?.find((t) => t.TopicArn?.endsWith(`:${ORDER_EVENTS_TOPIC}`));
        if (!topic) {
          throw new Error(`SNS topic ${ORDER_EVENTS_TOPIC} not found - run scripts/sns/setup.sh first`);
        }
        return topic.TopicArn;
      })
      .catch((err) => {
        topicArnPromise = undefined; // allow a retry
        throw err;
      });
  }

  return topicArnPromise;
}

export async function publishOrderPlaced(order) {
  const TopicArn = await getOrderEventsTopicArn();

  const out = await sns.send(
    new PublishCommand({
      TopicArn,
      // MessageAttributes are what subscribers filter on. A subscriber that only cares
      // about cancellations can filter on eventType instead of receiving everything
      // and discarding most of it.
      Subject: "order.placed",
      MessageAttributes: {
        eventType: { DataType: "String", StringValue: "order.placed" }
      },
      Message: JSON.stringify({
        eventType: "order.placed",
        occurredAt: new Date().toISOString(),
        order
      })
    })
  );

  return out.MessageId;
}
