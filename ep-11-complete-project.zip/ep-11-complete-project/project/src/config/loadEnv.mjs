// Loads .env for scripts that run on your machine (bootstrap's Node helpers, the
// worker, tests) - the deployed Lambda never imports this, since its config comes from
// the environment variables set at deploy time, not a local file that won't exist there.
import dotenv from "dotenv";

// override: true so an edited .env always wins, matching scripts/lib/floci.sh's rule.
dotenv.config({ override: true });
