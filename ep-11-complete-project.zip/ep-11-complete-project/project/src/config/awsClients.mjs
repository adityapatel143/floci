// Central place where every AWS SDK v3 client is constructed.
//
// Set AWS_ENDPOINT_URL to point these at Floci. Leave it unset and `endpoint` is
// `undefined`, which makes these ordinary real-AWS clients: they resolve the real
// regional endpoints and use the SDK's normal credential chain (a Lambda's execution
// role, in production) - nothing below has to change for that to work.
import { S3Client } from "@aws-sdk/client-s3";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { SQSClient } from "@aws-sdk/client-sqs";
import { SNSClient } from "@aws-sdk/client-sns";

export const endpoint = process.env.AWS_ENDPOINT_URL || undefined;
// AWS_DEFAULT_REGION is Floci-only (deploy.sh injects it there); a real Lambda's
// runtime sets AWS_REGION itself and rejects AWS_DEFAULT_REGION as a reserved key, so
// it never gets injected there - check both, in that order.
export const region = process.env.AWS_DEFAULT_REGION || process.env.AWS_REGION || "us-east-1";

// Floci checks that a signature is present, not that the key is real, so dummy values
// work - but only pass them, and only override the endpoint, when Floci is actually in
// play. Real AWS must never get a hardcoded key: that would both be redundant (the
// execution role already provides credentials) and leak whatever key is in scope here.
const floci = endpoint
  ? {
      endpoint,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || "test",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "test"
      }
    }
  : {};

const shared = { region, ...floci };

export const s3 = new S3Client({
  ...shared,
  // Path-style is required for Floci (bucket.localhost does not resolve); real AWS
  // uses its own default (virtual-hosted style) when this is left unset.
  ...(endpoint ? { forcePathStyle: true } : {})
});

export const ddb = new DynamoDBClient(shared);
export const sqs = new SQSClient(shared);
export const sns = new SNSClient(shared);
