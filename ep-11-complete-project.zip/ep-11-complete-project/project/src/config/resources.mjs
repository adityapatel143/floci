// Names of the AWS resources this episode creates.
// Shared so every script and the cleanup step can never drift apart.

import { readFileSync } from "node:fs";

// S3 bucket names are unique across every AWS account, not just this one, so a fixed
// default would make the second person to deploy this project fail with
// BucketAlreadyExists on a bucket they don't even own. scripts/lib/floci.sh's
// resolve_web_bucket() picks a per-account default and saves it here; read the exact
// same value rather than resolving it a second, possibly different, way.
function readGeneratedState(name) {
  try {
    return readFileSync(`.floci/${name}`, "utf8").trim();
  } catch {
    return "";
  }
}

export const SMOKE_BUCKET = process.env.SMOKE_BUCKET || "flocicart-ep01-smoke";
export const LAMBDA_FUNCTION = process.env.LAMBDA_FUNCTION || "flocicart-api";
export const HTTP_API_NAME = process.env.HTTP_API_NAME || "flocicart-http";
export const HTTP_API_STAGE = process.env.HTTP_API_STAGE || "dev";
export const CATALOG_TABLE = process.env.CATALOG_TABLE || "flocicart-products";
export const DB_INSTANCE_ID = process.env.DB_INSTANCE_ID || "flocicart-pg";
export const CACHE_CLUSTER_ID = process.env.CACHE_CLUSTER_ID || "flocicart-redis";
export const ORDERS_QUEUE_NAME = process.env.ORDERS_QUEUE_NAME || "orders-queue";
export const ORDERS_DLQ_NAME = process.env.ORDERS_DLQ_NAME || "orders-queue-dlq";

// One topic, many subscribers. The queues below are subscribers, not the topic itself -
// adding a third one later requires no change to the publisher.
export const ORDER_EVENTS_TOPIC = process.env.ORDER_EVENTS_TOPIC || "order-events";
export const NOTIFICATIONS_QUEUE_NAME =
  process.env.NOTIFICATIONS_QUEUE_NAME || "order-events-notifications";
export const ANALYTICS_QUEUE_NAME =
  process.env.ANALYTICS_QUEUE_NAME || "order-events-analytics";

// Real per-order status for each pipeline stage (db write, enqueue, worker, fan-out,
// both downstream consumers) - what the storefront's pipeline animation reads instead
// of guessing on a fixed timeline.
export const ORDER_PIPELINE_TABLE =
  process.env.ORDER_PIPELINE_TABLE || "flocicart-order-pipeline";

// Bucket holding the static storefront that CloudFront serves.
export const WEB_BUCKET =
  process.env.WEB_BUCKET || readGeneratedState("web-bucket-name") || "flocicart-web";

// DNS names in front of the distribution.
export const DNS_ZONE = process.env.DNS_ZONE || "flocicart.local";
export const DNS_RECORD = process.env.DNS_RECORD || "app.flocicart.local";
