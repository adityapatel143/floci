// Consumes order.placed events fanned out via SNS to the notifications queue.
//
// Stand-in for actually sending a customer email/SMS - the point of deploying this is
// proving the fan-out genuinely reaches a second, independent subscriber, not just the
// one queue SNS was first demoed with.

import { recordStage } from "../../src/repositories/orderPipeline.mjs";

// RawMessageDelivery is false (see scripts/sns/setup.sh), so the SQS body is the full
// SNS envelope - the actual event is JSON-encoded inside its Message field, not the body
// itself.
function unwrap(body) {
  const envelope = JSON.parse(body || "{}");
  return JSON.parse(envelope.Message || "{}");
}

// Best-effort telemetry for the storefront's pipeline UI - a write failure here must
// never turn a message that genuinely succeeded into a reported failure, or vice versa.
const trackStage = (orderId, status, err) =>
  recordStage(orderId, "notifications", status, err?.message).catch(() => {});

export const handler = async (event) => {
  const batchItemFailures = [];

  for (const record of event.Records || []) {
    let orderId;
    try {
      const { eventType, order } = unwrap(record.body);
      orderId = order?.order_id;
      console.log(
        "notification sent",
        JSON.stringify({ eventType, orderId, productId: order?.product_id })
      );
      await trackStage(orderId, "ok");
    } catch (err) {
      console.error(`message ${record.messageId} failed:`, err.message);
      await trackStage(orderId, "failed", err);
      batchItemFailures.push({ itemIdentifier: record.messageId });
    }
  }

  return { batchItemFailures };
};
