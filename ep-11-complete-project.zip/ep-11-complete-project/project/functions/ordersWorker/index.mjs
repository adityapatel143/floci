// Consumes order jobs directly from SQS via an event source mapping, and publishes an
// event when each one is done.
//
// This replaces running workers/ordersWorker.mjs by hand in a terminal: on real AWS
// nothing should depend on a developer's laptop staying on and polling forever. Lambda's
// own SQS integration does the polling instead, scales consumers with queue depth, and
// keeps working whether or not anyone is watching a terminal.
//
// Reports failures per-message (ReportBatchItemFailures - enabled on the event source
// mapping in scripts/lambda/deploy-worker.sh) instead of failing the whole batch, so one
// bad message does not force SQS to redeliver messages that already succeeded. A failed
// message is retried up to the queue's maxReceiveCount, then moved to its DLQ, same as
// the old standalone worker.

import { publishOrderPlaced } from "../../src/events/orderEvents.mjs";
import { recordStage } from "../../src/repositories/orderPipeline.mjs";

// Best-effort telemetry for the storefront's pipeline UI - a write failure here must
// never turn a message that genuinely succeeded into a reported failure, or vice versa.
const trackStage = (orderId, stage, status, err) =>
  recordStage(orderId, stage, status, err?.message).catch(() => {});

export const handler = async (event) => {
  const batchItemFailures = [];

  for (const record of event.Records || []) {
    let payload;
    try {
      payload = JSON.parse(record.body || "{}");
    } catch (err) {
      console.error(`message ${record.messageId} could not be parsed:`, err.message);
      batchItemFailures.push({ itemIdentifier: record.messageId });
      continue;
    }

    const orderId = payload.order_id;
    try {
      // Stand-in for the real work: charging a card, updating stock, and so on.
      console.log("processed", payload);
      await trackStage(orderId, "worker", "ok");

      const messageId = await publishOrderPlaced(payload);
      console.log("published order.placed", messageId);
      await trackStage(orderId, "fanout", "ok");
    } catch (err) {
      console.error(`message ${record.messageId} failed:`, err.message);
      await trackStage(orderId, "fanout", "failed", err);
      batchItemFailures.push({ itemIdentifier: record.messageId });
    }
  }

  return { batchItemFailures };
};
