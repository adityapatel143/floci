// The FlociCart API Lambda, now handing slow work to a queue.
//
// POST /orders does the minimum that must happen synchronously - validate and store the
// order - and enqueues everything else. The caller gets a 201 without waiting for
// payment, email or stock updates.
//
// Routing is table-driven with path parameters, because the storefront needs
// /products/{productId} and /orders/{orderId} for update and delete.
//
// Every JSON response carries a `meta` block with the handler's own elapsed time and,
// for cached reads, whether the data came from Redis or from the origin store.

import {
  createProductAndInvalidate,
  deleteProductAndInvalidate,
  getProductById,
  getProductsCached,
  updateProductAndInvalidate
} from "../../src/services/productsCached.mjs";
import {
  initOrdersTable,
  createOrder,
  deleteOrder,
  getOrder,
  listOrders,
  updateOrder
} from "../../src/repositories/ordersPg.mjs";
import { enqueueOrderJob } from "../../src/queues/ordersQueue.mjs";
import { recordStage, getPipeline } from "../../src/repositories/orderPipeline.mjs";
import { NotFoundError, ValidationError } from "../../src/errors.mjs";

let ordersReady;

function ensureOrdersTable() {
  if (!ordersReady) {
    // Cache the promise, not the result: two concurrent requests then share one CREATE.
    ordersReady = initOrdersTable().catch((err) => {
      ordersReady = undefined;
      throw err;
    });
  }
  return ordersReady;
}

// The browser calls this from a different origin (S3/CloudFront) than the API. Note that
// when the HTTP API has a CORS configuration, API Gateway answers preflights and strips
// whatever CORS headers we return here - so on real AWS these are effectively belt and
// braces. They matter if the gateway CORS config is ever removed, and locally.
const CORS = {
  "access-control-allow-origin": process.env.CORS_ALLOW_ORIGIN || "*",
  "access-control-allow-headers": "content-type",
  "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS"
};

const json = (statusCode, payload) => ({
  statusCode,
  headers: { "content-type": "application/json", ...CORS },
  body: JSON.stringify(payload)
});

const parseBody = (event) => {
  try {
    return JSON.parse(event?.body || "{}");
  } catch {
    throw new ValidationError("Request body must be valid JSON");
  }
};

/* --------------------------- response metadata ---------------------------- */

// Wall-clock time spent inside the handler: the DynamoDB/Redis/Postgres round trip plus
// our own work, but NOT API Gateway overhead or network transit. The browser measures
// that half itself, and the two are reported separately because the gap between them is
// the interesting part when a response feels slow.
//
// `source` is lifted out of the payload and into `meta` so the cache indicator has one
// shape for every route, whether or not that route reads through a cache.
//
// This travels in the body rather than a custom header on purpose: cross-origin
// JavaScript cannot read a custom response header unless it is named in
// Access-Control-Expose-Headers, and API Gateway's CORS config would have to be changed
// to add it. The body needs no CORS changes at all.
function withMeta(response, startedAt) {
  const serverMs = Number((Number(process.hrtime.bigint() - startedAt) / 1e6).toFixed(1));
  if (!response?.body) return response; // 204 preflight has no body to annotate

  let payload;
  try {
    payload = JSON.parse(response.body);
  } catch {
    return response;
  }
  // Only object payloads have room for a meta key; never reshape an array response.
  if (payload === null || typeof payload !== "object" || Array.isArray(payload)) {
    return response;
  }

  payload.meta = { serverMs, source: payload.source ?? null };
  delete payload.source; // it now lives in meta, so there is one place to read it from
  return { ...response, body: JSON.stringify(payload) };
}

/* -------------------------------- routing --------------------------------- */

// Routes are matched in order. A segment written as ":name" captures that segment and
// hands it to the handler as params.name, already percent-decoded.
const routes = [
  ["GET", "/health", async () => json(200, { ok: true, service: "flocicart-api", now: new Date().toISOString() })],

  // ---- products (DynamoDB, read-through cache) ----
  ["GET", "/products", async () => {
    const out = await getProductsCached();
    return json(200, { ...out, count: out.items.length });
  }],
  ["POST", "/products", async (event) => {
    const product = await createProductAndInvalidate(parseBody(event));
    return json(201, { ok: true, product });
  }],
  ["GET", "/products/:productId", async (_event, { productId }) =>
    json(200, { ok: true, product: await getProductById(productId) })],
  ["PUT", "/products/:productId", async (event, { productId }) =>
    json(200, { ok: true, product: await updateProductAndInvalidate(productId, parseBody(event)) })],
  ["DELETE", "/products/:productId", async (_event, { productId }) =>
    json(200, { ok: true, deleted: await deleteProductAndInvalidate(productId) })],

  // ---- orders (PostgreSQL on RDS) ----
  ["GET", "/orders", async () => {
    await ensureOrdersTable();
    const items = await listOrders();
    return json(200, { items, count: items.length });
  }],
  ["POST", "/orders", async (event) => {
    await ensureOrdersTable();
    const order = await createOrder(parseBody(event));
    // Best-effort telemetry for the storefront's pipeline UI - never let a write here
    // turn an order that is already durable in PostgreSQL into a failed request.
    recordStage(order.order_id, "db", "ok").catch(() => {});

    // The order is already durable in PostgreSQL at this point. If enqueueing fails,
    // the customer should still get their 201 rather than a 500 for an order that was
    // in fact accepted - so report queued:false instead of throwing.
    let queued = true;
    try {
      await enqueueOrderJob(order);
      recordStage(order.order_id, "queue", "ok").catch(() => {});
    } catch (err) {
      queued = false;
      console.error("enqueue failed", err.message);
      recordStage(order.order_id, "queue", "failed", err.message).catch(() => {});
    }

    console.log("order stored", JSON.stringify(order));
    return json(201, { ok: true, order, queued });
  }],
  ["GET", "/orders/:orderId", async (_event, { orderId }) => {
    await ensureOrdersTable();
    return json(200, { ok: true, order: await getOrder(orderId) });
  }],
  ["GET", "/orders/:orderId/pipeline", async (_event, { orderId }) =>
    json(200, { ok: true, orderId, stages: await getPipeline(orderId) })],
  ["PUT", "/orders/:orderId", async (event, { orderId }) => {
    await ensureOrdersTable();
    return json(200, { ok: true, order: await updateOrder(orderId, parseBody(event)) });
  }],
  ["DELETE", "/orders/:orderId", async (_event, { orderId }) => {
    await ensureOrdersTable();
    return json(200, { ok: true, deleted: await deleteOrder(orderId) });
  }]
];

function match(method, path) {
  const parts = path.split("/").filter(Boolean);
  let methodMismatch = false;

  for (const [routeMethod, pattern, handle] of routes) {
    const segments = pattern.split("/").filter(Boolean);
    if (segments.length !== parts.length) continue;

    const params = {};
    const ok = segments.every((segment, i) => {
      if (!segment.startsWith(":")) return segment === parts[i];
      params[segment.slice(1)] = decodeURIComponent(parts[i]);
      return true;
    });
    if (!ok) continue;

    // The path exists but the verb does not: remember it so we can answer 405 rather
    // than a misleading 404 if nothing else matches.
    if (routeMethod !== method) {
      methodMismatch = true;
      continue;
    }
    return { handle, params };
  }

  return { methodMismatch };
}

/* -------------------------------- handler --------------------------------- */

export const handler = async (event) => {
  const startedAt = process.hrtime.bigint();
  const method = event?.requestContext?.http?.method || "INVOKE";
  const stage = event?.requestContext?.stage;
  let path = event?.rawPath || "/";

  // A named (non-$default) HTTP API stage prepends its own name onto every rawPath -
  // "/dev/health", not "/health" - so every route below would otherwise never match on
  // real AWS. Floci's rawPath is already clean, so this never fires there.
  if (stage && stage !== "$default" && (path === `/${stage}` || path.startsWith(`/${stage}/`))) {
    path = path.slice(stage.length + 1) || "/";
  }

  console.log("request", JSON.stringify({ method, path }));

  // Preflight. Note the ANY /{proxy+} route means OPTIONS reaches this Lambda rather
  // than being answered by API Gateway's built-in CORS handling.
  if (method === "OPTIONS") return { statusCode: 204, headers: CORS, body: "" };

  try {
    const { handle, params, methodMismatch } = match(method, path);

    if (!handle) {
      return withMeta(
        methodMismatch
          ? json(405, { message: "Method Not Allowed", method, path })
          : json(404, { message: "Not Found", method, path }),
        startedAt
      );
    }

    return withMeta(await handle(event, params), startedAt);
  } catch (err) {
    if (err instanceof ValidationError) {
      return withMeta(json(400, { message: err.message }), startedAt);
    }

    if (err instanceof NotFoundError) {
      return withMeta(json(404, { message: err.message }), startedAt);
    }

    // A missing IAM grant is a deployment problem, not a bug in the request. Saying so
    // - with the action that was denied - turns an opaque 500 in DevTools into
    // something actionable without opening CloudWatch.
    if (err?.name === "AccessDeniedException") {
      console.error("permission denied", err.message);
      return withMeta(
        json(502, { message: "The API is missing an IAM permission for this action" }),
        startedAt
      );
    }

    if (["ECONNREFUSED", "ETIMEDOUT", "ENOTFOUND"].includes(err?.code)) {
      console.error("dependency unreachable", err.message);
      return withMeta(json(503, { message: "A backing store is unavailable" }), startedAt);
    }

    console.error("unhandled", err);
    return withMeta(json(500, { message: "Internal Server Error" }), startedAt);
  }
};
