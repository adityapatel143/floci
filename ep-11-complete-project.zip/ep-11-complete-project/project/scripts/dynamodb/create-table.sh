#!/usr/bin/env bash
# Creates the product catalog table and the order-pipeline status table, and waits
# until each can actually accept writes.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws

wait_for_floci

if floci_aws dynamodb describe-table --table-name "$CATALOG_TABLE" >/dev/null 2>&1; then
  echo "Table ${CATALOG_TABLE} already exists."
else
  echo "Creating table ${CATALOG_TABLE}..."
  floci_aws dynamodb create-table \
    --table-name "$CATALOG_TABLE" \
    --attribute-definitions AttributeName=productId,AttributeType=S \
    --key-schema AttributeName=productId,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST >/dev/null
fi

# Records real per-order progress (db write, enqueue, worker, fan-out, both downstream
# consumers) so the storefront's pipeline UI can show what actually happened - written
# to by four different Lambdas, read by the API's GET /orders/:orderId/pipeline route.
if floci_aws dynamodb describe-table --table-name "$ORDER_PIPELINE_TABLE" >/dev/null 2>&1; then
  echo "Table ${ORDER_PIPELINE_TABLE} already exists."
else
  echo "Creating table ${ORDER_PIPELINE_TABLE}..."
  floci_aws dynamodb create-table \
    --table-name "$ORDER_PIPELINE_TABLE" \
    --attribute-definitions AttributeName=orderId,AttributeType=S \
    --key-schema AttributeName=orderId,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST >/dev/null
fi

# A table exists before it is usable; writing to a CREATING table fails.
echo "Waiting for ${CATALOG_TABLE} to become ACTIVE..."
floci_aws dynamodb wait table-exists --table-name "$CATALOG_TABLE"
echo "Waiting for ${ORDER_PIPELINE_TABLE} to become ACTIVE..."
floci_aws dynamodb wait table-exists --table-name "$ORDER_PIPELINE_TABLE"

echo "Tables ready."
