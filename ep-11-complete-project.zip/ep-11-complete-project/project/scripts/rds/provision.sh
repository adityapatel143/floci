#!/usr/bin/env bash
# Provisions the PostgreSQL instance that stores orders, and reports its address.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws

wait_for_floci

# Lambda is not VPC-attached in this project, so it reaches RDS over the public internet
# path, not through the VPC - the default security group does not allow that. A
# dedicated security group open on 5432 to the world is the simplest fix for a demo;
# production should instead put the Lambda in the VPC (or use RDS Proxy with IAM auth)
# and keep the database off the public internet entirely.
SG_ID=""
if ! using_floci; then
  VPC_ID=$(floci_aws ec2 describe-vpcs --filters Name=isDefault,Values=true \
    --query 'Vpcs[0].VpcId' --output text)
  SG_NAME="flocicart-rds-demo"
  SG_ID=$(floci_aws ec2 describe-security-groups \
    --filters "Name=group-name,Values=${SG_NAME}" "Name=vpc-id,Values=${VPC_ID}" \
    --query 'SecurityGroups[0].GroupId' --output text 2>/dev/null || true)
  if [ -z "$SG_ID" ] || [ "$SG_ID" = "None" ]; then
    echo "Creating security group ${SG_NAME} (Postgres from anywhere - demo only)..."
    SG_ID=$(floci_aws ec2 create-security-group \
      --group-name "$SG_NAME" \
      --description "FlociCart demo: allow Postgres from anywhere (Lambda is not VPC-attached)" \
      --vpc-id "$VPC_ID" \
      --query 'GroupId' --output text)
    floci_aws ec2 authorize-security-group-ingress \
      --group-id "$SG_ID" --protocol tcp --port 5432 --cidr 0.0.0.0/0 >/dev/null
  fi
fi

if floci_aws rds describe-db-instances --db-instance-identifier "$DB_INSTANCE_ID" >/dev/null 2>&1; then
  echo "DB instance ${DB_INSTANCE_ID} already exists."
  # Created before the security group above existed, or with the wrong one attached -
  # applied immediately, since a security group change does not require a reboot.
  if [ -n "$SG_ID" ]; then
    floci_aws rds modify-db-instance \
      --db-instance-identifier "$DB_INSTANCE_ID" \
      --vpc-security-group-ids "$SG_ID" \
      --publicly-accessible \
      --apply-immediately >/dev/null
  fi
else
  echo "Creating DB instance ${DB_INSTANCE_ID}..."
  EXTRA_ARGS=()
  if [ -n "$SG_ID" ]; then
    EXTRA_ARGS=(--vpc-security-group-ids "$SG_ID" --publicly-accessible)
  fi
  # ${EXTRA_ARGS[@]+...} (not [@]} directly) because bash 3.2 - macOS's default
  # /bin/bash, unlike Linux's bash 4+ - treats a zero-element array as unbound under
  # `set -u`, even though EXTRA_ARGS=() above assigned it.
  floci_aws rds create-db-instance \
    --db-instance-identifier "$DB_INSTANCE_ID" \
    --db-instance-class db.t3.micro \
    --engine postgres \
    --master-username "$PGUSER" \
    --master-user-password "$PGPASSWORD" \
    --allocated-storage 20 \
    "${EXTRA_ARGS[@]+"${EXTRA_ARGS[@]}"}" >/dev/null
fi

echo "Waiting for ${DB_INSTANCE_ID} to become available..."
floci_aws rds wait db-instance-available --db-instance-identifier "$DB_INSTANCE_ID" 2>/dev/null || true

if ! discover_pg; then
  echo "Could not read the endpoint for ${DB_INSTANCE_ID}." >&2
  exit 1
fi

save_state pg-host "$PG_ADDRESS"
save_state pg-port "$PG_PORT"

echo
echo "DB instance ready."
echo "PGHOST=$PG_ADDRESS"
echo "PGPORT=$PG_PORT"
