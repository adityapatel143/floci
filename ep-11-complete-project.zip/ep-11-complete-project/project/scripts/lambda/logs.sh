#!/usr/bin/env bash
# Tails the CloudWatch Logs group that Floci creates for the function.
#
# Optional first argument overrides which function to tail, e.g.
# ./scripts/lambda/logs.sh flocicart-orders-worker
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws

NAME="${1:-$FUNCTION_NAME}"
GROUP="/aws/lambda/${NAME}"

# The log group only exists after the first invocation, so say so rather than failing.
if ! floci_aws logs describe-log-groups \
  --log-group-name-prefix "$GROUP" \
  --query 'logGroups[0].logGroupName' \
  --output text 2>/dev/null | grep -q "$GROUP"; then
  echo "No logs yet for ${NAME}. Invoke it first: ./scripts/lambda/invoke.sh" >&2
  exit 0
fi

echo "Tailing ${GROUP} (Ctrl+C to stop)..."
floci_aws logs tail "$GROUP" --follow
