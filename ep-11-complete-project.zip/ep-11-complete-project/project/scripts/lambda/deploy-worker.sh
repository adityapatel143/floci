#!/usr/bin/env bash
# Packages and (re)deploys the orders-worker Lambda, and wires it to the orders queue
# with an event source mapping - on Floci, or on real AWS when AWS_ENDPOINT_URL is left
# unset (see using_floci() in scripts/lib/floci.sh).
#
# This is what actually processes orders now: Lambda's own SQS poller invokes this
# function as messages arrive, using the same execution role's credentials. There is no
# terminal to keep open - workers/ordersWorker.mjs (run with `npm run worker`) still
# works locally against Floci if you want to watch processing happen without deploying
# anything, but this script is the path that also works on real AWS.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws zip jq

if [ ! -d node_modules ]; then
  echo "node_modules not found. Run npm install first." >&2
  exit 1
fi

wait_for_floci

if ! discover_queue; then
  echo "Queue ${ORDERS_QUEUE_NAME} not found. Run ./scripts/sqs/create-queue.sh first." >&2
  exit 1
fi
QUEUE_ARN=$(floci_aws sqs get-queue-attributes \
  --queue-url "$ORDERS_QUEUE_URL" \
  --attribute-names QueueArn \
  --query 'Attributes.QueueArn' --output text)

echo "Packaging ${WORKER_FUNCTION_NAME}..."
mkdir -p dist
# Same package as the API function (see scripts/lambda/deploy.sh for why only the zip,
# not the whole dist/ dir, is removed) - simpler than maintaining a second, narrower zip
# for one small handler, at the cost of a few unused files inside it.
rm -f dist/worker.zip
zip -r dist/worker.zip functions src node_modules package.json >/dev/null
echo "Package size: $(du -h dist/worker.zip | cut -f1)"

ENV_VARS="ORDER_EVENTS_TOPIC=${ORDER_EVENTS_TOPIC}"
ENV_VARS+=",ORDER_PIPELINE_TABLE=${ORDER_PIPELINE_TABLE}"

# Resolved once here, at deploy time, with the deployer's own (broader) credentials -
# not looked up by the function itself at runtime. The function's execution role only
# needs sns:Publish, never sns:CreateTopic/ListTopics, because it never has to ask.
if discover_topic; then
  ENV_VARS+=",ORDER_EVENTS_TOPIC_ARN=${ORDER_EVENTS_TOPIC_ARN}"
  echo "Lambda-side topic:    ${ORDER_EVENTS_TOPIC_ARN}"
else
  echo "Warning: topic ${ORDER_EVENTS_TOPIC} not found - publishing will fail." >&2
  echo "         Run ./scripts/sns/setup.sh, then redeploy." >&2
fi

if using_floci; then
  # Same reasoning as deploy.sh: the function runs in its own container, where
  # "localhost" would mean itself, not Floci - and real AWS rejects these as reserved
  # env var names outright, so none of them are ever sent there.
  LAMBDA_ENDPOINT="$(lambda_facing_endpoint)"
  ENV_VARS+=",AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION}"
  ENV_VARS+=",AWS_ENDPOINT_URL=${LAMBDA_ENDPOINT}"
  ENV_VARS+=",AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}"
  ENV_VARS+=",AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}"
  echo "Lambda-side endpoint: ${LAMBDA_ENDPOINT}"
else
  echo "Lambda-side endpoint: (none - using the execution role against real AWS)"
fi

floci_aws lambda delete-function --function-name "$WORKER_FUNCTION_NAME" >/dev/null 2>&1 || true

ROLE_ARN=$(floci_aws iam get-role --role-name "$APP_ROLE_NAME" \
  --query 'Role.Arn' --output text 2>/dev/null || true)
if [ -z "$ROLE_ARN" ] || [ "$ROLE_ARN" = "None" ]; then
  if using_floci; then
    ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/lambda-role"
    echo "Note: ${APP_ROLE_NAME} not found - using the placeholder role."
    echo "      Run ./scripts/iam/setup.sh, then redeploy, to use least privilege."
  else
    echo "Role ${APP_ROLE_NAME} not found. Run ./scripts/iam/setup.sh first." >&2
    exit 1
  fi
fi
echo "Execution role:       ${ROLE_ARN}"

echo "Deploying ${WORKER_FUNCTION_NAME}..."
floci_aws lambda create-function \
  --function-name "$WORKER_FUNCTION_NAME" \
  --runtime nodejs20.x \
  --handler functions/ordersWorker/index.handler \
  --zip-file fileb://dist/worker.zip \
  --role "$ROLE_ARN" \
  --environment "Variables={${ENV_VARS}}" \
  --tracing-config Mode=Active \
  --output json |
  jq -r '"Deployed: \(.FunctionArn)\nRuntime:  \(.Runtime)\nHandler:  \(.Handler)"'

# A freshly (re)created function needs a moment before it can be wired to an event
# source - an immediate create-event-source-mapping otherwise intermittently fails with
# "function not found/active yet".
floci_aws lambda wait function-active --function-name "$WORKER_FUNCTION_NAME" 2>/dev/null || true

# create-event-source-mapping is not idempotent - calling it twice would attach the
# queue a second time and process every message twice. List first, only create if this
# function/queue pair is not already mapped.
EXISTING_UUID=$(floci_aws lambda list-event-source-mappings \
  --function-name "$WORKER_FUNCTION_NAME" \
  --event-source-arn "$QUEUE_ARN" \
  --query 'EventSourceMappings[0].UUID' --output text 2>/dev/null || true)

if [ -n "$EXISTING_UUID" ] && [ "$EXISTING_UUID" != "None" ]; then
  echo "Event source mapping already exists: ${EXISTING_UUID}"
else
  # ReportBatchItemFailures matches the handler's return shape - without both this flag
  # and the handler returning batchItemFailures, Lambda treats any single failure as the
  # whole batch failing, and redelivers messages that already succeeded.
  EXISTING_UUID=$(floci_aws lambda create-event-source-mapping \
    --function-name "$WORKER_FUNCTION_NAME" \
    --event-source-arn "$QUEUE_ARN" \
    --batch-size 5 \
    --function-response-types ReportBatchItemFailures \
    --query 'UUID' --output text)
  echo "Event source mapping created: ${EXISTING_UUID}"
fi

echo
echo "Orders queue is now consumed by ${WORKER_FUNCTION_NAME} - no separate terminal needed."
