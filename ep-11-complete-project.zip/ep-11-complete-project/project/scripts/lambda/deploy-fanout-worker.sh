#!/usr/bin/env bash
# Packages and (re)deploys a fan-out consumer Lambda, wired to its own SQS queue - on
# Floci, or on real AWS when AWS_ENDPOINT_URL is left unset.
#
# Generalizes scripts/lambda/deploy-worker.sh: the notifications and analytics queues
# are two independent subscribers of the same SNS topic, and both need the exact same
# deploy mechanics (package, role, tracing, event source mapping) - only the function
# name, handler, and queue differ, so one parametrized script covers both instead of two
# near-duplicate copies.
#
# Usage: ./scripts/lambda/deploy-fanout-worker.sh <function-name> <handler> <queue-name>
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws zip jq

FN_NAME="${1:?function name required}"
HANDLER="${2:?handler required}"
QUEUE_NAME="${3:?queue name required}"

if [ ! -d node_modules ]; then
  echo "node_modules not found. Run npm install first." >&2
  exit 1
fi

wait_for_floci

QUEUE_URL=$(floci_aws sqs get-queue-url --queue-name "$QUEUE_NAME" \
  --query QueueUrl --output text 2>/dev/null || true)
if [ -z "$QUEUE_URL" ] || [ "$QUEUE_URL" = "None" ]; then
  echo "Queue ${QUEUE_NAME} not found. Run ./scripts/sns/setup.sh first." >&2
  exit 1
fi
QUEUE_ARN=$(floci_aws sqs get-queue-attributes \
  --queue-url "$QUEUE_URL" \
  --attribute-names QueueArn \
  --query 'Attributes.QueueArn' --output text)

echo "Packaging ${FN_NAME}..."
mkdir -p dist
# Same package as the other functions (see scripts/lambda/deploy.sh for why only the
# zip, not the whole dist/ dir, is removed) - one zip, several handlers inside it.
rm -f "dist/${FN_NAME}.zip"
zip -r "dist/${FN_NAME}.zip" functions src node_modules package.json >/dev/null
echo "Package size: $(du -h "dist/${FN_NAME}.zip" | cut -f1)"

ENV_VARS="ORDER_PIPELINE_TABLE=${ORDER_PIPELINE_TABLE}"
if using_floci; then
  # Same reasoning as deploy.sh: the function runs in its own container, where
  # "localhost" would mean itself, not Floci - and real AWS rejects these as reserved
  # env var names outright, so none of them are ever sent there.
  LAMBDA_ENDPOINT="$(lambda_facing_endpoint)"
  ENV_VARS+=",AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION}"
  ENV_VARS+=",AWS_ENDPOINT_URL=${LAMBDA_ENDPOINT}"
  ENV_VARS+=",AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}"
  ENV_VARS+=",AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}"
  echo "Lambda-side endpoint: ${LAMBDA_ENDPOINT}"
else
  echo "Lambda-side endpoint: (none - using the execution role against real AWS)"
fi

floci_aws lambda delete-function --function-name "$FN_NAME" >/dev/null 2>&1 || true

ROLE_ARN=$(floci_aws iam get-role --role-name "$APP_ROLE_NAME" \
  --query 'Role.Arn' --output text 2>/dev/null || true)
if [ -z "$ROLE_ARN" ] || [ "$ROLE_ARN" = "None" ]; then
  if using_floci; then
    ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/lambda-role"
    echo "Note: ${APP_ROLE_NAME} not found - using the placeholder role."
    echo "      Run ./scripts/iam/setup.sh, then redeploy, to use least privilege."
  else
    echo "Role ${APP_ROLE_NAME} not found. Run ./scripts/iam/setup.sh first." >&2
    exit 1
  fi
fi
echo "Execution role:       ${ROLE_ARN}"

DEPLOY_ARGS=(--function-name "$FN_NAME" --runtime nodejs20.x --handler "$HANDLER"
  --zip-file "fileb://dist/${FN_NAME}.zip" --role "$ROLE_ARN" --tracing-config Mode=Active)
if [ -n "$ENV_VARS" ]; then
  DEPLOY_ARGS+=(--environment "Variables={${ENV_VARS}}")
fi

echo "Deploying ${FN_NAME}..."
floci_aws lambda create-function "${DEPLOY_ARGS[@]}" --output json |
  jq -r '"Deployed: \(.FunctionArn)\nRuntime:  \(.Runtime)\nHandler:  \(.Handler)"'

# A freshly (re)created function needs a moment before it can be wired to an event
# source - an immediate create-event-source-mapping otherwise intermittently fails with
# "function not found/active yet".
floci_aws lambda wait function-active --function-name "$FN_NAME" 2>/dev/null || true

# create-event-source-mapping is not idempotent - calling it twice would attach the
# queue a second time and process every message twice. List first, only create if this
# function/queue pair is not already mapped.
EXISTING_UUID=$(floci_aws lambda list-event-source-mappings \
  --function-name "$FN_NAME" \
  --event-source-arn "$QUEUE_ARN" \
  --query 'EventSourceMappings[0].UUID' --output text 2>/dev/null || true)

if [ -n "$EXISTING_UUID" ] && [ "$EXISTING_UUID" != "None" ]; then
  echo "Event source mapping already exists: ${EXISTING_UUID}"
else
  EXISTING_UUID=$(floci_aws lambda create-event-source-mapping \
    --function-name "$FN_NAME" \
    --event-source-arn "$QUEUE_ARN" \
    --batch-size 5 \
    --function-response-types ReportBatchItemFailures \
    --query 'UUID' --output text)
  echo "Event source mapping created: ${EXISTING_UUID}"
fi

echo
echo "${QUEUE_NAME} is now consumed by ${FN_NAME}."
