#!/usr/bin/env bash
# Packages the handler into a zip and (re)deploys it as a Lambda function - on Floci, or
# on real AWS when AWS_ENDPOINT_URL is left unset (see using_floci() in scripts/lib/floci.sh).
#
# The function needs to know where PostgreSQL, Redis and the queue live. Those addresses
# are discovered here and injected as environment variables, which is why redeploying
# fixes most "cannot connect" errors. Floci additionally needs an explicit endpoint and
# fake credentials because its container can't reach itself via "localhost"; real AWS
# needs neither - its Lambda runtime resolves the real endpoints and execution role
# credentials on its own.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws zip jq

if [ ! -d node_modules ]; then
  echo "node_modules not found. Run npm install first." >&2
  exit 1
fi

wait_for_floci

echo "Packaging ${FUNCTION_NAME}..."
mkdir -p dist
# Remove only the old zip, not the whole dist/ directory - bootstrap.sh writes its
# per-step logs to dist/bootstrap-logs/ and s3/upload.sh its config.js there too, and
# both are still needed by later steps in the same bootstrap run.
rm -f dist/api.zip
zip -r dist/api.zip functions src node_modules package.json >/dev/null
echo "Package size: $(du -h dist/api.zip | cut -f1)"

ENV_VARS="CATALOG_TABLE=${CATALOG_TABLE}"
ENV_VARS+=",ORDERS_QUEUE_NAME=${ORDERS_QUEUE_NAME}"
ENV_VARS+=",ORDER_EVENTS_TOPIC=${ORDER_EVENTS_TOPIC}"
ENV_VARS+=",ORDER_PIPELINE_TABLE=${ORDER_PIPELINE_TABLE}"
if using_floci; then
  # Floci needs an explicit endpoint, region and fake credentials: the function runs in
  # its own container, where "localhost" would mean itself, not Floci. Real AWS rejects
  # AWS_DEFAULT_REGION/AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY as env vars outright - they
  # are reserved names the Lambda runtime sets itself (as AWS_REGION, plus the execution
  # role's own temporary credentials) - so none of these three are ever sent to real AWS.
  LAMBDA_ENDPOINT="$(lambda_facing_endpoint)"
  ENV_VARS+=",AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION}"
  ENV_VARS+=",AWS_ENDPOINT_URL=${LAMBDA_ENDPOINT}"
  ENV_VARS+=",AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}"
  ENV_VARS+=",AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}"
  echo "Lambda-side endpoint: ${LAMBDA_ENDPOINT}"
else
  # Real AWS: the execution role supplies credentials via the runtime automatically.
  # Static keys here would be redundant at best and leak the deployer's own AWS access
  # into the function's environment at worst.
  echo "Lambda-side endpoint: (none - using the execution role against real AWS)"
fi

if discover_pg; then
  ENV_VARS+=",PGHOST=${PG_ADDRESS},PGPORT=${PG_PORT}"
  ENV_VARS+=",PGUSER=${PGUSER},PGPASSWORD=${PGPASSWORD},PGDATABASE=${PGDATABASE}"
  echo "Lambda-side database:  ${PG_ADDRESS}:${PG_PORT}"
else
  echo "Warning: ${DB_INSTANCE_ID} not found - /orders will fail." >&2
fi

# Redis is optional: with no REDIS_HOST the app skips the cache instead of failing.
if discover_redis; then
  ENV_VARS+=",REDIS_HOST=${REDIS_ADDRESS},REDIS_PORT=${REDIS_PORT}"
  echo "Lambda-side cache:     ${REDIS_ADDRESS}:${REDIS_PORT}"
else
  echo "Note: no Redis endpoint - /products will report source=db-no-cache."
fi

if ! discover_queue; then
  echo "Warning: queue ${ORDERS_QUEUE_NAME} not found." >&2
  echo "         Run ./scripts/sqs/create-queue.sh, then redeploy." >&2
fi

floci_aws lambda delete-function --function-name "$FUNCTION_NAME" >/dev/null 2>&1 || true

# Prefer the least-privilege role created in this episode. Floci tolerates a made-up
# placeholder ARN so a quick demo deploy still works; real AWS never would, so fail
# clearly there instead of deploying with a role guaranteed not to exist.
ROLE_ARN=$(floci_aws iam get-role --role-name "$APP_ROLE_NAME" \
  --query 'Role.Arn' --output text 2>/dev/null || true)
if [ -z "$ROLE_ARN" ] || [ "$ROLE_ARN" = "None" ]; then
  if using_floci; then
    ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/lambda-role"
    echo "Note: ${APP_ROLE_NAME} not found - using the placeholder role."
    echo "      Run ./scripts/iam/setup.sh, then redeploy, to use least privilege."
  else
    echo "Role ${APP_ROLE_NAME} not found. Run ./scripts/iam/setup.sh first." >&2
    exit 1
  fi
fi
echo "Execution role:       ${ROLE_ARN}"

echo "Deploying ${FUNCTION_NAME}..."
floci_aws lambda create-function \
  --function-name "$FUNCTION_NAME" \
  --runtime nodejs20.x \
  --handler functions/api/index.handler \
  --zip-file fileb://dist/api.zip \
  --role "$ROLE_ARN" \
  --environment "Variables={${ENV_VARS}}" \
  --tracing-config Mode=Active \
  --output json |
  jq -r '"Deployed: \(.FunctionArn)\nRuntime:  \(.Runtime)\nHandler:  \(.Handler)"'

# Deleting the function above wiped its resource policy too - permissions are not
# carried over to the freshly created one, even though it has the same name/ARN. If an
# HTTP API already points at this function, it silently loses the ability to invoke it
# (every route starts returning a generic 500, including ones with no dependencies of
# their own) until this is re-granted - which apigw/create-http-api.sh only does as a
# side effect of recreating the whole API. Redo just the grant here instead, so a plain
# code-only redeploy never requires recreating the API to keep working.
EXISTING_API_ID="$(read_state api-id)"
if [ -z "$EXISTING_API_ID" ]; then
  echo "No saved API id (.floci/api-id) - skipping the API Gateway permission re-grant."
  echo "If an HTTP API already exists, run ./scripts/apigw/create-http-api.sh once to reconnect it."
elif using_floci; then
  : # Floci does not enforce this permission, so there is nothing to re-grant.
else
  if GRANT_OUT=$(floci_aws lambda add-permission \
    --function-name "$FUNCTION_NAME" \
    --statement-id "apigw-${EXISTING_API_ID}" \
    --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:${AWS_DEFAULT_REGION}:$(cut -d: -f5 <<<"$ROLE_ARN"):${EXISTING_API_ID}/*/*" \
    2>&1); then
    echo "Re-granted API Gateway (${EXISTING_API_ID}) permission to invoke this function."
  elif grep -q "ResourceConflictException" <<<"$GRANT_OUT"; then
    echo "API Gateway (${EXISTING_API_ID}) permission was already in place."
  else
    echo "Could not re-grant the API Gateway (${EXISTING_API_ID}) invoke permission:" >&2
    echo "$GRANT_OUT" >&2
    echo "Run ./scripts/apigw/create-http-api.sh to reconnect it instead." >&2
  fi
fi

echo
echo "Next: ./scripts/apigw/create-http-api.sh"
