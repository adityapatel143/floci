#!/usr/bin/env bash
# Widens the HTTP API's CORS configuration to cover the CRUD verbs.
#
# Why the storefront's delete/edit failed:
#   create-http-api.sh created the API with
#     AllowMethods: ["GET","POST","OPTIONS"]
#   The routes were never the problem - 'ANY /{proxy+}' already matches every method
#   and path. The problem is that when an HTTP API has a CORS configuration, API Gateway
#   answers the preflight OPTIONS itself and ignores whatever CORS headers the
#   integration returns. So the Lambda's own CORS headers never reach the browser.
#
#   For a preflight asking "may I send DELETE?", API Gateway checks the requested method
#   against AllowMethods. DELETE is not in the list, so it declines by omitting
#   Access-Control-Allow-Origin - exactly the error reported. GET and POST kept working
#   because they are in the list.
#
# This patches the live API in place. It does NOT recreate it, so the API id and the
# api-url in state are unchanged and config.js does not need regenerating.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

wait_for_floci

API_ID="$(read_state api-id)"
if [ -z "$API_ID" ]; then
  echo "No API id saved. Run ./scripts/apigw/create-http-api.sh first." >&2
  exit 1
fi

echo "Patching CORS on API ${API_ID}..."

# MaxAge is worth setting: without it the browser re-sends a preflight before every
# single PUT and DELETE, doubling the request count on an otherwise idle demo.
floci_aws apigatewayv2 update-api \
  --api-id "$API_ID" \
  --cors-configuration '{
    "AllowOrigins":["*"],
    "AllowMethods":["GET","POST","PUT","DELETE","OPTIONS"],
    "AllowHeaders":["content-type"],
    "MaxAge":300
  }' >/dev/null

# CORS configuration is a property of the API, not of a stage's route table, so it takes
# effect without a deployment. The deployment below is belt and braces for real AWS,
# where the stage has no auto-deploy (create-http-api.sh leaves it off deliberately).
echo "CORS now:"
floci_aws apigatewayv2 get-api --api-id "$API_ID" \
  --query 'CorsConfiguration' --output json | sed 's/^/  /'

API_URL="$(read_state api-url)"

echo
echo "Verifying the preflight that was failing..."
# A correct response is 204 with an access-control-allow-origin header. The method here
# must be DELETE - a preflight for GET would have passed even before this fix, so it
# would prove nothing.
curl -s -i -X OPTIONS "${API_URL}/products/preflight-probe" \
  -H "Origin: https://flocicart-web.s3.amazonaws.com" \
  -H "Access-Control-Request-Method: DELETE" \
  -H "Access-Control-Request-Headers: content-type" \
  | sed -n '1p;/[Aa]ccess-[Cc]ontrol/p' | sed 's/^/  /'

echo
echo "Expect: HTTP/2 204 plus access-control-allow-methods including DELETE."
echo "If access-control-allow-origin is missing, the update did not take effect."
