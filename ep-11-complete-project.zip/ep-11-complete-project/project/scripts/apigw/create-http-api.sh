#!/usr/bin/env bash
# Creates the HTTP API that fronts our Lambda, and saves its id for the other scripts.
#
# Re-running this deletes the previous API first, so you never accumulate dead endpoints.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq curl

wait_for_floci

# The function must exist before the integration can point at it - and its real ARN is
# read from here rather than hand-built, so this works unchanged against real AWS too.
LAMBDA_ARN=$(floci_aws lambda get-function --function-name "$FUNCTION_NAME" \
  --query 'Configuration.FunctionArn' --output text 2>/dev/null || true)
if [ -z "$LAMBDA_ARN" ] || [ "$LAMBDA_ARN" = "None" ]; then
  echo "Lambda ${FUNCTION_NAME} is not deployed. Run ./scripts/lambda/deploy.sh first." >&2
  exit 1
fi

EXISTING=$(floci_aws apigatewayv2 get-apis \
  --query "Items[?Name=='${HTTP_API_NAME}'].ApiId" --output text 2>/dev/null || true)

for old in $EXISTING; do
  # `--output text` prints the literal string None when the query matches nothing.
  if [ "$old" != "None" ]; then
    echo "Deleting previous API: $old"
    floci_aws apigatewayv2 delete-api --api-id "$old" >/dev/null
  fi
done

# AllowMethods must list every verb the storefront actually sends. This is not optional
# bookkeeping: when an HTTP API has a CORS configuration, API Gateway REPLACES whatever
# CORS headers the integration returns with these. A preflight asking "may I send
# DELETE?" is answered by checking this list, and a verb that is missing gets a response
# with no Access-Control-Allow-Origin at all - which the browser reports as the wildly
# misleading "No 'Access-Control-Allow-Origin' header is present on the requested
# resource", even though the Lambda ran fine and returned correct headers of its own.
#
# MaxAge is worth setting too: without it the browser re-sends a preflight before every
# single PUT and DELETE, doubling the request count.
API_ID=$(floci_aws apigatewayv2 create-api \
  --name "$HTTP_API_NAME" \
  --protocol-type HTTP \
  --cors-configuration '{"AllowOrigins":["*"],"AllowMethods":["GET","POST","PUT","DELETE","OPTIONS"],"AllowHeaders":["content-type"],"MaxAge":300}' \
  --query ApiId --output text)

# Real AWS refuses to invoke a Lambda through API Gateway without this resource-based
# permission - it just returns a 500 with no route ever reachable, which is why the
# wait_for_http_api check below hangs and times out without it. Floci does not enforce
# this, so every route worked there with or without it. Statement id is scoped to this
# API's id, so re-running against a fresh (new) API id never collides with a previous,
# now-deleted API's grant - only re-running against the SAME id (no redeploy in between)
# hits "already exists", which is fine to ignore; any other failure is a real problem
# and must not be swallowed, or it silently reproduces as an unexplained timeout below.
ADD_PERMISSION_OUT=$(floci_aws lambda add-permission \
  --function-name "$FUNCTION_NAME" \
  --statement-id "apigw-${API_ID}" \
  --action lambda:InvokeFunction \
  --principal apigateway.amazonaws.com \
  --source-arn "arn:aws:execute-api:${AWS_DEFAULT_REGION}:$(cut -d: -f5 <<<"$LAMBDA_ARN"):${API_ID}/*/*" \
  2>&1) || {
  if ! grep -q "ResourceConflictException" <<<"$ADD_PERMISSION_OUT"; then
    echo "$ADD_PERMISSION_OUT" >&2
    exit 1
  fi
}

# AWS_PROXY hands the whole request to Lambda as an event and uses whatever the handler
# returns as the response; payload format 2.0 is the one HTTP APIs use.
INTEGRATION_ID=$(floci_aws apigatewayv2 create-integration \
  --api-id "$API_ID" \
  --integration-type AWS_PROXY \
  --integration-uri "$LAMBDA_ARN" \
  --payload-format-version 2.0 \
  --query IntegrationId --output text)

# Two routes, because 'ANY /{proxy+}' matches /orders but NOT the bare root.
#
# Worth knowing: an explicit ANY route also matches OPTIONS, and an explicit route
# outranks API Gateway's automatic preflight handling. So preflights reach the Lambda
# rather than being answered by the gateway - the handler answers them, and then the
# gateway overwrites its CORS headers using the configuration above. Both halves have to
# be right, which is why the handler keeps an OPTIONS branch of its own.
for ROUTE in 'ANY /{proxy+}' 'ANY /'; do
  floci_aws apigatewayv2 create-route \
    --api-id "$API_ID" \
    --route-key "$ROUTE" \
    --target "integrations/$INTEGRATION_ID" >/dev/null
done

# auto-deploy is left off deliberately: this script always recreates the whole API
# fresh in one pass, so there is never an incremental change for auto-deploy to pick up
# afterward - and real AWS rejects an explicit CreateDeployment against a stage that has
# auto-deploy on ("auto deployment is enabled ... cannot create a deployment"). A plain
# stage plus one explicit deployment is deployed immediately and unambiguously, which
# an implicit initial auto-deployment was not: real AWS has shown the stage sitting at
# "not deployed" with routes already created before the stage existed.
floci_aws apigatewayv2 create-stage \
  --api-id "$API_ID" \
  --stage-name "$HTTP_API_STAGE" >/dev/null

DEPLOYMENT_ID=$(floci_aws apigatewayv2 create-deployment \
  --api-id "$API_ID" \
  --query DeploymentId --output text)

floci_aws apigatewayv2 update-stage \
  --api-id "$API_ID" \
  --stage-name "$HTTP_API_STAGE" \
  --deployment-id "$DEPLOYMENT_ID" >/dev/null

# [VERIFY] Local invoke URL shape as served by Floci; real AWS HTTP APIs always use the
# execute-api domain shape instead.
if using_floci; then
  API_URL="${EP}/restapis/${API_ID}/${HTTP_API_STAGE}/_user_request_"
else
  API_URL="https://${API_ID}.execute-api.${AWS_DEFAULT_REGION}.amazonaws.com/${HTTP_API_STAGE}"
fi

save_state api-id "$API_ID"
save_state api-url "$API_URL"

wait_for_http_api "$API_URL"

echo "API_ID=$API_ID"
echo "API_URL=$API_URL"
