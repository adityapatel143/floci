#!/usr/bin/env bash
# Exchanges long-lived credentials for short-lived ones by assuming the app role.
#
# This is the shape of every "secure" AWS workflow: nothing carries permanent keys with
# real power. You start as an identity that can do almost nothing except assume a role,
# and STS hands back credentials that expire.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

wait_for_floci

ROLE_ARN="$(read_state role-arn)"
if [ -z "$ROLE_ARN" ]; then
  if using_floci; then
    ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/${APP_ROLE_NAME}"
  else
    echo "No role ARN saved. Run ./scripts/iam/setup.sh first." >&2
    exit 1
  fi
fi

echo "Caller before assuming:"
floci_aws sts get-caller-identity --output json | jq -r '"  \(.Arn)"'

# --duration-seconds is the lifetime of the returned credentials. Short is the point:
# a leaked key that expires in 15 minutes is a much smaller problem.
CREDS=$(floci_aws sts assume-role \
  --role-arn "$ROLE_ARN" \
  --role-session-name "flocicart-demo" \
  --duration-seconds 900 \
  --output json)

echo
echo "Temporary credentials:"
jq -r '.Credentials
       | "  AccessKeyId:  \(.AccessKeyId)\n  Expires:      \(.Expiration)"' <<<"$CREDS"

echo
echo "To act as the role in this shell, export all three:"
jq -r '.Credentials
       | "  export AWS_ACCESS_KEY_ID=\(.AccessKeyId)\n  export AWS_SECRET_ACCESS_KEY=\(.SecretAccessKey)\n  export AWS_SESSION_TOKEN=\(.SessionToken)"' <<<"$CREDS"

echo
echo "Note: whether Floci enforces the policy on those credentials varies by version"
echo "[VERIFY]. On real AWS, a call outside the policy above returns AccessDenied."
