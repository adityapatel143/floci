#!/usr/bin/env bash
# Removes everything this episode created - inside Floci, or on real AWS if
# AWS_ENDPOINT_URL is left unset. Every step is tolerant of "already gone", so the
# script is safe to run at any time.
set -euo pipefail

cd "$(dirname "$0")/.."
source scripts/lib/floci.sh

require_cmd aws jq

# This now deletes real resources when targeting real AWS, so require a deliberate,
# hard-to-fat-finger opt-in rather than letting an empty AWS_ENDPOINT_URL do it by
# accident.
if ! using_floci && [ "${CONFIRM_DELETE_REAL_AWS:-}" != "yes" ]; then
  echo "AWS_ENDPOINT_URL is unset, so this would delete real AWS resources:" >&2
  echo "  Lambda, API Gateway, SQS, SNS, ElastiCache, RDS, DynamoDB, S3, IAM, CloudFront, Route 53." >&2
  echo "Set CONFIRM_DELETE_REAL_AWS=yes to proceed, or export AWS_ENDPOINT_URL to target Floci instead." >&2
  exit 1
fi

if ! floci_aws sts get-caller-identity >/dev/null 2>&1; then
  if using_floci; then
    echo "Floci is not running, so there is nothing to clean up."
  else
    echo "Could not authenticate with AWS - nothing was deleted." >&2
  fi
  rm -rf dist "$STATE_DIR"
  exit 0
fi
resolve_web_bucket

# Delete from the outside in: API, then function, then the stores behind it.
echo "Deleting HTTP APIs named: ${HTTP_API_NAME}"
API_IDS=$(floci_aws apigatewayv2 get-apis \
  --query "Items[?Name=='${HTTP_API_NAME}'].ApiId" --output text 2>/dev/null || true)
FOUND=0
for id in $API_IDS; do
  if [ "$id" != "None" ]; then
    floci_aws apigatewayv2 delete-api --api-id "$id" >/dev/null && echo "  deleted $id"
    FOUND=1
  fi
done
if [ "$FOUND" -eq 0 ]; then
  echo "  (none)"
fi

echo "Deleting Lambda function: ${FUNCTION_NAME}"
floci_aws lambda delete-function --function-name "$FUNCTION_NAME" >/dev/null 2>&1 ||
  echo "  (not deployed)"

echo "Deleting log group: /aws/lambda/${FUNCTION_NAME}"
floci_aws logs delete-log-group --log-group-name "/aws/lambda/${FUNCTION_NAME}" >/dev/null 2>&1 ||
  echo "  (no logs)"

# The event source mapping must go before the function - deleting the function first
# leaves an orphaned mapping stuck retrying a function that no longer exists. Shared
# across the three consumer Lambdas since the deletion mechanics are identical.
delete_consumer_lambda() {
  local fn_name="$1"
  echo "Deleting Lambda function: ${fn_name}"
  local mappings
  mappings=$(floci_aws lambda list-event-source-mappings \
    --function-name "$fn_name" \
    --query 'EventSourceMappings[].UUID' --output text 2>/dev/null || true)
  for uuid in $mappings; do
    floci_aws lambda delete-event-source-mapping --uuid "$uuid" >/dev/null 2>&1 || true
  done
  floci_aws lambda delete-function --function-name "$fn_name" >/dev/null 2>&1 ||
    echo "  (not deployed)"

  echo "Deleting log group: /aws/lambda/${fn_name}"
  floci_aws logs delete-log-group --log-group-name "/aws/lambda/${fn_name}" >/dev/null 2>&1 ||
    echo "  (no logs)"
}

for fn in "$WORKER_FUNCTION_NAME" "$NOTIFICATIONS_FUNCTION_NAME" "$ANALYTICS_FUNCTION_NAME"; do
  delete_consumer_lambda "$fn"
done

# Delete by looked-up URL: the queue URL is assigned by SQS, not something we can compose.
for queue in "$ORDERS_QUEUE_NAME" "$ORDERS_DLQ_NAME" "$NOTIFICATIONS_QUEUE_NAME" "$ANALYTICS_QUEUE_NAME"; do
  echo "Deleting queue: ${queue}"
  URL=$(floci_aws sqs get-queue-url --queue-name "$queue" --query QueueUrl --output text 2>/dev/null || true)
  if [ -n "$URL" ] && [ "$URL" != "None" ]; then
    floci_aws sqs delete-queue --queue-url "$URL" >/dev/null && echo "  deleted"
  else
    echo "  (not present)"
  fi
done

# Deleting the topic also removes its subscriptions, so no separate unsubscribe loop.
echo "Deleting SNS topic: ${ORDER_EVENTS_TOPIC}"
if discover_topic; then
  floci_aws sns delete-topic --topic-arn "$ORDER_EVENTS_TOPIC_ARN" >/dev/null && echo "  deleted"
else
  echo "  (not present)"
fi

echo "Deleting cache cluster: ${CACHE_CLUSTER_ID}"
floci_aws elasticache delete-replication-group --replication-group-id "$CACHE_CLUSTER_ID" >/dev/null 2>&1 ||
  echo "  (not present)"

echo "Deleting DB instance: ${DB_INSTANCE_ID}"
floci_aws rds delete-db-instance \
  --db-instance-identifier "$DB_INSTANCE_ID" \
  --skip-final-snapshot >/dev/null 2>&1 ||
  echo "  (not present)"

echo "Deleting DynamoDB table: ${CATALOG_TABLE}"
if floci_aws dynamodb delete-table --table-name "$CATALOG_TABLE" >/dev/null 2>&1; then
  floci_aws dynamodb wait table-not-exists --table-name "$CATALOG_TABLE" 2>/dev/null || true
  echo "  deleted"
else
  echo "  (not present)"
fi

echo "Deleting DynamoDB table: ${ORDER_PIPELINE_TABLE}"
if floci_aws dynamodb delete-table --table-name "$ORDER_PIPELINE_TABLE" >/dev/null 2>&1; then
  floci_aws dynamodb wait table-not-exists --table-name "$ORDER_PIPELINE_TABLE" 2>/dev/null || true
  echo "  deleted"
else
  echo "  (not present)"
fi

echo "Deleting bucket: ${SMOKE_BUCKET}"
floci_aws s3 rb "s3://${SMOKE_BUCKET}" --force >/dev/null 2>&1 ||
  echo "  (not present)"

# An inline policy has to be removed before the role can be deleted.
echo "Deleting IAM role: ${APP_ROLE_NAME}"
if floci_aws iam get-role --role-name "$APP_ROLE_NAME" >/dev/null 2>&1; then
  floci_aws iam delete-role-policy --role-name "$APP_ROLE_NAME" \
    --policy-name "$APP_POLICY_NAME" >/dev/null 2>&1 || true
  floci_aws iam delete-role --role-name "$APP_ROLE_NAME" >/dev/null 2>&1 &&
    echo "  deleted" || echo "  could not delete"
else
  echo "  (not present)"
fi

# A hosted zone must be empty apart from its NS and SOA records before it can be
# deleted, so remove our CNAME first.
echo "Deleting hosted zone: ${DNS_ZONE}"
ZONE_ID=$(floci_aws route53 list-hosted-zones \
  --query "HostedZones[?Name=='${DNS_ZONE}.'].Id | [0]" --output text 2>/dev/null || true)
if [ -n "$ZONE_ID" ] && [ "$ZONE_ID" != "None" ]; then
  ZONE_ID="${ZONE_ID#/hostedzone/}"
  BATCH=$(jq -n --arg name "${DNS_RECORD}." '{
    Changes: [{ Action: "DELETE", ResourceRecordSet: { Name: $name, Type: "CNAME", TTL: 60,
      ResourceRecords: [{ Value: "placeholder" }] } }]
  }')
  # The DELETE must match the existing record exactly, so read the current value first.
  CURRENT=$(floci_aws route53 list-resource-record-sets --hosted-zone-id "$ZONE_ID" \
    --query "ResourceRecordSets[?Name=='${DNS_RECORD}.'] | [0].ResourceRecords[0].Value" \
    --output text 2>/dev/null || true)
  if [ -n "$CURRENT" ] && [ "$CURRENT" != "None" ]; then
    BATCH=$(jq --arg v "$CURRENT" '.Changes[0].ResourceRecordSet.ResourceRecords[0].Value = $v' <<<"$BATCH")
    floci_aws route53 change-resource-record-sets \
      --hosted-zone-id "$ZONE_ID" --change-batch "$BATCH" >/dev/null 2>&1 || true
  fi
  floci_aws route53 delete-hosted-zone --id "$ZONE_ID" >/dev/null 2>&1 &&
    echo "  deleted ${ZONE_ID}" || echo "  could not delete ${ZONE_ID}"
else
  echo "  (not present)"
fi

# A distribution must be disabled and fully deployed before AWS allows deletion, which
# takes many minutes on real AWS. Locally we try, and report rather than block.
echo "Deleting CloudFront distribution"
if discover_distribution; then
  ETAG=$(floci_aws cloudfront get-distribution-config --id "$DISTRIBUTION_ID" \
    --query ETag --output text 2>/dev/null || true)
  if floci_aws cloudfront delete-distribution --id "$DISTRIBUTION_ID" --if-match "$ETAG" >/dev/null 2>&1; then
    echo "  deleted ${DISTRIBUTION_ID}"
  elif using_floci; then
    echo "  could not delete ${DISTRIBUTION_ID} - disable it first, or restart Floci"
  else
    echo "  could not delete ${DISTRIBUTION_ID} - disable it, wait for it to redeploy"
    echo "    (can take 15-20 minutes on real AWS), then re-run cleanup"
  fi
else
  echo "  (not present)"
fi

echo "Deleting bucket: ${WEB_BUCKET}"
floci_aws s3 rb "s3://${WEB_BUCKET}" --force >/dev/null 2>&1 ||
  echo "  (not present)"

echo "Removing local build output and saved ids"
rm -rf dist "$STATE_DIR"

if using_floci; then
  echo "Cleanup complete. Run 'npm run floci:down' to stop the emulator too."
else
  echo "Cleanup complete."
  echo "Note: RDS/ElastiCache deletion is asynchronous - they keep billing until AWS"
  echo "finishes deleting them, a few minutes from now. A CloudFront distribution that"
  echo "could not be deleted above needs a manual disable + wait + delete."
fi
