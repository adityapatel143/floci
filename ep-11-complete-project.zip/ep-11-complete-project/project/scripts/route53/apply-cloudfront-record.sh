#!/usr/bin/env bash
# Points a real hostname at a CloudFront distribution, on real AWS or on Floci.
#
# Separate from setup-zone.sh because on real AWS you usually already own the zone and
# only want to add one record to it - creating a hosted zone you did not intend to own
# is an expensive mistake.
set -euo pipefail

cd "$(dirname "$0")/../.."

require() {
  if [ -z "${!1:-}" ]; then
    echo "Set ${1} before applying the record." >&2
    echo "  ${2}" >&2
    exit 1
  fi
}

require ZONE_ID "export ZONE_ID=Z1234567890ABC   # from: aws route53 list-hosted-zones"
require APP_DOMAIN "export APP_DOMAIN=app.example.com"
require CLOUDFRONT_DOMAIN "export CLOUDFRONT_DOMAIN=d111111abcdef8.cloudfront.net"

if ! command -v jq >/dev/null 2>&1; then
  echo "Missing required command: jq" >&2
  exit 1
fi

# No --endpoint-url means real AWS. Set AWS_ENDPOINT_URL to run this against Floci.
AWS_ARGS=()
if [ -n "${AWS_ENDPOINT_URL:-}" ]; then
  AWS_ARGS+=(--endpoint-url "$AWS_ENDPOINT_URL")
  echo "Targeting Floci at ${AWS_ENDPOINT_URL}"
else
  echo "Targeting real AWS"
fi

# jq rather than sed: a domain is not a safe thing to splice into JSON with a regex, and
# jq guarantees the result is still valid JSON.
CHANGE_BATCH=$(jq \
  --arg domain "${APP_DOMAIN}." \
  --arg target "$CLOUDFRONT_DOMAIN" \
  '.Comment = "Point \($domain) at CloudFront"
   | .Changes[0].ResourceRecordSet.Name = $domain
   | .Changes[0].ResourceRecordSet.ResourceRecords[0].Value = $target' \
  scripts/route53/change-batch.json)

# UPSERT so this is safe to re-run after the distribution is replaced.
# ${AWS_ARGS[@]+...} (not [@]} directly) because bash 3.2 - macOS's default /bin/bash,
# unlike Linux's bash 4+ - treats a zero-element array as unbound under `set -u`, even
# though AWS_ARGS=() above assigned it.
aws route53 change-resource-record-sets \
  --hosted-zone-id "$ZONE_ID" \
  --change-batch "$CHANGE_BATCH" \
  "${AWS_ARGS[@]+"${AWS_ARGS[@]}"}" >/dev/null

echo "Applied: ${APP_DOMAIN} CNAME -> ${CLOUDFRONT_DOMAIN}"
echo
echo "Note: a CNAME cannot sit at a zone apex. For example.com itself, use an"
echo "ALIAS/A record targeting the distribution instead."
