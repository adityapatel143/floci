#!/usr/bin/env bash
# Traces one order through every layer the series built, in order, printing what each
# one did. This is the episode: not new infrastructure, but proof that eleven separate
# pieces are actually one system.
#
# Each step is numbered with the service it exercises, so a failure tells you exactly
# which layer to look at.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq curl

# Prefer the saved URL over an env var so there is nothing to paste by hand.
API_BASE="${API_BASE:-$(read_state api-url)}"
if [ -z "$API_BASE" ]; then
  echo "No API URL. Run ./scripts/apigw/create-http-api.sh first." >&2
  exit 1
fi

# Unique ids per run so the script can be run repeatedly without unique-key collisions.
RUN_ID="$(date +%s)"
PRODUCT_ID="p-trace-${RUN_ID}"
ORDER_ID="o-trace-${RUN_ID}"

step() {
  echo
  echo "=== $1"
}

call_api() {
  local method="$1" path="$2" body="${3:-}"
  if [ -n "$body" ]; then
    # --fail-with-body turns a 4xx/5xx into a non-zero exit but still shows the message.
    curl --fail-with-body -sS -X "$method" "${API_BASE}${path}" \
      -H 'content-type: application/json' -d "$body"
  else
    curl --fail-with-body -sS -X "$method" "${API_BASE}${path}"
  fi
  echo
}

echo "RUN_ID=${RUN_ID}"
echo "API:    ${API_BASE}"

step "1/7 API Gateway -> Lambda (health)"
call_api GET /health | jq -c .

step "2/7 Lambda -> DynamoDB (write a product)"
call_api POST /products \
  "$(jq -nc --arg id "$PRODUCT_ID" '{productId: $id, name: "Trace Item", price: 25}')" | jq -c .

step "3/7 Lambda -> Redis (cache miss, then hit)"
echo -n "  first read:  "
call_api GET /products | jq -r '.source'
echo -n "  second read: "
call_api GET /products | jq -r '.source'
echo "  (db then cache means the cache is live; db-no-cache means Redis is not configured)"

step "4/7 Lambda -> PostgreSQL + SQS (place an order)"
call_api POST /orders \
  "$(jq -nc --arg o "$ORDER_ID" --arg p "$PRODUCT_ID" '{orderId: $o, productId: $p, quantity: 1}')" | jq -c .

step "5/7 SQS depth before the worker runs"
./scripts/sqs/status.sh

step "6/7 Worker: SQS -> processing -> SNS publish"
# The worker runs forever by design, so cap it: 15 seconds is well past the 5s long poll,
# enough for one full receive-process-acknowledge cycle. 124 is timeout's "I killed it".
set +e
timeout 15s npm run --silent worker
WORKER_EXIT=$?
set -e
if [ "$WORKER_EXIT" -ne 0 ] && [ "$WORKER_EXIT" -ne 124 ]; then
  echo "Worker failed with exit ${WORKER_EXIT}" >&2
  exit 1
fi

step "7/7 SNS fan-out: the same event in both subscriber queues"
./scripts/sns/watch-events.sh

echo
echo "Trace complete for ${ORDER_ID}."
echo "One request touched: API Gateway, Lambda, DynamoDB, Redis, PostgreSQL, SQS, SNS."
