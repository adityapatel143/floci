#!/usr/bin/env bash
# Checks you are ready - and willing - to run this stack against real AWS.
#
# Everything so far has been free because nothing left your machine. This script is the
# deliberate speed bump before that stops being true: from here on, RDS and ElastiCache
# bill by the hour whether or not anyone uses them.
set -euo pipefail

# .env, if present, wins over anything already exported - same rule as scripts/lib/floci.sh.
if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

# The whole point is that we are NOT talking to the emulator, so an endpoint override
# here means the caller thinks they are doing something they are not.
if [ -n "${AWS_ENDPOINT_URL:-}" ]; then
  echo "AWS_ENDPOINT_URL is set to '${AWS_ENDPOINT_URL}'." >&2
  echo "That points at Floci. Unset it before running an AWS preflight." >&2
  exit 1
fi

if ! command -v aws >/dev/null 2>&1; then
  echo "AWS CLI not found." >&2
  exit 1
fi

REGION="${AWS_DEFAULT_REGION:-${AWS_REGION:-}}"
if [ -z "$REGION" ]; then
  echo "Set AWS_DEFAULT_REGION before deploying to real AWS." >&2
  exit 1
fi

# get-caller-identity is the cheapest way to prove credentials resolve and work. It is
# also the only call in this script - a preflight must not create anything.
if ! IDENTITY=$(aws sts get-caller-identity --output json 2>&1); then
  echo "Could not authenticate with AWS:" >&2
  echo "$IDENTITY" >&2
  echo >&2
  echo "Configure credentials with 'aws configure', SSO, or CI OIDC." >&2
  exit 1
fi

ACCOUNT=$(printf '%s' "$IDENTITY" | grep -o '"Account": *"[^"]*"' | cut -d'"' -f4)
ARN=$(printf '%s' "$IDENTITY" | grep -o '"Arn": *"[^"]*"' | cut -d'"' -f4)

echo "AWS preflight passed"
echo "  Account: ${ACCOUNT}"
echo "  Identity: ${ARN}"
echo "  Region:  ${REGION}"
echo
echo "Resources this stack would create that cost money while idle:"
echo "  - RDS db.t3.micro instance"
echo "  - ElastiCache cache.t3.micro node"
echo "  - CloudFront distribution and Route 53 hosted zone"
echo
echo "DynamoDB (on-demand), Lambda, SQS and SNS are effectively free at demo volume."
echo "Set a budget alert before you continue, and run the cleanup script when you finish."
