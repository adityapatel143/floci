# Shared helpers for every shell script in this episode.
# Source it, do not execute it:  source scripts/lib/floci.sh

# .env, if present, wins over anything already exported - editing it is the deliberate
# action, so a stale variable left in the shell should never silently override it.
if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

# One endpoint for all services; override AWS_ENDPOINT_URL to point at real AWS.
EP="${AWS_ENDPOINT_URL:-http://localhost:4566}"

# The AWS CLI refuses to sign a request without credentials, even fake ones - but fake
# ones only make sense for Floci. Real AWS should use whatever is already configured
# (a real key from .env, a profile, SSO, an instance/task role) instead of being forced
# to "test", which would outrank all of those the moment it is set.
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-us-east-1}"
if [ -n "${AWS_ENDPOINT_URL:-}" ]; then
  export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-test}"
  export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-test}"
fi

# Resource names, kept in sync with src/config/resources.mjs.
FUNCTION_NAME="${LAMBDA_FUNCTION:-flocicart-api}"
WORKER_FUNCTION_NAME="${WORKER_FUNCTION_NAME:-flocicart-orders-worker}"
NOTIFICATIONS_FUNCTION_NAME="${NOTIFICATIONS_FUNCTION_NAME:-flocicart-notifications-worker}"
ANALYTICS_FUNCTION_NAME="${ANALYTICS_FUNCTION_NAME:-flocicart-analytics-worker}"
SMOKE_BUCKET="${SMOKE_BUCKET:-flocicart-ep01-smoke}"
HTTP_API_NAME="${HTTP_API_NAME:-flocicart-http}"
HTTP_API_STAGE="${HTTP_API_STAGE:-dev}"
CATALOG_TABLE="${CATALOG_TABLE:-flocicart-products}"
ORDER_PIPELINE_TABLE="${ORDER_PIPELINE_TABLE:-flocicart-order-pipeline}"
DB_INSTANCE_ID="${DB_INSTANCE_ID:-flocicart-pg}"
CACHE_CLUSTER_ID="${CACHE_CLUSTER_ID:-flocicart-redis}"
ORDERS_QUEUE_NAME="${ORDERS_QUEUE_NAME:-orders-queue}"
ORDERS_DLQ_NAME="${ORDERS_DLQ_NAME:-orders-queue-dlq}"
ORDER_EVENTS_TOPIC="${ORDER_EVENTS_TOPIC:-order-events}"
NOTIFICATIONS_QUEUE_NAME="${NOTIFICATIONS_QUEUE_NAME:-order-events-notifications}"
ANALYTICS_QUEUE_NAME="${ANALYTICS_QUEUE_NAME:-order-events-analytics}"
# Left unset here on purpose - S3 bucket names are unique across every AWS account on
# earth, not just this one, so a fixed default would make the second person to deploy
# this project (a classmate, a teammate, anyone besides the very first person) fail
# with BucketAlreadyExists on a bucket they don't even own. An explicit override (from
# .env) is captured now; the actual per-account default is computed later by
# resolve_web_bucket(), which needs an AWS call this file cannot make at source time.
WEB_BUCKET="${WEB_BUCKET:-}"
DISTRIBUTION_COMMENT="${DISTRIBUTION_COMMENT:-flocicart static distribution}"
DNS_ZONE="${DNS_ZONE:-flocicart.local}"
DNS_RECORD="${DNS_RECORD:-app.flocicart.local}"
APP_ROLE_NAME="${APP_ROLE_NAME:-flocicart-app-role}"
APP_POLICY_NAME="${APP_POLICY_NAME:-flocicart-inline}"

# Demo credentials only. On real AWS these would come from Secrets Manager - Episode 11
# covers doing this properly.
PGUSER="${PGUSER:-postgres}"
PGPASSWORD="${PGPASSWORD:-postgres}"
PGDATABASE="${PGDATABASE:-postgres}"

# Floci's fixed test account id - only meaningful as a placeholder in Floci mode. Real
# ARNs must come from an actual API response (see apigw/create-http-api.sh,
# lambda/deploy.sh, sts/assume-role.sh), never be hand-built from this.
ACCOUNT_ID="000000000000"
FLOCI_CONTAINER="${FLOCI_CONTAINER:-flocicart-floci}"

# Generated ids and discovered endpoints land here so later commands do not have to
# recreate a resource just to learn its address. Git-ignored; cleanup.sh removes it.
STATE_DIR=".floci"

save_state() {
  mkdir -p "$STATE_DIR"
  printf '%s' "$2" >"$STATE_DIR/$1"
}

read_state() {
  cat "$STATE_DIR/$1" 2>/dev/null || true
}

# True in Floci mode, false when AWS_ENDPOINT_URL was left unset to target real AWS.
# Scripts that must behave differently against real AWS (Lambda env vars, API Gateway
# invoke URLs, IAM role fallbacks) branch on this instead of re-checking the env var.
using_floci() {
  [ -n "${AWS_ENDPOINT_URL:-}" ]
}

# `aws` with the endpoint override applied only in Floci mode - a real AWS call must
# never be silently pointed at localhost.
floci_aws() {
  if using_floci; then
    aws --endpoint-url "$EP" "$@"
  else
    aws "$@"
  fi
}

require_cmd() {
  for cmd in "$@"; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      echo "Missing required command: $cmd" >&2
      exit 1
    fi
  done
}

# The endpoint a Lambda must use to call back into Floci.
#
# Our shell uses http://localhost:4566, but the function runs in its own container where
# "localhost" is the function itself - so it needs Floci's address on the Docker network.
lambda_facing_endpoint() {
  local ip
  ip="$(docker inspect -f \
    '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' \
    "$FLOCI_CONTAINER" 2>/dev/null | head -n1)"

  if [ -n "$ip" ]; then
    printf 'http://%s:4566\n' "$ip"
  else
    printf '%s\n' "$EP"
  fi
}

# Reads the database address RDS assigned, into PG_ADDRESS / PG_PORT.
discover_pg() {
  local info
  info="$(floci_aws rds describe-db-instances \
    --db-instance-identifier "$DB_INSTANCE_ID" \
    --query 'DBInstances[0].Endpoint.[Address,Port]' \
    --output text 2>/dev/null || true)"

  PG_ADDRESS="$(awk '{print $1}' <<<"$info")"
  PG_PORT="$(awk '{print $2}' <<<"$info")"

  if [ -z "$PG_ADDRESS" ] || [ "$PG_ADDRESS" = "None" ]; then
    return 1
  fi
  return 0
}

# Reads the cache node address ElastiCache assigned, into REDIS_ADDRESS / REDIS_PORT.
# Support varies by Floci version, so callers must handle failure.
discover_redis() {
  local info
  info="$(floci_aws elasticache describe-replication-groups \
    --replication-group-id "$CACHE_CLUSTER_ID" \
    --query 'ReplicationGroups[0].ConfigurationEndpoint.[Address,Port]' \
    --output text 2>/dev/null || true)"

  REDIS_ADDRESS="$(awk '{print $1}' <<<"$info")"
  REDIS_PORT="$(awk '{print $2}' <<<"$info")"

  if [ -z "$REDIS_ADDRESS" ] || [ "$REDIS_ADDRESS" = "None" ]; then
    return 1
  fi

  # Floci reports "localhost" here, but Lambda runs in its own container, where that
  # would mean the function itself rather than the Valkey/Redis container.
  if [ "$REDIS_ADDRESS" = "localhost" ]; then
    REDIS_ADDRESS="floci-valkey-${CACHE_CLUSTER_ID}"
  fi
  return 0
}

# Looks up the queue URL SQS assigned, into ORDERS_QUEUE_URL.
discover_queue() {
  ORDERS_QUEUE_URL="$(floci_aws sqs get-queue-url \
    --queue-name "$ORDERS_QUEUE_NAME" \
    --query QueueUrl --output text 2>/dev/null || true)"

  if [ -z "$ORDERS_QUEUE_URL" ] || [ "$ORDERS_QUEUE_URL" = "None" ]; then
    return 1
  fi
  return 0
}

# Looks up the topic ARN SNS assigned, into ORDER_EVENTS_TOPIC_ARN.
discover_topic() {
  ORDER_EVENTS_TOPIC_ARN="$(floci_aws sns list-topics \
    --query "Topics[?ends_with(TopicArn, ':${ORDER_EVENTS_TOPIC}')].TopicArn | [0]" \
    --output text 2>/dev/null || true)"

  if [ -z "$ORDER_EVENTS_TOPIC_ARN" ] || [ "$ORDER_EVENTS_TOPIC_ARN" = "None" ]; then
    return 1
  fi
  return 0
}

# Finds our distribution by its Comment, into DISTRIBUTION_ID / DISTRIBUTION_DOMAIN.
# CloudFront has no "name", so the comment is the only stable handle we control.
discover_distribution() {
  local info
  info="$(floci_aws cloudfront list-distributions \
    --query "DistributionList.Items[?Comment=='${DISTRIBUTION_COMMENT}'].[Id,DomainName] | [0]" \
    --output text 2>/dev/null || true)"

  DISTRIBUTION_ID="$(awk '{print $1}' <<<"$info")"
  DISTRIBUTION_DOMAIN="$(awk '{print $2}' <<<"$info")"

  if [ -z "$DISTRIBUTION_ID" ] || [ "$DISTRIBUTION_ID" = "None" ]; then
    return 1
  fi
  return 0
}

# The real AWS account id (or Floci's fixed placeholder). Deliberately NOT cached in
# state: `.floci/` persists across both Floci and real-AWS runs of the same project, so
# a value cached while targeting Floci (the placeholder, 000000000000) would be silently
# wrong - and not obviously wrong, since it looks like a valid id - if reused after
# switching to real AWS. STS is already fast enough that caching was not worth this risk.
resolve_account_id() {
  if using_floci; then
    printf '%s' "$ACCOUNT_ID"
    return 0
  fi
  floci_aws sts get-caller-identity --query Account --output text
}

# Sets the real WEB_BUCKET value. Deferred out of the plain assignment above because
# the default needs an AWS call (resolve_account_id) that cannot happen before
# wait_for_floci - call this once, after wait_for_floci, in any script that uses
# $WEB_BUCKET. An explicit override (env var/.env) always wins and is never suffixed.
# Saved to state so the Node side (src/config/resources.mjs) can read the exact same
# value without a second AWS call of its own.
resolve_web_bucket() {
  if [ -n "$WEB_BUCKET" ]; then
    return 0
  fi
  WEB_BUCKET="flocicart-web-$(resolve_account_id)"
  save_state web-bucket-name "$WEB_BUCKET"
}

# Floci accepts TCP connections slightly before it can serve API calls, so poll a real
# call instead of the port.
wait_for_floci() {
  local attempts="${1:-30}"
  for ((i = 1; i <= attempts; i++)); do
    if floci_aws sts get-caller-identity >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
  done
  echo "Floci did not become ready at $EP after ${attempts}s." >&2
  echo "Check it with: docker compose logs -f floci" >&2
  exit 1
}

# A freshly created HTTP API is briefly unroutable and answers 404 "Invalid API id
# specified", so poll the stage URL until it actually serves the Lambda.
wait_for_http_api() {
  local url="$1"
  local attempts="${2:-30}"
  for ((i = 1; i <= attempts; i++)); do
    if curl -fsS -o /dev/null "${url}/health" 2>/dev/null; then
      return 0
    fi
    sleep 1
  done

  # One last call without -f, so the real status/body (403 = permission, 500 = Lambda
  # error, timeout = network) is visible instead of a bare "did not start serving".
  local tmp status
  tmp="$(mktemp -t flocicart-wait.XXXXXX)"
  status="$(curl -sS -o "$tmp" -w '%{http_code}' "${url}/health" 2>&1 || true)"
  echo "HTTP API did not start serving ${url} after ${attempts}s." >&2
  echo "Last response: HTTP ${status}" >&2
  cat "$tmp" >&2
  rm -f "$tmp"
  exit 1
}
