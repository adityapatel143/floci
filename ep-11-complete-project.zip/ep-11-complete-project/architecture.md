# Episode 14 Architecture - The Complete Stack

Fourteen episodes, one system. This is FlociCart end to end: every service introduced
across the series, wired together exactly as `npm run bootstrap` deploys it, whether
that is on Floci or on real AWS.

> **A note on the icons below:** GitHub's and VS Code's built-in Mermaid renderers do
> not support loading external icon packs, so literal AWS service icons cannot be
> embedded reliably here. Instead, every node uses AWS's own official
> service-category color coding (the same colors AWS uses on its own architecture
> icons) plus an emoji, so the diagram is still immediately readable by service type.

**Color key** (AWS's own category colors):
🟧 Compute &nbsp;·&nbsp; 🟩 Storage &nbsp;·&nbsp; 🟦 Database &nbsp;·&nbsp;
🟪 Networking / Content Delivery &nbsp;·&nbsp; 🟥 Security &nbsp;·&nbsp;
🟨 App Integration (SQS/SNS) &nbsp;·&nbsp; ⬛ Client

```mermaid
%%{init: {"flowchart": {"useMaxWidth": true, "nodeSpacing": 30, "rankSpacing": 80, "padding": 15, "curve": "basis"}, "themeVariables": {"fontSize": "26px"}}}%%
flowchart TB
    classDef client     fill:#232F3E,stroke:#FF9900,color:#fff,stroke-width:3px,font-size:26px,font-weight:bold;
    classDef network    fill:#8C4FFF,stroke:#232F3E,color:#fff,stroke-width:3px,font-size:26px,font-weight:bold;
    classDef compute    fill:#ED7100,stroke:#232F3E,color:#fff,stroke-width:3px,font-size:26px,font-weight:bold;
    classDef storage    fill:#7AA116,stroke:#232F3E,color:#fff,stroke-width:3px,font-size:26px,font-weight:bold;
    classDef database   fill:#527FFF,stroke:#232F3E,color:#fff,stroke-width:3px,font-size:26px,font-weight:bold;
    classDef integration fill:#E7A800,stroke:#232F3E,color:#111,stroke-width:3px,font-size:26px,font-weight:bold;
    classDef security   fill:#DD344C,stroke:#232F3E,color:#fff,stroke-width:3px,font-size:26px,font-weight:bold;

    Browser["🧑‍💻 Browser<br/>FlociCart storefront"]:::client

    subgraph EDGE["🌍 Edge &amp; Delivery"]
        direction TB
        R53["🌐 Route 53<br/>DNS"]:::network
        CF["🚀 CloudFront<br/>CDN distribution"]:::network
        S3["🪣 S3<br/>flocicart-web-&lt;account&gt;"]:::storage
    end

    subgraph API["🔌 API"]
        APIGW["🔗 API Gateway (HTTP API)<br/>flocicart-http"]:::network
    end

    subgraph COMPUTE["⚙️ Compute - 4 Lambdas, one shared IAM role, X-Ray active tracing"]
        direction TB
        ApiFn["🟧 Lambda: flocicart-api<br/>products + orders handler"]:::compute
        WorkerFn["🟧 Lambda: orders-worker<br/>SQS-triggered"]:::compute
        NotifFn["🟧 Lambda: notifications-worker<br/>SQS-triggered"]:::compute
        AnalyticsFn["🟧 Lambda: analytics-worker<br/>SQS-triggered"]:::compute
    end

    subgraph DATA["🗄️ Data Stores"]
        direction TB
        DdbCatalog[("🟦 DynamoDB<br/>flocicart-products")]:::database
        Redis[("🟦 ElastiCache Redis<br/>flocicart-redis (cache-aside)")]:::database
        Rds[("🟦 RDS PostgreSQL<br/>flocicart-pg (orders)")]:::database
        DdbPipeline[("🟦 DynamoDB<br/>flocicart-order-pipeline")]:::database
    end

    subgraph ASYNC["📨 Messaging - SQS + SNS fan-out"]
        direction TB
        SqsOrders["🟨 SQS: orders-queue"]:::integration
        SqsDlq["🟨 SQS DLQ: orders-queue-dlq"]:::integration
        SnsTopic{{"🟨 SNS: order-events"}}:::integration
        SqsNotif["🟨 SQS: order-events-notifications"]:::integration
        SqsAnalytics["🟨 SQS: order-events-analytics"]:::integration
    end

    subgraph SEC["🔐 Security &amp; Observability"]
        direction TB
        Role["🟥 IAM Role<br/>flocicart-app-role"]:::security
        Xray["🟥 X-Ray active tracing"]:::security
        Logs["🟥 CloudWatch Logs"]:::security
    end

    Browser -->|HTTPS| R53 --> CF
    CF -->|static assets| S3
    Browser -->|"fetch() calls"| APIGW
    APIGW --> ApiFn

    ApiFn -->|read-through cache| Redis
    Redis -.->|cache miss| DdbCatalog
    ApiFn --> DdbCatalog
    ApiFn -->|orders CRUD| Rds
    ApiFn -->|"enqueue (sync)"| SqsOrders
    ApiFn -->|"record stage: db, queue"| DdbPipeline
    Browser -.->|"poll GET /orders/:id/pipeline"| APIGW

    SqsOrders --> WorkerFn
    SqsOrders -.->|"3 failed attempts"| SqsDlq
    WorkerFn -->|"record stage: worker"| DdbPipeline
    WorkerFn -->|publish order.placed| SnsTopic
    WorkerFn -->|"record stage: fanout"| DdbPipeline

    SnsTopic --> SqsNotif
    SnsTopic --> SqsAnalytics
    SqsNotif --> NotifFn
    SqsAnalytics --> AnalyticsFn
    NotifFn -->|"record stage: notifications"| DdbPipeline
    AnalyticsFn -->|"record stage: analytics"| DdbPipeline

    ApiFn -.->|assumes| Role
    WorkerFn -.->|assumes| Role
    NotifFn -.->|assumes| Role
    AnalyticsFn -.->|assumes| Role
    Role -.-> Xray
    Role -.-> Logs
```

## Request lifecycle

**1. Serving the storefront (static, cached at the edge)**
Browser → Route 53 → CloudFront → S3. Nothing dynamic touches this path - it is exactly
why a CDN is worth having.

**2. A synchronous API call (the caller waits)** - `GET`/`POST /products`, `GET
/orders`, etc.
Browser → API Gateway → `flocicart-api` → DynamoDB (products, through Redis) or RDS
(orders). The response carries a `meta` block with server + total timing and, for
product reads, whether it was a cache hit.

**3. Placing an order (partly synchronous, partly not)**
`POST /orders` writes to RDS and enqueues to `orders-queue` before returning `201` - the
customer never waits for anything past that. Both outcomes are recorded to the
`flocicart-order-pipeline` DynamoDB table as they happen.

**4. The asynchronous fan-out (the customer already has their `201`)**
`orders-worker` (its own Lambda, triggered directly by the queue - no polling loop)
picks up the message, publishes `order.placed` to SNS, and records both steps. SNS fans
that single message out to two independent queues; `notifications-worker` and
`analytics-worker` (two more Lambdas, each triggered by its own queue) consume them in
parallel and record their own outcomes. A message that keeps failing anywhere in this
chain is retried automatically and ends up on a DLQ after 3 attempts - it is never
silently lost.

**5. Watching it happen**
The storefront polls `GET /orders/:orderId/pipeline`, which just reads the row every
Lambda above wrote to - a stage turns green the moment that Lambda actually recorded
success, and red with the real error if it failed. Nothing here is a guessed timeline.

## Every service, and what it's doing here

| Service | Category | Role in FlociCart |
| --- | --- | --- |
| Route 53 | Networking | DNS in front of the CloudFront distribution |
| CloudFront | Networking | CDN caching the static storefront at the edge |
| S3 | Storage | Hosts the static storefront (`index.html`/`app.js`/`styles.css`/`config.js`) |
| API Gateway (HTTP API) | Networking | Public HTTPS entry point, routes to `flocicart-api` |
| Lambda (×4) | Compute | `flocicart-api`, `orders-worker`, `notifications-worker`, `analytics-worker` |
| DynamoDB (×2) | Database | Product catalog (`flocicart-products`); real per-order pipeline status (`flocicart-order-pipeline`) |
| ElastiCache (Redis) | Database | Read-through cache in front of the product catalog |
| RDS (PostgreSQL) | Database | Durable order storage |
| SQS (×3) + 1 DLQ | App Integration | `orders-queue` (+ DLQ), `order-events-notifications`, `order-events-analytics` |
| SNS | App Integration | Fans `order.placed` out to both downstream queues in one publish |
| IAM | Security | One least-privilege role (`flocicart-app-role`), assumed by all four Lambdas |
| X-Ray | Security / Observability | Active tracing on every Lambda |
| CloudWatch Logs | Security / Observability | Per-function logs, `npm run *:logs` tails them |

## What changed to get here from Episode 13

Episode 13 already had the whole stack automated end to end - this episode's job was
migration-readiness and closing the gaps that only real AWS (never Floci) enforces:
hardcoded fake account IDs in IAM policy JSON, a reserved Lambda env var, a missing API
Gateway invoke permission, an HTTP API stage that was never actually deployed, an app
router that didn't strip a named stage's prefix, RDS needing a security group and TLS,
a missing SQS queue policy for SNS delivery, and an S3 bucket name that was not unique
per AWS account. None of these ever failed on Floci - that is exactly why they were
worth documenting here.
