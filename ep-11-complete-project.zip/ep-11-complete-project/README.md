# Ep 14 - Wrap-Up and Migration Path

Difficulty: Expert · Git tag: `ep-10-complete-project`

## Where we left off

Episode 13 automated bootstrap and CI smoke tests - one command, `npm run bootstrap`,
brings up the whole stack on Floci, and CI runs the identical thing.

## What this episode adds

- A migration checklist (`docs/migration-checklist.md`) from local Floci to real AWS
- `.env` auto-loading: every script (bash and Node) now reads `.env` on its own, so
  going to real AWS is "fill in `.env`, run the same commands" - nothing to `export`
  by hand, no per-terminal setup to repeat or forget
- `npm run preflight:aws`: a read-only, deliberately annoying speed bump before anything
  can cost money - it creates nothing, it only proves your AWS credentials work
- Every script now genuinely supports both targets, controlled by one thing: whether
  `AWS_ENDPOINT_URL` is set. Set it (as every earlier episode does) and you get Floci.
  Leave it unset and the exact same scripts talk to real AWS - no separate "prod" copies
  of anything.
- `scripts/route53/apply-cloudfront-record.sh`: adds one DNS record to a zone you already
  own, instead of `dns:setup`'s "always create a brand-new hosted zone" (fine on Floci,
  an expensive mistake on real AWS)
- A safety gate on `npm run cleanup`: deleting real AWS resources now requires an explicit
  `CONFIRM_DELETE_REAL_AWS=yes`, so an empty `AWS_ENDPOINT_URL` can never delete
  production by accident
- Order processing (and now notifications/analytics) moved from a terminal-only poller
  to real event-driven Lambdas, with a `GET /orders/:orderId/pipeline` endpoint and an
  animated storefront panel that show genuine per-stage status - see "Processing
  orders" below
- `WEB_BUCKET` now defaults to `flocicart-web-<your-account-id>` instead of a fixed
  name - S3 bucket names are unique across every AWS account, so a constant would make
  the second person to deploy this project (a classmate, a teammate) fail with
  `BucketAlreadyExists` on a bucket they don't own. Resolved automatically, nothing to
  configure, and still stable across re-runs
- All four Lambdas deploy with AWS X-Ray active tracing enabled

This episode does not deploy anything to real AWS - it makes the project *able* to,
safely, and tells you exactly how.

## Prerequisites

- Node.js 20+, Docker, the AWS CLI, `jq`, `zip`, `curl`
- For the local walkthrough below: nothing else - it runs entirely against Floci
- For the real-AWS path: an actual AWS account and credentials (`aws configure`, SSO, or
  CI OIDC) - not needed to follow this README, only if you choose to go further

## Files

| Path | What it is |
| --- | --- |
| `docs/migration-checklist.md` | The step-by-step migration plan, in the order to follow it |
| `.env.example` | Local Floci defaults - `cp` to `.env` for the walkthrough below |
| `.env.aws.example` | Real AWS template - just the access key, secret key, and region |
| `scripts/bootstrap/preflight-aws.sh` | Read-only credential/cost check before a real deploy |
| `scripts/bootstrap/bootstrap.sh` | The one-command stack, now dual-mode (Floci or real AWS) |
| `scripts/route53/apply-cloudfront-record.sh` | Adds a CNAME to a zone you already own, real AWS or Floci |
| `scripts/lib/floci.sh` | Shared helpers: auto-loads `.env`, plus `using_floci()` - the one switch every script checks |
| `src/config/loadEnv.mjs` | The same `.env` auto-load, for the Node scripts that run locally (tests, worker, smoke test) |
| `src/config/awsClients.mjs` | SDK clients: Floci overrides when `AWS_ENDPOINT_URL` is set, plain real-AWS clients otherwise |
| `functions/ordersWorker/index.mjs` | Order processing as its own Lambda, triggered directly by SQS - see "Processing orders" below |
| `functions/notificationsWorker/index.mjs`, `functions/analyticsWorker/index.mjs` | The two SNS fan-out subscribers, each its own Lambda triggered by its own queue |
| `scripts/lambda/deploy-worker.sh` | Deploys the orders worker and wires its SQS event source mapping, real AWS or Floci |
| `scripts/lambda/deploy-fanout-worker.sh` | Same deploy mechanics, parametrized - deploys either fan-out consumer |
| `src/repositories/orderPipeline.mjs` | Real per-order, per-stage status (DynamoDB) that all four Lambdas write to and the API reads back |
| `workers/ordersWorker.mjs` | The original standalone poller - now optional, local-only (see below) |
| `tests/integration.smoke.mjs` | The same smoke suite from Episode 13, unchanged |

## Processing orders: three Lambdas, not a terminal

Earlier episodes processed the orders queue by running `npm run worker` in its own
terminal - fine for following along locally, not something that should ever be a
requirement on real AWS (nothing should depend on a laptop staying on and polling
forever).

`npm run bootstrap` now deploys three small Lambdas instead of one, each triggered
directly by its own SQS queue via a Lambda event source mapping - no polling loop of
ours involved:

- **orders worker** (`functions/ordersWorker`) consumes the orders queue, logs the
  work, and publishes an `order.placed` event to SNS.
- **notifications worker** / **analytics worker** (`functions/notificationsWorker`,
  `functions/analyticsWorker`) each independently consume the queue SNS fans that event
  out to - stand-ins for sending a real notification and recording real analytics, but
  they prove the fan-out genuinely reaches two separate subscribers, not just one queue.

All three report failures per-message (`FunctionResponseTypes=ReportBatchItemFailures`),
so one bad message never redelivers messages that already succeeded; a message that
keeps failing still ends up on its queue's DLQ after 3 attempts, same as before.
`scripts/sns/setup.sh` also attaches the SQS queue policy real AWS requires before SNS
can deliver into a queue at all - subscribing alone does not grant this on real AWS
(Floci does not enforce it, which is why this was easy to miss); without it, the two
fan-out Lambdas are simply never invoked, silently - zero logs, zero errors anywhere.

`workers/ordersWorker.mjs` (`npm run worker`) still works against Floci if you want to
watch processing happen in a terminal without deploying anything - it's just no longer
required, on Floci or on real AWS.

### Watching it happen: the order pipeline panel

After you place an order in the storefront UI, a panel animates through every stage
above - saved to the database, queued, picked up by the order worker, broadcast via
SNS, delivered to both downstream consumers. It reads real status from
`GET /orders/:orderId/pipeline` (backed by `src/repositories/orderPipeline.mjs`, a
small DynamoDB table all four Lambdas write to) - a stage only turns green once that
Lambda actually recorded success, and turns red with the real error if it failed,
rather than playing a fixed animation regardless of what actually happened.

## Viewing the storefront locally

Once `npm run bootstrap` finishes (the "s3 static site"/"s3 config refresh" steps
publish it), open the direct S3 URL in a browser:

```
http://localhost:4566/flocicart-web-000000000000/index.html
```

The bucket is named `flocicart-web-<account-id>`, and on Floci the account id is
always the fixed placeholder `000000000000`, so this exact URL never changes locally.
`scripts/s3/upload.sh` also prints it as "Direct S3 URL: ..." on every run if you ever
need to double check it (or on real AWS, where the account id - and so the URL - is
your own).

## Run instructions (local, against Floci)

This is the same one-command flow as Episode 13 - nothing about the local workflow
changed. It's included here so you can prove the stack still works after everything
above:

```bash
cd project
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run bootstrap
```

```text
Bootstrapping FlociCart against Floci (http://localhost:4566)

docker compose up           ok
waiting for Floci           ok
iam role                    ok
dynamodb table              ok
rds instance                ok
elasticache node            ok
sqs queues                  ok
sns topic                   ok
s3 static site              ok
lambda deploy               ok
orders worker               ok
notifications worker        ok
analytics worker            ok
http api                    ok
s3 config refresh           ok

bootstrap complete
API_BASE=http://localhost:4566/restapis/2db10041ae/dev/_user_request_

Verify with: npm run test:integration
```

```bash
npm run test:integration
```

```text
✔ static site bucket exists
✔ API is reachable
✔ POST /products writes to DynamoDB
✔ POST /products rejects bad input with 400
✔ GET /products returns the product just written
✔ POST /orders writes to PostgreSQL and enqueues
✔ GET /orders returns the order just written
✔ unknown routes return 404
ℹ tests 8
ℹ pass 8
```

## Going to real AWS

Everything below provisions real, billable resources - RDS and ElastiCache cost money by
the hour whether or not anyone uses them - so read `docs/migration-checklist.md` first
and treat this as a plan to run deliberately, not a command to paste blind.

The whole thing is driven by one file, `.env`, which every script now loads
automatically (`scripts/lib/floci.sh` on the bash side, `src/config/loadEnv.mjs` on the
Node side) - there is nothing to `export` by hand:

```bash
cp .env.aws.example .env
```

Edit `.env` and fill in three values - your real AWS access key, secret key, and
region:

```dotenv
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_DEFAULT_REGION=us-east-1
```

**`.env.aws.example` deliberately has no `AWS_ENDPOINT_URL` line - do not add one.** Its
mere presence is what every script uses to mean "this is Floci" (see the table below);
leaving it out is what makes real AWS happen.

Then:

```bash
npm run preflight:aws   # optional - read-only, creates nothing, just proves the
                         # credentials in .env actually work and lists what will bill
npm run bootstrap        # the same command as the local walkthrough
```

With no `AWS_ENDPOINT_URL` in play, `bootstrap.sh` skips `docker compose up` entirely and
provisions the real thing instead - real IAM role, real DynamoDB table, real RDS
instance, and so on, ending with a real Lambda behind a real HTTP API. A missing/invalid
credential fails immediately and cleanly, before anything is created:

```text
Could not authenticate with AWS:
An error occurred (InvalidClientTokenId) when calling the GetCallerIdentity operation...
Configure credentials with 'aws configure', SSO, or CI OIDC.
```

If one step fails partway through, every earlier step already created its resource for
real - re-running `npm run bootstrap` does not recreate anything (every step checks
first, or is naturally idempotent), but it does re-check each one before reaching the
step that actually failed, which is slow to sit through on real AWS. Skip straight to
it with `BOOTSTRAP_FROM`, using the name shown in the failing step's own
`dist/bootstrap-logs/<name>.log` line:

```bash
BOOTSTRAP_FROM=apigw npm run bootstrap   # names: iam, ddb, rds, redis, sqs, sns, s3, lambda, worker, notifications-worker, analytics-worker, apigw, s3-refresh
```

Finally, DNS - only after you have a real CloudFront domain from the bootstrap output:

```bash
export ZONE_ID=<your-hosted-zone-id>       # aws route53 list-hosted-zones
export APP_DOMAIN=app.example.com
export CLOUDFRONT_DOMAIN=<distribution-domain-from-bootstrap-output>
./scripts/route53/apply-cloudfront-record.sh
```

(No temporary/SSO credentials? Uncomment `AWS_SESSION_TOKEN` in `.env.aws.example`
instead of an access key - `.env` is loaded the same way either way. Already have
credentials exported in your shell and no `.env` at all? That still works too - `.env`
only overrides what it explicitly sets, and shell exports cover the rest.)

### What actually changes between the two targets

Nothing was rewritten twice - the same scripts branch on `using_floci()`
(`scripts/lib/floci.sh`), which is just "was `AWS_ENDPOINT_URL` set, in `.env` or the
shell":

| | Floci (`AWS_ENDPOINT_URL` set) | Real AWS (`AWS_ENDPOINT_URL` unset) |
| --- | --- | --- |
| `aws` calls | `--endpoint-url` added automatically | No override - real regional endpoints |
| Fake `test`/`test` credential fallback | Applied if none are set | Never applied - a real key from `.env`, a profile, SSO, or an instance/task role is used as-is |
| Lambda's own AWS SDK clients | `endpoint` + fake `test`/`test` credentials | No override, no credentials - the execution role signs everything |
| Deployed Lambda's env vars | `AWS_ENDPOINT_URL`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` | None of those three - a real deploy never gets static keys |
| Missing IAM role at deploy time | Falls back to a made-up placeholder ARN (fine on an emulator) | Fails with "run `iam:setup` first" (a fake ARN would just fail anyway) |
| API invoke URL | `${EP}/restapis/{id}/{stage}/_user_request_` | `https://{id}.execute-api.{region}.amazonaws.com/{stage}` |
| `npm run cleanup` | Deletes freely | Refuses unless `CONFIRM_DELETE_REAL_AWS=yes` is also set |

That middle row is the one worth calling out explicitly: earlier code in this series
defaulted the SDK's endpoint to `http://localhost:4566` even when `AWS_ENDPOINT_URL` was
unset, and unconditionally baked whatever `AWS_ACCESS_KEY_ID`/`AWS_SECRET_ACCESS_KEY`
were in your shell into the deployed function's environment variables. Against Floci
that's harmless test/test noise; against real AWS it would have meant a Lambda that
could never reach real AWS (still pointed at localhost) *and* leaked the deployer's own
AWS credentials into a place anyone with Lambda read access could read them. Fixed as
part of this episode - see `src/config/awsClients.mjs` and `scripts/lambda/deploy.sh`.

## CI

`.github/workflows/flocicart-ci.yml` runs `npm ci`, `npm run bootstrap`, and
`npm run test:integration` against Floci, exactly like Episode 13 - no AWS account, no
secrets, no cost. It always sets `AWS_ENDPOINT_URL`, so it always exercises the Floci
branch of everything above; the real-AWS branch is for you to run by hand, deliberately.

## Cleanup

```bash
npm run cleanup     # Floci: deletes freely
npm run floci:down
```

Against real AWS, the same command requires an explicit opt-in - `.env` still applies,
so this deletes whatever `.env` currently points at:

```bash
CONFIRM_DELETE_REAL_AWS=yes npm run cleanup
```

It deletes the same resource list either way - Lambda, API Gateway, SQS, SNS,
ElastiCache, RDS, DynamoDB, S3, IAM, CloudFront, Route 53 - but two things on real AWS
are worth knowing before you rely on it:

- **RDS and ElastiCache deletion is asynchronous.** The command returns as soon as AWS
  *accepts* the delete request, not once it's actually gone - they keep billing for a
  few more minutes while AWS finishes tearing them down.
- **CloudFront almost never deletes on the first try.** AWS requires a distribution to
  be disabled and fully redeployed (5-20 minutes) before it can be deleted at all. If
  cleanup reports "could not delete", disable it (`aws cloudfront update-distribution
  --id <id> --distribution-config ... Enabled=false`), wait for its status to become
  `Deployed`, then re-run `npm run cleanup`.
- **If you used `apply-cloudfront-record.sh` on a zone you already own** (the
  recommended real-AWS path - see step 6 of the migration checklist), `npm run cleanup`
  does not remove that CNAME record: it only ever deletes a hosted zone matching
  `DNS_ZONE` (the one `dns:setup` creates), and deliberately never touches a zone it
  didn't create. Remove the record yourself once the distribution is gone:
  `aws route53 change-resource-record-sets --hosted-zone-id $ZONE_ID --change-batch '{"Changes":[{"Action":"DELETE",...}]}'`
  with the same values you gave `apply-cloudfront-record.sh`.

## Common errors

| Error | Fix |
| --- | --- |
| A bootstrap step prints `FAILED` | Its log is printed right below, and kept in `dist/bootstrap-logs/`. |
| `No API base found. Run npm run bootstrap first.` | The tests ran before a bootstrap, or `.floci/` was cleaned. |
| `AWS_ENDPOINT_URL is set to '...'. That points at Floci. Unset it before running an AWS preflight.` | You're trying to preflight real AWS with a local endpoint still exported - `unset AWS_ENDPOINT_URL`. |
| `Could not authenticate with AWS` | Configure real credentials (`aws configure`, SSO, or CI OIDC) before `preflight:aws` or a real `bootstrap`. |
| `Role flocicart-app-role not found. Run ./scripts/iam/setup.sh first.` | Real-AWS deploys refuse the Floci placeholder role - run IAM setup first, per the checklist. |
| `AWS_ENDPOINT_URL is unset, so this would delete real AWS resources` | Add `CONFIRM_DELETE_REAL_AWS=yes` if that's really what you want, or export `AWS_ENDPOINT_URL` to target Floci instead. |
| `MalformedPolicyDocument: Invalid principal ... 000000000000:root` | Should not happen anymore - `iam/setup.sh` substitutes the real account id into the policy files before sending them. If you see it, `.env`/credentials resolved to the wrong account. |
| `reserved keys ... AWS_DEFAULT_REGION` on `lambda deploy` | Should not happen anymore - that var is Floci-only now. If you see it, you're running an old copy of `lambda/deploy.sh`. |
| `http api` step times out (`did not start serving`) | Its log now includes the last HTTP status/body it actually got - a 403 there means the Lambda invoke permission is missing (should be added automatically by `apigw/create-http-api.sh`); a 500 means the Lambda itself is erroring, check `npm run lambda:logs`. |

## End of series

Fourteen episodes, one project: Route 53 and CloudFront at the edge, API Gateway and
Lambda in the middle, DynamoDB/PostgreSQL/Redis/SQS/SNS behind it, IAM securing all of
it, and CI proving it stays working - all runnable for free on Floci, with a checked
path to the real thing whenever you're ready to pay for it.

