# Ep 08 - SNS Fan-Out Notifications

Difficulty: intermediate · Git tag: `ep-08-sns` · Starts from: `ep-07-sqs`

## Where we left off

Episode 07 moved order processing onto a queue. One queue means exactly one consumer -
add a second thing that needs to know about orders and you have to change the producer.

## What this episode adds

- An `order-events` SNS topic published to by the worker
- **Two** subscriber queues, notifications and analytics, both fed by one publish
- Message attributes so subscribers can filter instead of receiving everything
- `sns:watch` to drain both subscriber queues and prove the fan-out happened

## SQS or SNS?

| | SQS | SNS |
| --- | --- | --- |
| Delivery | One consumer takes each message | Every subscriber gets a copy |
| Coupling | Producer knows the queue | Producer knows only the topic |
| Adding a consumer | Change the producer | Run one `subscribe` command |
| Good for | Work that must happen once | Facts other systems react to |

FlociCart uses both: a queue for "process this order" (do it once) and a topic for
"an order was placed" (tell whoever cares).

## Run instructions

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run ddb:create-table
npm run rds:provision
npm run cache:provision
npm run sqs:create-queue
npm run sns:setup
npm run lambda:deploy
npm run api:create
```

```text
Topic: arn:aws:sns:us-east-1:000000000000:order-events
Subscribers:
  order-events-notifications: subscribed
  order-events-analytics: subscribed
```

`sns:setup` is safe to re-run - it skips queues that are already subscribed, so you do
not end up with duplicate subscriptions delivering every event twice.

### Terminal 1 - the worker

```bash
npm run worker
```

### Terminal 2 - place an order, then look at both subscribers

```bash
cd project
export AWS_ENDPOINT_URL=http://localhost:4566
API_URL=$(npm run --silent api:url)

curl -s -X POST "$API_URL/orders" -H 'content-type: application/json' \
  -d '{"orderId":"o3","productId":"p1","quantity":1}' | jq .

npm run sns:watch
```

Terminal 1:

```text
processed { order_id: 'o3', product_id: 'p1', quantity: 1, created_at: '...' }
published order.placed 9f2c...
```

Terminal 2 - the same event, delivered twice, once per subscriber:

```json
--- order-events-notifications
{ "eventType": "order.placed", "occurredAt": "...", "order": { "order_id": "o3", ... } }

--- order-events-analytics
{ "eventType": "order.placed", "occurredAt": "...", "order": { "order_id": "o3", ... } }
```

One `Publish` call, two deliveries, and the worker never learned that a second subscriber
exists. Adding a third is one CLI command.

## Cleanup

```bash
npm run cleanup      # deletes the topic (and its subscriptions), all four queues, and the rest
npm run floci:down
```

## Common errors

| Error | Fix |
| --- | --- |
| `NotFound: Topic does not exist` | Run `npm run sns:setup`, then `npm run lambda:deploy`. |
| Every event appears twice per queue | Duplicate subscriptions from an older run. Run `npm run cleanup`, then set up again. |
| `sns:watch` prints `(no messages)` | The worker has not published yet, or a previous `sns:watch` already drained them - it deletes what it reads. |
| Events reach one queue but not the other | Only one subscription was created. Re-run `npm run sns:setup` and check its output. |

## What is next

Episode 09 puts a static frontend on S3 and a CloudFront distribution in front of it.
