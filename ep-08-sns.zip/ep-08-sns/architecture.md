# Episode 08 Architecture

The worker stops being the end of the line. It publishes one event, and SNS delivers a
copy to every subscriber - none of which the worker knows about.

```mermaid
flowchart LR
    L["Lambda: flocicart-api"] -->|"SendMessage"| Q["SQS: orders-queue"]
    Q --> W["ordersWorker.mjs"]
    W -->|"Publish order.placed"| T["SNS: order-events"]
    T -->|"fan-out"| NQ["SQS: order-events-notifications"]
    T -->|"fan-out"| AQ["SQS: order-events-analytics"]
    NQ -.-> N["email / push<br/>(future)"]
    AQ -.-> A["reporting<br/>(future)"]
```

Queue vs topic: the orders queue delivers each job to exactly one worker, the topic
delivers each event to every subscriber. Adding a third subscriber is a CLI command, not
a code change.
