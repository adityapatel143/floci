# Ep 09 - S3 Static Frontend and CloudFront

Difficulty: intermediate · Git tag: `ep-09-s3-cloudfront` · Starts from: `ep-08-sns`

## Where we left off

Episode 08 finished the backend. Everything so far has been exercised with `curl` - there
is no actual storefront.

## What this episode adds

- A static storefront in S3 (`index.html`, `app.js`)
- A generated `config.js` carrying the real API URL to the browser
- Correct `Content-Type` on every upload
- A CloudFront distribution in front of the bucket, found by comment so re-runs reuse it

## Two things that break static sites

**Content-Type.** S3 stores bytes and serves back whatever type you told it. Upload
`index.html` without `--content-type text/html` and the browser downloads the file instead
of rendering it. `upload.sh` sets it explicitly for every object.

**Hardcoded API URLs.** The API id changes every time the API is recreated, so `app.js`
cannot contain it. Instead `upload.sh` writes `config.js` with the current URL and
`index.html` loads it first. `config.js` is uploaded with `no-cache` so a redeploy is
picked up immediately.

## Run instructions

Create the API first - the upload bakes its URL into `config.js`.

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run ddb:create-table
npm run lambda:deploy
npm run api:create
npm run web:upload
npm run cdn:create
```

```text
Uploaded to s3://flocicart-web
Direct S3 URL: http://localhost:4566/flocicart-web/index.html
API base baked into config.js: http://localhost:4566/restapis/abc123/dev/_user_request_
```

Check the origin content:

```bash
curl -s http://localhost:4566/flocicart-web/index.html | head -5
curl -s http://localhost:4566/flocicart-web/config.js
```

Then open `http://localhost:4566/flocicart-web/index.html` in a browser. The page should
render the product list from the API rather than a download prompt.

If you recreate the API later, re-run `npm run web:upload` so `config.js` is regenerated.

## About the distribution domain

How Floci exposes a CloudFront domain locally varies by version [VERIFY]. `cdn:create`
prints the id and domain it was given, and always prints the direct S3 URL as a fallback
so you can confirm the content independently of the CDN layer.

## Cleanup

```bash
npm run cleanup      # deletes the distribution, both buckets, and everything before it
npm run floci:down
```

## Common errors

| Error | Fix |
| --- | --- |
| Browser downloads `index.html` instead of showing it | Missing Content-Type. Re-run `npm run web:upload`. |
| Page shows `No API base configured.` | `config.js` was generated before the API existed. Run `npm run api:create`, then `npm run web:upload`. |
| `CallerReference ... already exists` | A fixed CallerReference was reused. The script now generates a fresh one per run. |
| `Bucket flocicart-web does not exist.` | Run `npm run web:upload` before `npm run cdn:create`. |
| `Request failed:` in the page output | The API is down or blocking the origin. Check with `curl "$(npm run --silent api:url)/products"`. |

## What is next

Episode 10 puts Route53 DNS in front of the distribution.
