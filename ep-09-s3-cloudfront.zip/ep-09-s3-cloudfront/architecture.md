# Episode 09 Architecture

The browser finally enters the picture. Static assets come from S3 through CloudFront;
data still comes from the API. Two different paths, one page.

```mermaid
flowchart LR
    U["Browser"] -->|"HTML, JS"| CF["CloudFront distribution"]
    CF --> S3[("S3: flocicart-web<br/>index.html, app.js, config.js")]
    U -->|"fetch /products"| API["API Gateway v2"]
    API --> L["Lambda: flocicart-api"]
    L --> D[("DynamoDB")]
```

`config.js` is the join between the two paths: `upload.sh` generates it with the current
API URL so the static bundle never has to hardcode an id that changes on every deploy.
