#!/usr/bin/env bash
# Packages the handler into a zip and (re)deploys it as a Lambda function on Floci.
#
# The function needs to know where Floci, PostgreSQL, Redis and the queue live *from
# inside its own container*. Those addresses are discovered here and injected as
# environment variables, which is why redeploying fixes most "cannot connect" errors.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws zip jq

if [ ! -d node_modules ]; then
  echo "node_modules not found. Run npm install first." >&2
  exit 1
fi

wait_for_floci

echo "Packaging ${FUNCTION_NAME}..."
rm -rf dist
mkdir -p dist
zip -r dist/api.zip functions src node_modules package.json >/dev/null
echo "Package size: $(du -h dist/api.zip | cut -f1)"

LAMBDA_ENDPOINT="$(lambda_facing_endpoint)"
ENV_VARS="AWS_ENDPOINT_URL=${LAMBDA_ENDPOINT}"
ENV_VARS+=",AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION}"
ENV_VARS+=",AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}"
ENV_VARS+=",AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}"
ENV_VARS+=",CATALOG_TABLE=${CATALOG_TABLE}"
ENV_VARS+=",ORDERS_QUEUE_NAME=${ORDERS_QUEUE_NAME}"
ENV_VARS+=",ORDER_EVENTS_TOPIC=${ORDER_EVENTS_TOPIC}"
echo "Lambda-side endpoint: ${LAMBDA_ENDPOINT}"

if discover_pg; then
  ENV_VARS+=",PGHOST=${PG_ADDRESS},PGPORT=${PG_PORT}"
  ENV_VARS+=",PGUSER=${PGUSER},PGPASSWORD=${PGPASSWORD},PGDATABASE=${PGDATABASE}"
  echo "Lambda-side database:  ${PG_ADDRESS}:${PG_PORT}"
else
  echo "Warning: ${DB_INSTANCE_ID} not found - /orders will fail." >&2
fi

# Redis is optional: with no REDIS_HOST the app skips the cache instead of failing.
if discover_redis; then
  ENV_VARS+=",REDIS_HOST=${REDIS_ADDRESS},REDIS_PORT=${REDIS_PORT}"
  echo "Lambda-side cache:     ${REDIS_ADDRESS}:${REDIS_PORT}"
else
  echo "Note: no Redis endpoint - /products will report source=db-no-cache."
fi

if ! discover_queue; then
  echo "Warning: queue ${ORDERS_QUEUE_NAME} not found." >&2
  echo "         Run ./scripts/sqs/create-queue.sh, then redeploy." >&2
fi

floci_aws lambda delete-function --function-name "$FUNCTION_NAME" >/dev/null 2>&1 || true

echo "Deploying ${FUNCTION_NAME}..."
floci_aws lambda create-function \
  --function-name "$FUNCTION_NAME" \
  --runtime nodejs20.x \
  --handler functions/api/index.handler \
  --zip-file fileb://dist/api.zip \
  --role arn:aws:iam::000000000000:role/lambda-role \
  --environment "Variables={${ENV_VARS}}" \
  --output json |
  jq -r '"Deployed: \(.FunctionArn)\nRuntime:  \(.Runtime)\nHandler:  \(.Handler)"'

echo
echo "Next: ./scripts/apigw/create-http-api.sh"
