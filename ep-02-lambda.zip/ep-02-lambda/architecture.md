# Episode 02 Architecture

The compute layer arrives. There is still no HTTP in front of it, so the only way in is a
direct `lambda invoke` through the same 4566 endpoint we set up in Episode 01.

```mermaid
flowchart LR
    C["CLI / deploy script"] -->|"lambda invoke"| F["Floci :4566"]
    F --> L["Lambda: flocicart-api"]
    L --> R["JSON response<br/>(API Gateway proxy shape)"]
    L --> CW["CloudWatch Logs<br/>/aws/lambda/flocicart-api"]
```

The handler already returns `statusCode` / `headers` / `body` so Episode 03 can put an
HTTP API in front of it without touching the function code.
