// Names of the AWS resources this episode creates.
// Shared so every script and the cleanup step can never drift apart.

export const SMOKE_BUCKET = process.env.SMOKE_BUCKET || "flocicart-ep01-smoke";
export const LAMBDA_FUNCTION = process.env.LAMBDA_FUNCTION || "flocicart-api";
