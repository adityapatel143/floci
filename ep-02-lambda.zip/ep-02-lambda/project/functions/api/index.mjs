// The FlociCart API Lambda. Right now it only reports that it is alive; every later
// episode grows this same handler instead of adding a new one.
//
// The response is already shaped as an API Gateway proxy result (statusCode/headers/body)
// even though nothing calls it over HTTP yet - Episode 03 puts an HTTP API in front of it
// and this shape is what that integration expects.

export const handler = async (event) => {
  // Goes to CloudWatch Logs, which is the only way to see inside a running Lambda.
  // Read it with ./scripts/lambda/logs.sh
  console.log("invoke", JSON.stringify({ keys: Object.keys(event ?? {}) }));

  return {
    statusCode: 200,
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      ok: true,
      service: "flocicart-api",
      // requestContext is only present when API Gateway invoked us, so this doubles as a
      // marker for how the function was reached.
      mode: event?.requestContext ? "http" : "invoke",
      now: new Date().toISOString()
    })
  };
};
