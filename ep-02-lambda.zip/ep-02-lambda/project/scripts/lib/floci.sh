# Shared helpers for every shell script in this episode.
# Source it, do not execute it:  source "$(dirname "$0")/../lib/floci.sh"

# One endpoint for all services; override AWS_ENDPOINT_URL to point at real AWS.
EP="${AWS_ENDPOINT_URL:-http://localhost:4566}"

# The AWS CLI refuses to sign a request without credentials, even fake ones.
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-us-east-1}"
export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-test}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-test}"

# Resource names, kept in sync with src/config/resources.mjs.
FUNCTION_NAME="${LAMBDA_FUNCTION:-flocicart-api}"
SMOKE_BUCKET="${SMOKE_BUCKET:-flocicart-ep01-smoke}"

# `aws` with the endpoint override already applied, so no script repeats it.
floci_aws() {
  aws --endpoint-url "$EP" "$@"
}

require_cmd() {
  for cmd in "$@"; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      echo "Missing required command: $cmd" >&2
      exit 1
    fi
  done
}

# Floci accepts TCP connections slightly before it can serve API calls, so poll a real
# call instead of the port. Without this, a script run right after `docker compose up`
# can fail with a confusing 404 or connection reset.
wait_for_floci() {
  local attempts="${1:-30}"
  for ((i = 1; i <= attempts; i++)); do
    if floci_aws sts get-caller-identity >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
  done
  echo "Floci did not become ready at $EP after ${attempts}s." >&2
  echo "Check it with: docker compose logs -f floci" >&2
  exit 1
}
