#!/usr/bin/env bash
# Removes everything this episode created inside Floci, without stopping the container.
#
# Every step is tolerant of "already gone" so the script is safe to run at any time,
# including twice in a row or before anything was ever deployed.
set -euo pipefail

cd "$(dirname "$0")/.."
source scripts/lib/floci.sh

require_cmd aws

if ! floci_aws sts get-caller-identity >/dev/null 2>&1; then
  echo "Floci is not running, so there is nothing to clean up."
  rm -rf dist
  exit 0
fi

echo "Deleting Lambda function: ${FUNCTION_NAME}"
floci_aws lambda delete-function --function-name "$FUNCTION_NAME" >/dev/null 2>&1 ||
  echo "  (not deployed)"

echo "Deleting log group: /aws/lambda/${FUNCTION_NAME}"
floci_aws logs delete-log-group --log-group-name "/aws/lambda/${FUNCTION_NAME}" >/dev/null 2>&1 ||
  echo "  (no logs)"

echo "Deleting bucket: ${SMOKE_BUCKET}"
floci_aws s3 rb "s3://${SMOKE_BUCKET}" --force >/dev/null 2>&1 ||
  echo "  (not present)"

echo "Removing local build output: dist/"
rm -rf dist

echo "Cleanup complete. Run 'npm run floci:down' to stop the emulator too."
