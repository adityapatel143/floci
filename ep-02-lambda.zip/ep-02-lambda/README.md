# Ep 02 - First Node.js Lambda on Floci

Difficulty: beginner · Git tag: `ep-02-lambda` · Starts from: `ep-01-setup-scaffold`

## Where we left off

Episode 01 gave us a running Floci container and SDK clients pointed at `http://localhost:4566`.

## What this episode adds

- A Node.js Lambda handler (`functions/api/index.mjs`)
- A packaging + deploy script that zips the project and creates the function
- An invoke script that decodes the response and detects handler errors
- A logs script, because a deployed Lambda has no terminal to print to
- A cleanup script that removes the function, its log group and the build output

## Prerequisites

- Everything from Episode 01 (Docker, Node 20+)
- AWS CLI v2 (`aws --version`), plus `zip` and `jq`

## Files in this episode

| Path | Purpose |
| --- | --- |
| `project/functions/api/index.mjs` | The Lambda handler |
| `project/scripts/lib/floci.sh` | Shared shell helpers: endpoint, resource names, readiness wait |
| `project/scripts/lambda/deploy.sh` | Zips the project and creates the function |
| `project/scripts/lambda/invoke.sh` | Invokes it and pretty-prints the response |
| `project/scripts/lambda/logs.sh` | Tails `/aws/lambda/flocicart-api` |
| `project/scripts/cleanup.sh` | Deletes everything this episode created |

## Run instructions

1. Open this episode's project.

```bash
cd project
```

2. Start Floci and export the env vars.

```bash
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test
```

3. Install dependencies and deploy.

```bash
npm install
npm run lambda:deploy
```

```text
Packaging flocicart-api...
Package size: 12M
Deploying flocicart-api...
Deployed: arn:aws:lambda:us-east-1:000000000000:function:flocicart-api
Runtime:  nodejs20.x
Handler:  functions/api/index.handler
```

4. Invoke the Lambda.

```bash
npm run lambda:invoke
```

```text
Status: 200
Response:
{
  "statusCode": 200,
  "headers": { "content-type": "application/json" },
  "body": "{\"ok\":true,\"service\":\"flocicart-api\",\"mode\":\"invoke\",\"now\":\"...\"}"
}

Decoded body:
{
  "ok": true,
  "service": "flocicart-api",
  "mode": "invoke",
  "now": "2026-01-01T00:00:00.000Z"
}
```

You can also send your own payload: `./scripts/lambda/invoke.sh '{"hello":"world"}'`.

5. Read the function's logs.

```bash
npm run lambda:logs
```

## Cleanup

```bash
npm run cleanup      # delete the function, its logs and dist/
npm run floci:down   # stop the emulator
```

## Common errors

| Error | Fix |
| --- | --- |
| `node_modules not found. Run npm install first.` | The zip bundles dependencies, so install before deploying. |
| `Function not found: flocicart-api` | Deploy has not run, or cleanup removed it. Run `npm run lambda:deploy`. |
| `Floci did not become ready at http://localhost:4566` | The container is still booting or is not running. Check `npm run floci:logs`. |
| `Unable to import module 'functions/api/index'` | The `--handler` path must match the path inside the zip. Redeploy from the project root. |

## What is next

Episode 03 puts an API Gateway v2 HTTP API in front of this Lambda so it answers real HTTP requests.
