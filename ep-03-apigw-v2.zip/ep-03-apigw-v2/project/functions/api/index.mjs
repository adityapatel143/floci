// The FlociCart API Lambda, now reachable over HTTP through API Gateway v2.
//
// The function itself did not have to change shape to get here: it already returned
// statusCode/headers/body in Episode 02. All we add is reading the request details that
// API Gateway puts in the event, so the same handler can answer more than one route.

// Payload format 2.0 puts the method under requestContext.http and the path in rawPath.
// Both are absent on a direct `lambda invoke`, which is why they have fallbacks.
const readRequest = (event) => ({
  method: event?.requestContext?.http?.method || "INVOKE",
  path: event?.rawPath || "/"
});

const json = (statusCode, payload) => ({
  statusCode,
  headers: { "content-type": "application/json" },
  body: JSON.stringify(payload)
});

export const handler = async (event) => {
  const { method, path } = readRequest(event);

  // Goes to CloudWatch Logs - the only way to see inside a Lambda serving HTTP traffic.
  // Read it with ./scripts/lambda/logs.sh
  console.log("request", JSON.stringify({ method, path }));

  if (path === "/health") {
    return json(200, {
      ok: true,
      service: "flocicart-api",
      method,
      path,
      now: new Date().toISOString()
    });
  }

  // One catch-all response for every other path. Episode 04 replaces this with real
  // product routes backed by DynamoDB.
  return json(200, { ok: true, service: "flocicart-api", method, path });
};
