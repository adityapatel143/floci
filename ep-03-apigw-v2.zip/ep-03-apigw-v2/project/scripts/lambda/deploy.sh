#!/usr/bin/env bash
# Packages the handler into a zip and (re)deploys it as a Lambda function on Floci.
#
# Deploy is delete-then-create on purpose: it is the shortest path to a known state while
# iterating on a tutorial, and there is nothing worth preserving in a local emulator.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws zip jq

if [ ! -d node_modules ]; then
  echo "node_modules not found. Run npm install first." >&2
  exit 1
fi

wait_for_floci

# Lambda resolves --handler against paths inside the zip, so the archive is built from the
# project root: functions/api/index.mjs -> handler "functions/api/index.handler".
echo "Packaging ${FUNCTION_NAME}..."
rm -rf dist
mkdir -p dist
zip -r dist/api.zip functions src node_modules package.json >/dev/null
echo "Package size: $(du -h dist/api.zip | cut -f1)"

# Ignore the error when the function does not exist yet - that is the first-run case.
floci_aws lambda delete-function --function-name "$FUNCTION_NAME" >/dev/null 2>&1 || true

echo "Deploying ${FUNCTION_NAME}..."
floci_aws lambda create-function \
  --function-name "$FUNCTION_NAME" \
  --runtime nodejs20.x \
  --handler functions/api/index.handler \
  --zip-file fileb://dist/api.zip \
  --role arn:aws:iam::000000000000:role/lambda-role \
  --output json |
  jq -r '"Deployed: \(.FunctionArn)\nRuntime:  \(.Runtime)\nHandler:  \(.Handler)"'

echo
echo "Next: ./scripts/apigw/create-http-api.sh"
