#!/usr/bin/env bash
# Creates the HTTP API that fronts our Lambda, and saves its id for the other scripts.
#
# Re-running this deletes the previous API first. Without that, every run would create
# another API with the same name and a brand new id, and you would slowly accumulate
# dead endpoints while wondering which URL is the live one.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq curl

wait_for_floci

# The function must exist before the integration can point at it.
if ! floci_aws lambda get-function --function-name "$FUNCTION_NAME" >/dev/null 2>&1; then
  echo "Lambda ${FUNCTION_NAME} is not deployed. Run ./scripts/lambda/deploy.sh first." >&2
  exit 1
fi

EXISTING=$(floci_aws apigatewayv2 get-apis \
  --query "Items[?Name=='${HTTP_API_NAME}'].ApiId" --output text 2>/dev/null || true)

for old in $EXISTING; do
  # `--output text` prints the literal string None when the query matches nothing.
  if [ "$old" != "None" ]; then
    echo "Deleting previous API: $old"
    floci_aws apigatewayv2 delete-api --api-id "$old" >/dev/null
  fi
done

API_ID=$(floci_aws apigatewayv2 create-api \
  --name "$HTTP_API_NAME" \
  --protocol-type HTTP \
  --query ApiId --output text)

# AWS_PROXY hands the whole request to Lambda as an event and uses whatever the handler
# returns as the response; payload format 2.0 is the one HTTP APIs use.
INTEGRATION_ID=$(floci_aws apigatewayv2 create-integration \
  --api-id "$API_ID" \
  --integration-type AWS_PROXY \
  --integration-uri "$LAMBDA_ARN" \
  --payload-format-version 2.0 \
  --query IntegrationId --output text)

# Two routes, because 'ANY /{proxy+}' matches /health and /products but NOT the bare root.
for ROUTE in 'ANY /{proxy+}' 'ANY /'; do
  floci_aws apigatewayv2 create-route \
    --api-id "$API_ID" \
    --route-key "$ROUTE" \
    --target "integrations/$INTEGRATION_ID" >/dev/null
done

# --auto-deploy means route changes go live immediately, so there is no separate
# "deploy the stage" step to forget.
floci_aws apigatewayv2 create-stage \
  --api-id "$API_ID" \
  --stage-name "$HTTP_API_STAGE" \
  --auto-deploy >/dev/null

# [VERIFY] Local invoke URL shape as served by Floci.
API_URL="${EP}/restapis/${API_ID}/${HTTP_API_STAGE}/_user_request_"

save_state api-id "$API_ID"
save_state api-url "$API_URL"

wait_for_http_api "$API_URL"

echo "API_ID=$API_ID"
echo "API_URL=$API_URL"
echo
echo "Try it:  curl -s \"\$(./scripts/apigw/url.sh)/health\" | jq ."
