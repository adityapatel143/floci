# Ep 03 - API Gateway v2 to Lambda

Difficulty: beginner · Git tag: `ep-03-apigw-v2` · Starts from: `ep-02-lambda`

## Where we left off

Episode 02 deployed a Lambda we could only reach with `aws lambda invoke`.

## What this episode adds

- An API Gateway v2 HTTP API with an `AWS_PROXY` integration to that Lambda
- Catch-all routes (`ANY /` and `ANY /{proxy+}`) and an auto-deploying `dev` stage
- A `/health` route in the handler, driven by the request path
- The API id/URL saved to `.floci/` so you never have to recreate the API to find its URL

## Prerequisites

- Everything from Episode 02
- `curl` in addition to `aws`, `zip` and `jq`

## Files in this episode

| Path | Purpose |
| --- | --- |
| `project/scripts/apigw/create-http-api.sh` | Creates API, integration, routes and stage |
| `project/scripts/apigw/url.sh` | Prints the saved base URL |
| `project/functions/api/index.mjs` | Handler, now path-aware |
| `project/scripts/lib/floci.sh` | Shared helpers, plus the HTTP API readiness wait |

## Run instructions

1. Start Floci and export the env vars.

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test
```

2. Install, deploy the Lambda, then create the API.

```bash
npm install
npm run lambda:deploy
npm run api:create
```

```text
API_ID=abc123def4
API_URL=http://localhost:4566/restapis/abc123def4/dev/_user_request_
```

3. Call it over real HTTP.

```bash
API_URL=$(npm run --silent api:url)
curl -s "$API_URL/health" | jq .
```

```json
{
  "ok": true,
  "service": "flocicart-api",
  "method": "GET",
  "path": "/health",
  "now": "2026-01-01T00:00:00.000Z"
}
```

Any other path hits the catch-all route:

```bash
curl -s "$API_URL/anything" | jq .
curl -s -X POST "$API_URL/" | jq .
```

`npm run api:create` is safe to re-run - it deletes the previous API of the same name
first, so you never end up with a pile of dead API ids.

## Cleanup

```bash
npm run cleanup      # delete the API, the Lambda, its logs, dist/ and .floci/
npm run floci:down   # stop the emulator
```

## Common errors

| Error | Fix |
| --- | --- |
| `{"message":"Invalid API id specified"}` | The API was just created and is not routable yet. `create-http-api.sh` now waits for it; if you see it, re-run `npm run api:create`. |
| `Lambda flocicart-api is not deployed.` | Run `npm run lambda:deploy` before creating the API. |
| `No API URL saved.` | `npm run api:create` has not run in this project, or cleanup removed `.floci/`. |
| `{"message":"Not Found"}` on the root path | `ANY /{proxy+}` does not match `/`. Both routes are created here - re-run `npm run api:create`. |

## What is next

Episode 04 adds DynamoDB so those routes read and write real product data instead of an echo.
