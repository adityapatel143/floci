# Ep 11 - IAM and STS

Difficulty: intermediate · Git tag: `ep-11-iam-sts` · Starts from: `ep-10-route53`

## Where we left off

Every episode so far deployed the Lambda with `arn:aws:iam::000000000000:role/lambda-role`
- a role that was never created. Fine on an emulator, impossible on real AWS.

## What this episode adds

- A real `flocicart-app-role` with an inline policy scoped to specific ARNs
- A trust policy that names who may assume it, instead of allowing everyone
- `deploy.sh` using that role, falling back with a warning if it does not exist
- An STS assume-role script showing short-lived credentials

## Least privilege, concretely

The policy in `infra/iam/flocicart-app-policy.json` grants four things and nothing else:

| Statement | Actions | Resource |
| --- | --- | --- |
| `DdbCatalogReadWrite` | GetItem, PutItem, Scan, Query | the `flocicart-products` table only |
| `SqsOrderSend` | SendMessage, GetQueueUrl | the `orders-queue` only |
| `SnsPublish` | Publish | the `order-events` topic only |
| `WriteOwnLogs` | CreateLogStream, PutLogEvents | its own log group only |

Note what is missing: no `DeleteTable`, no `dynamodb:*`, no other table, no read access to
the queue it writes to. `"Resource": "*"` would have been shorter and would have taught
the opposite lesson.

## Two principals, one role

`infra/iam/trust-policy.json` allows two things to assume the role:

- `lambda.amazonaws.com` - so the function can actually run as it
- the account root - so you can assume it yourself for the demo below

The original `"Principal": { "AWS": "*" }` allowed *any* AWS account anywhere to assume
the role. That is the single most common IAM mistake in tutorials.

## Run instructions

```bash
cd project
npm run floci:up
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test

npm install
npm run iam:setup
npm run lambda:deploy    # now runs as flocicart-app-role
npm run api:create
```

```text
Role ARN: arn:aws:iam::000000000000:role/flocicart-app-role

Granted (and nothing else):
  DdbCatalogReadWrite: dynamodb:GetItem, dynamodb:PutItem, dynamodb:Scan, dynamodb:Query
    on arn:aws:dynamodb:us-east-1:000000000000:table/flocicart-products
  SqsOrderSend: sqs:SendMessage, sqs:GetQueueUrl
    on arn:aws:sqs:us-east-1:000000000000:orders-queue
  ...
```

The deploy confirms which role it used:

```text
Execution role:       arn:aws:iam::000000000000:role/flocicart-app-role
```

## Temporary credentials

```bash
npm run sts:assume
```

```text
Caller before assuming:
  arn:aws:iam::000000000000:root

Temporary credentials:
  AccessKeyId:  ASIA...
  Expires:      2026-01-01T00:15:00Z
```

15 minutes, then they are worthless. That is the whole argument for assume-role over
long-lived keys: the blast radius of a leak is bounded by a clock.

Whether Floci enforces the policy against those credentials varies by version [VERIFY].
On real AWS, calling anything outside the four statements returns `AccessDenied`.

## Cleanup

```bash
npm run cleanup      # removes the inline policy, then the role, then everything else
npm run floci:down
```

## Common errors

| Error | Fix |
| --- | --- |
| `NoSuchEntity: The role ... cannot be found` | Run `npm run iam:setup` before deploying. |
| `Note: flocicart-app-role not found - using the placeholder role.` | Same - the deploy fell back so it would not block you. |
| `MalformedPolicyDocument` | The JSON is invalid or an ARN is malformed. Validate with `jq . infra/iam/flocicart-app-policy.json`. |
| `AccessDenied` after assuming the role | Working as intended - the action is outside the policy. Add it deliberately, do not widen to `*`. |
| `DeleteConflict` during cleanup | The inline policy is still attached. Cleanup removes it first; re-run it. |

## What is next

Episode 12 traces a single request through every layer we have built.
