# Episode 11 Architecture

Identity stops being a placeholder. The Lambda runs as a role whose policy names the exact
resources it may touch, and humans get credentials that expire.

```mermaid
flowchart LR
    LSVC["lambda.amazonaws.com"] -->|"sts:AssumeRole<br/>(trust policy)"| ROLE["IAM role<br/>flocicart-app-role"]
    YOU["You / CI"] -->|"sts:AssumeRole"| STS["STS"]
    STS -->|"credentials, 15 min"| ROLE
    ROLE -->|"inline policy"| P["Allowed:<br/>products table<br/>orders-queue<br/>order-events topic<br/>own log group"]
    ROLE --> L["Lambda: flocicart-api"]
    L --> D[("DynamoDB")]
    L --> Q["SQS"]
```

Everything not listed in the policy is denied by default - IAM has no implicit allow.
