// Order persistence, backed by PostgreSQL on RDS.

import pg from "pg";
import { ValidationError } from "../errors.mjs";

const { Pool } = pg;

// A pool, not a client, and created at module scope on purpose: Lambda reuses the module
// between warm invocations, so connections survive instead of being reopened per request.
const pool = new Pool({
  host: process.env.PGHOST || "127.0.0.1",
  port: Number(process.env.PGPORT || 5432),
  user: process.env.PGUSER || "postgres",
  password: process.env.PGPASSWORD || "postgres",
  database: process.env.PGDATABASE || "postgres",
  max: 2,
  idleTimeoutMillis: 10_000,
  // Fail fast instead of letting API Gateway time out with no explanation.
  connectionTimeoutMillis: 5_000
});

// An idle pool client that errors emits on the pool itself; without a listener Node
// treats it as an unhandled error and exits.
pool.on("error", (err) => {
  console.error("pg pool error", err.message);
});

export async function initOrdersTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      order_id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL,
      quantity INTEGER NOT NULL CHECK (quantity > 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

function validate({ orderId, productId, quantity }) {
  if (typeof orderId !== "string" || orderId.trim() === "") {
    throw new ValidationError("orderId is required and must be a non-empty string");
  }
  if (typeof productId !== "string" || productId.trim() === "") {
    throw new ValidationError("productId is required and must be a non-empty string");
  }
  if (!Number.isInteger(quantity) || quantity <= 0) {
    throw new ValidationError("quantity is required and must be a positive integer");
  }
  return { orderId: orderId.trim(), productId: productId.trim(), quantity };
}

export async function createOrder(input) {
  const order = validate(input);

  try {
    // Parameterised query: the values never become part of the SQL text.
    const out = await pool.query(
      `INSERT INTO orders (order_id, product_id, quantity)
       VALUES ($1, $2, $3)
       RETURNING order_id, product_id, quantity, created_at`,
      [order.orderId, order.productId, order.quantity]
    );
    return out.rows[0];
  } catch (err) {
    // 23505 = unique_violation. A duplicate id is the caller's mistake, not a server fault.
    if (err?.code === "23505") {
      throw new ValidationError(`Order ${order.orderId} already exists`);
    }
    throw err;
  }
}

export async function listOrders() {
  const out = await pool.query(
    `SELECT order_id, product_id, quantity, created_at
     FROM orders
     ORDER BY created_at DESC
     LIMIT 100`
  );
  return out.rows;
}
