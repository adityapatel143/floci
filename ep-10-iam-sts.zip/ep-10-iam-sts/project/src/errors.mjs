// Shared error type. The repositories throw it, and the handler maps it to HTTP 400 -
// that mapping is the only place that knows about status codes.

export class ValidationError extends Error {}
