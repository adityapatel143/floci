// SQS access for order jobs: the producer side runs in the Lambda, the consumer side in
// workers/ordersWorker.mjs. Both use this module so the queue URL is resolved one way.

import {
  SendMessageCommand,
  ReceiveMessageCommand,
  DeleteMessageCommand,
  GetQueueUrlCommand
} from "@aws-sdk/client-sqs";
import { sqs } from "../config/awsClients.mjs";
import { ORDERS_QUEUE_NAME } from "../config/resources.mjs";

// The queue URL is assigned by SQS, so it is looked up rather than hardcoded. Guessing
// it (http://host/000000000000/name) works until the account id or host differs.
let queueUrlPromise;

export function getOrdersQueueUrl() {
  if (process.env.ORDERS_QUEUE_URL) {
    return Promise.resolve(process.env.ORDERS_QUEUE_URL);
  }

  if (!queueUrlPromise) {
    // Cache the promise so concurrent callers share one lookup per container.
    queueUrlPromise = sqs
      .send(new GetQueueUrlCommand({ QueueName: ORDERS_QUEUE_NAME }))
      .then((out) => out.QueueUrl)
      .catch((err) => {
        queueUrlPromise = undefined; // allow a retry after the queue is created
        throw err;
      });
  }

  return queueUrlPromise;
}

export async function enqueueOrderJob(payload) {
  const QueueUrl = await getOrdersQueueUrl();
  const out = await sqs.send(
    new SendMessageCommand({ QueueUrl, MessageBody: JSON.stringify(payload) })
  );
  return out.MessageId;
}

export async function pullOrderJobs() {
  const QueueUrl = await getOrdersQueueUrl();
  const out = await sqs.send(
    new ReceiveMessageCommand({
      QueueUrl,
      MaxNumberOfMessages: 5,
      // Long polling: hold the connection open for up to 5s waiting for work, instead of
      // returning empty immediately and spinning in a tight, expensive loop.
      WaitTimeSeconds: 5,
      // Needed to see how many times a message has been retried.
      AttributeNames: ["ApproximateReceiveCount"]
    })
  );
  return out.Messages || [];
}

// Deleting is the acknowledgement. A message that is never deleted becomes visible again
// after the queue's visibility timeout and is redelivered - that is the retry mechanism.
export async function ackOrderJob(receiptHandle) {
  const QueueUrl = await getOrdersQueueUrl();
  await sqs.send(new DeleteMessageCommand({ QueueUrl, ReceiptHandle: receiptHandle }));
}
