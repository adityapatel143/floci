// Publishes domain events to SNS.
//
// The difference from SQS in one line: a queue message goes to exactly one consumer, an
// SNS message goes to every subscriber. The publisher below does not know or care how
// many that is - subscribers are added with a CLI command, not a code change.

import { PublishCommand, CreateTopicCommand } from "@aws-sdk/client-sns";
import { sns } from "../config/awsClients.mjs";
import { ORDER_EVENTS_TOPIC } from "../config/resources.mjs";

// The ARN is assigned by SNS. CreateTopic is idempotent and returns the existing ARN for
// a name that already exists, which makes it a safe way to look one up.
let topicArnPromise;

export function getOrderEventsTopicArn() {
  if (process.env.ORDER_EVENTS_TOPIC_ARN) {
    return Promise.resolve(process.env.ORDER_EVENTS_TOPIC_ARN);
  }

  if (!topicArnPromise) {
    topicArnPromise = sns
      .send(new CreateTopicCommand({ Name: ORDER_EVENTS_TOPIC }))
      .then((out) => out.TopicArn)
      .catch((err) => {
        topicArnPromise = undefined; // allow a retry
        throw err;
      });
  }

  return topicArnPromise;
}

export async function publishOrderPlaced(order) {
  const TopicArn = await getOrderEventsTopicArn();

  const out = await sns.send(
    new PublishCommand({
      TopicArn,
      // MessageAttributes are what subscribers filter on. A subscriber that only cares
      // about cancellations can filter on eventType instead of receiving everything
      // and discarding most of it.
      Subject: "order.placed",
      MessageAttributes: {
        eventType: { DataType: "String", StringValue: "order.placed" }
      },
      Message: JSON.stringify({
        eventType: "order.placed",
        occurredAt: new Date().toISOString(),
        order
      })
    })
  );

  return out.MessageId;
}
