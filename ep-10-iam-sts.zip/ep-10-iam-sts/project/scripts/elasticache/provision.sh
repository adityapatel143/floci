#!/usr/bin/env bash
# Provisions the Redis cache node and reports the address the Lambda should use.
#
# The app treats the cache as optional, so this script is allowed to report "not
# discoverable" without failing - /products keeps working, just uncached.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws

wait_for_floci

if floci_aws elasticache describe-replication-groups --replication-group-id "$CACHE_CLUSTER_ID" >/dev/null 2>&1; then
  echo "Cache cluster ${CACHE_CLUSTER_ID} already exists."
else
  echo "Creating Redis replication group ${CACHE_CLUSTER_ID}..."
  # This Floci build rejects engine=redis on CreateCacheCluster (that path is
  # memcached-only here) - CreateReplicationGroup is the Redis/Valkey equivalent.
  if ! floci_aws elasticache create-replication-group \
    --replication-group-id "$CACHE_CLUSTER_ID" \
    --replication-group-description "FlociCart Redis cache" \
    --engine redis \
    --cache-node-type cache.t3.micro \
    --num-cache-clusters 1 >/dev/null; then
    echo
    echo "This Floci build rejected CreateReplicationGroup for engine=redis [VERIFY]."
    echo "/products will report source=db-no-cache and keep working."
    exit 0
  fi
fi

# Node endpoints appear only once the cluster is available, so poll.
echo "Waiting for a node endpoint..."
for _ in $(seq 1 30); do
  if discover_redis; then
    break
  fi
  sleep 1
done

if discover_redis; then
  save_state redis-host "$REDIS_ADDRESS"
  save_state redis-port "$REDIS_PORT"
  echo
  echo "Cache cluster ready."
  echo "REDIS_HOST=$REDIS_ADDRESS"
  echo "REDIS_PORT=$REDIS_PORT"
else
  # Not fatal on purpose - see the fallback in src/cache/redis.mjs.
  echo
  echo "Node endpoint is not discoverable in this Floci build [VERIFY]."
  echo "/products will report source=db-no-cache and keep working."
fi
