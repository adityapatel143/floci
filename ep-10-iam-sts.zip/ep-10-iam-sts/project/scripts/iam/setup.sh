#!/usr/bin/env bash
# Creates the role the Lambda runs as, with a policy scoped to exactly what it needs.
#
# Up to now the deploy scripts referenced a role ARN that was never actually created -
# fine on an emulator, useless on real AWS. This script creates it for real, and
# deploy.sh now uses it.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

wait_for_floci

# create-role fails if the role exists, so update the trust policy instead of ignoring
# the error - otherwise a changed trust policy would silently never be applied.
if floci_aws iam get-role --role-name "$APP_ROLE_NAME" >/dev/null 2>&1; then
  echo "Role ${APP_ROLE_NAME} already exists - updating its trust policy."
  floci_aws iam update-assume-role-policy \
    --role-name "$APP_ROLE_NAME" \
    --policy-document file://infra/iam/trust-policy.json >/dev/null
else
  echo "Creating role ${APP_ROLE_NAME}..."
  floci_aws iam create-role \
    --role-name "$APP_ROLE_NAME" \
    --assume-role-policy-document file://infra/iam/trust-policy.json \
    --description "FlociCart application role" >/dev/null
fi

# put-role-policy is an upsert, so the permissions file is the source of truth: edit the
# JSON, re-run this, and the role matches it.
floci_aws iam put-role-policy \
  --role-name "$APP_ROLE_NAME" \
  --policy-name "$APP_POLICY_NAME" \
  --policy-document file://infra/iam/flocicart-app-policy.json >/dev/null

ROLE_ARN=$(floci_aws iam get-role --role-name "$APP_ROLE_NAME" \
  --query 'Role.Arn' --output text)
save_state role-arn "$ROLE_ARN"

echo "Role ARN: ${ROLE_ARN}"
echo
echo "Granted (and nothing else):"
jq -r '.Statement[] | "  \(.Sid): \(.Action | if type == "array" then join(", ") else . end)\n    on \(.Resource)"' \
  infra/iam/flocicart-app-policy.json

echo
echo "Redeploy so the function runs as this role: ./scripts/lambda/deploy.sh"
echo "See temporary credentials with:            ./scripts/sts/assume-role.sh"
