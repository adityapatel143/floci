#!/usr/bin/env bash
# Creates the flocicart.local hosted zone and points app.flocicart.local at CloudFront.
#
# Route 53 has no "create or update zone" call: create-hosted-zone always creates a new
# one, so re-running naively leaves you with several zones for the same name and no way
# to tell which one is answering. Hence the lookup first.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

wait_for_floci

# Route 53 names are stored with a trailing dot; the API expects it in queries too.
ZONE_ID=$(floci_aws route53 list-hosted-zones \
  --query "HostedZones[?Name=='${DNS_ZONE}.'].Id | [0]" \
  --output text 2>/dev/null || true)

if [ -z "$ZONE_ID" ] || [ "$ZONE_ID" = "None" ]; then
  echo "Creating hosted zone ${DNS_ZONE}..."
  # CallerReference must be unique per create call, so it carries a timestamp.
  ZONE_ID=$(floci_aws route53 create-hosted-zone \
    --name "$DNS_ZONE" \
    --caller-reference "flocicart-$(date +%s)" \
    --hosted-zone-config "Comment=FlociCart local zone,PrivateZone=false" \
    --query 'HostedZone.Id' --output text)
else
  echo "Hosted zone ${DNS_ZONE} already exists."
fi

# The API returns "/hostedzone/Z123..." but every other command wants the bare id.
ZONE_ID="${ZONE_ID#/hostedzone/}"
save_state zone-id "$ZONE_ID"
echo "ZONE_ID=$ZONE_ID"

# The record has to point at something real, so read the distribution rather than asking
# the viewer to paste a domain into a JSON file by hand.
if discover_distribution; then
  TARGET="$DISTRIBUTION_DOMAIN"
  echo "Target: ${TARGET} (CloudFront)"
else
  echo "No CloudFront distribution found. Run ./scripts/cloudfront/create.sh first." >&2
  exit 1
fi

# UPSERT, not CREATE: it succeeds whether or not the record already exists, which makes
# re-running this script safe after the distribution is recreated with a new domain.
CHANGE_BATCH=$(jq \
  --arg name "${DNS_RECORD}." \
  --arg target "$TARGET" \
  '.Changes[0].ResourceRecordSet.Name = $name
   | .Changes[0].ResourceRecordSet.ResourceRecords[0].Value = $target' \
  scripts/route53/change-batch.json)

floci_aws route53 change-resource-record-sets \
  --hosted-zone-id "$ZONE_ID" \
  --change-batch "$CHANGE_BATCH" >/dev/null

echo "Record: ${DNS_RECORD} CNAME -> ${TARGET}"
echo
echo "List the zone's records with: ./scripts/route53/records.sh"
