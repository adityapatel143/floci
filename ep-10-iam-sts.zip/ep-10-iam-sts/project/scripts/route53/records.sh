#!/usr/bin/env bash
# Lists what the zone currently answers with.
#
# This is the DNS equivalent of "did it actually work?" - the record set is the only
# proof that setup-zone.sh applied the change you think it did.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

ZONE_ID="$(read_state zone-id)"
if [ -z "$ZONE_ID" ]; then
  echo "No zone id saved. Run ./scripts/route53/setup-zone.sh first." >&2
  exit 1
fi

floci_aws route53 list-resource-record-sets \
  --hosted-zone-id "$ZONE_ID" \
  --output json |
  jq -r '.ResourceRecordSets[]
         | "\(.Type)\t\(.Name)\t-> \((.ResourceRecords // []) | map(.Value) | join(", "))"' |
  column -t -s $'\t'
