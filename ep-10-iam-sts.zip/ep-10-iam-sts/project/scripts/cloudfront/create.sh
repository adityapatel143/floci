#!/usr/bin/env bash
# Creates the CloudFront distribution in front of the S3 bucket.
#
# CloudFront has no unique name, so the Comment field is our only stable handle: the
# script finds an existing distribution by comment and reuses it instead of stacking up
# a new one on every run.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

wait_for_floci

if ! floci_aws s3api head-bucket --bucket "$WEB_BUCKET" >/dev/null 2>&1; then
  echo "Bucket ${WEB_BUCKET} does not exist. Run ./scripts/s3/upload.sh first." >&2
  exit 1
fi

if discover_distribution; then
  echo "Distribution already exists: ${DISTRIBUTION_ID}"
else
  # CallerReference must be unique per request - AWS uses it to make create-distribution
  # idempotent for retries, so a fixed value fails the second time round.
  CONFIG=$(jq \
    --arg ref "flocicart-$(date +%s)" \
    --arg bucket "$WEB_BUCKET" \
    --arg comment "$DISTRIBUTION_COMMENT" \
    '.CallerReference = $ref
     | .Comment = $comment
     | .Origins.Items[0].Id = "s3-\($bucket)"
     | .Origins.Items[0].DomainName = "\($bucket).s3.amazonaws.com"
     | .DefaultCacheBehavior.TargetOriginId = "s3-\($bucket)"' \
    scripts/cloudfront/distribution-config.json)

  echo "Creating distribution..."
  floci_aws cloudfront create-distribution \
    --distribution-config "$CONFIG" \
    --output json |
    jq -r '"Created: \(.Distribution.Id)"'

  discover_distribution
fi

save_state distribution-id "$DISTRIBUTION_ID"
save_state distribution-domain "$DISTRIBUTION_DOMAIN"

echo "Distribution ID:     ${DISTRIBUTION_ID}"
echo "Distribution domain: ${DISTRIBUTION_DOMAIN}"
echo
# [VERIFY] How Floci exposes a distribution domain locally varies by version; the S3 URL
# below always works and is the reliable way to check the content itself.
echo "If the distribution domain does not resolve locally, verify the origin directly:"
echo "  curl -s ${EP}/${WEB_BUCKET}/index.html"
