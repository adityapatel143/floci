#!/usr/bin/env bash
# Creates the orders queue plus its dead-letter queue.
#
# The DLQ is not optional decoration: without it, a message the worker can never process
# is redelivered forever and blocks progress. maxReceiveCount gives up after 3 tries and
# parks the message somewhere you can inspect it.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

wait_for_floci

# create-queue is idempotent when the attributes match, so re-running is safe.
DLQ_URL=$(floci_aws sqs create-queue \
  --queue-name "$ORDERS_DLQ_NAME" \
  --query QueueUrl --output text)

DLQ_ARN=$(floci_aws sqs get-queue-attributes \
  --queue-url "$DLQ_URL" \
  --attribute-names QueueArn \
  --query 'Attributes.QueueArn' --output text)

# VisibilityTimeout is how long a received message stays hidden from other consumers.
# It must exceed the time processing takes, or the job gets handed to a second worker
# while the first is still running it.
ATTRS=$(jq -n --arg arn "$DLQ_ARN" '{
  VisibilityTimeout: "30",
  MessageRetentionPeriod: "345600",
  RedrivePolicy: ({ deadLetterTargetArn: $arn, maxReceiveCount: 3 } | tostring)
}')

QUEUE_URL=$(floci_aws sqs create-queue \
  --queue-name "$ORDERS_QUEUE_NAME" \
  --attributes "$ATTRS" \
  --query QueueUrl --output text)

save_state orders-queue-url "$QUEUE_URL"

echo "Queue:            $QUEUE_URL"
echo "Dead-letter:      $DLQ_URL"
echo "Retries before DLQ: 3"
