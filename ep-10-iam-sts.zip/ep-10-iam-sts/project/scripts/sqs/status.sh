#!/usr/bin/env bash
# Shows how much work is waiting, in flight, or gave up.
#
# ApproximateNumberOfMessages is the backlog, NotVisible is what a worker is holding right
# now, and anything in the dead-letter queue failed 3 times and needs a human.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

show() {
  local name="$1"
  local url
  url=$(floci_aws sqs get-queue-url --queue-name "$name" --query QueueUrl --output text 2>/dev/null || true)

  if [ -z "$url" ] || [ "$url" = "None" ]; then
    echo "${name}: not created"
    return
  fi

  floci_aws sqs get-queue-attributes \
    --queue-url "$url" \
    --attribute-names ApproximateNumberOfMessages ApproximateNumberOfMessagesNotVisible \
    --output json |
    jq -r --arg name "$name" \
      '"\($name): \(.Attributes.ApproximateNumberOfMessages) waiting, \(.Attributes.ApproximateNumberOfMessagesNotVisible) in flight"'
}

show "$ORDERS_QUEUE_NAME"
show "$ORDERS_DLQ_NAME"
