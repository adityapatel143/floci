// Smoke test: proves the AWS SDK v3 can reach Floci before we build anything real on it.

import { CreateBucketCommand, ListBucketsCommand } from "@aws-sdk/client-s3";
import { ListTablesCommand } from "@aws-sdk/client-dynamodb";
import { s3, ddb, endpoint, region } from "../src/config/awsClients.mjs";
import { SMOKE_BUCKET } from "../src/config/resources.mjs";

console.log(`Endpoint: ${endpoint}`);
console.log(`Region:   ${region}`);

try {
  await s3.send(new CreateBucketCommand({ Bucket: SMOKE_BUCKET }));
  console.log(`Created bucket: ${SMOKE_BUCKET}`);
} catch (err) {
  // Re-running the smoke test must stay safe, so an existing bucket is not a failure.
  if (err?.name === "BucketAlreadyOwnedByYou" || err?.name === "BucketAlreadyExists") {
    console.log(`Bucket already exists: ${SMOKE_BUCKET}`);
  } else {
    fail(err);
  }
}

try {
  const buckets = await s3.send(new ListBucketsCommand({}));
  const tables = await ddb.send(new ListTablesCommand({}));

  console.log("Buckets:", (buckets.Buckets || []).map((b) => b.Name));
  console.log("Tables:", tables.TableNames || []);
  console.log("\nFloci is reachable.");
} catch (err) {
  fail(err);
}

function fail(err) {
  // A connection refused here almost always means the container is not up yet.
  if (["ECONNREFUSED", "ENOTFOUND", "EAI_AGAIN"].includes(err?.cause?.code || err?.code)) {
    console.error(`\nCannot reach Floci at ${endpoint}.`);
    console.error("Start it with `npm run floci:up`, then check `npm run floci:logs`.");
  } else {
    console.error("\nSmoke test failed:", err?.name || "Error", "-", err?.message);
  }
  process.exit(1);
}
