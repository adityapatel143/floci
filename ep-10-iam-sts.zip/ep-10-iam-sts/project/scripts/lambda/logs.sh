#!/usr/bin/env bash
# Tails the CloudWatch Logs group that Floci creates for the function.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws

GROUP="/aws/lambda/${FUNCTION_NAME}"

# The log group only exists after the first invocation, so say so rather than failing.
if ! floci_aws logs describe-log-groups \
  --log-group-name-prefix "$GROUP" \
  --query 'logGroups[0].logGroupName' \
  --output text 2>/dev/null | grep -q "$GROUP"; then
  echo "No logs yet for ${FUNCTION_NAME}. Invoke it first: ./scripts/lambda/invoke.sh" >&2
  exit 0
fi

echo "Tailing ${GROUP} (Ctrl+C to stop)..."
floci_aws logs tail "$GROUP" --follow
