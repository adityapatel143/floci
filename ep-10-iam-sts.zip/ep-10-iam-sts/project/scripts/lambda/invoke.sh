#!/usr/bin/env bash
# Invokes the Lambda directly, bypassing API Gateway.
#
# Optional first argument is the JSON payload, e.g. ./scripts/lambda/invoke.sh '{"a":1}'
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

PAYLOAD="${1:-{\}}"

# mktemp avoids a predictable, world-writable path in /tmp that another user could
# pre-create or symlink; the trap removes it even if the invoke fails.
OUT="$(mktemp -t flocicart-invoke.XXXXXX.json)"
trap 'rm -f "$OUT"' EXIT

RESULT="$(floci_aws lambda invoke \
  --function-name "$FUNCTION_NAME" \
  --payload "$PAYLOAD" \
  --cli-binary-format raw-in-base64-out \
  --output json \
  "$OUT")"

echo "Status: $(jq -r '.StatusCode' <<<"$RESULT")"

# A Lambda that throws still returns HTTP 200; FunctionError is the only signal that the
# handler failed.
if jq -e 'has("FunctionError")' >/dev/null <<<"$RESULT"; then
  echo "Function error: $(jq -r '.FunctionError' <<<"$RESULT")" >&2
  jq '.' "$OUT" >&2
  exit 1
fi

echo "Response:"
jq '.' "$OUT"

echo
echo "Decoded body:"
jq -r '.body' "$OUT" | jq '.'
