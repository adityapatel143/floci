#!/usr/bin/env bash
# Creates the order-events topic and subscribes two independent queues to it.
#
# Two subscribers, not one, because that is the whole point of SNS: the publisher sends a
# single message and every subscriber gets its own copy. Swap either queue for an email
# or webhook subscription and the publishing code does not change.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

wait_for_floci

# create-topic is idempotent: it returns the existing ARN for a name already in use.
TOPIC_ARN=$(floci_aws sns create-topic --name "$ORDER_EVENTS_TOPIC" \
  --query TopicArn --output text)
echo "Topic: $TOPIC_ARN"
save_state topic-arn "$TOPIC_ARN"

subscribe_queue() {
  local queue_name="$1"

  local queue_url queue_arn
  queue_url=$(floci_aws sqs create-queue --queue-name "$queue_name" \
    --query QueueUrl --output text)
  queue_arn=$(floci_aws sqs get-queue-attributes --queue-url "$queue_url" \
    --attribute-names QueueArn --query 'Attributes.QueueArn' --output text)

  # Skip if this queue is already subscribed, otherwise re-running the script would
  # attach a second subscription and every event would be delivered twice.
  local existing
  existing=$(floci_aws sns list-subscriptions-by-topic --topic-arn "$TOPIC_ARN" \
    --query "Subscriptions[?Endpoint=='${queue_arn}'].SubscriptionArn" \
    --output text 2>/dev/null || true)

  if [ -n "$existing" ] && [ "$existing" != "None" ]; then
    echo "  ${queue_name}: already subscribed"
  else
    floci_aws sns subscribe \
      --topic-arn "$TOPIC_ARN" \
      --protocol sqs \
      --notification-endpoint "$queue_arn" \
      --attributes RawMessageDelivery=false >/dev/null
    echo "  ${queue_name}: subscribed"
  fi

  save_state "queue-url-${queue_name}" "$queue_url"
}

echo "Subscribers:"
subscribe_queue "$NOTIFICATIONS_QUEUE_NAME"
subscribe_queue "$ANALYTICS_QUEUE_NAME"

echo
echo "Run ./scripts/lambda/deploy.sh so the function knows the topic name."
echo "Then watch both queues with: ./scripts/sns/watch-events.sh"
