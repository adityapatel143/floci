#!/usr/bin/env bash
# Drains both subscriber queues once and prints what each received.
#
# Run it after placing an order: the same event should appear in both, which is the
# fan-out actually happening rather than being described.
set -euo pipefail

cd "$(dirname "$0")/../.."
source scripts/lib/floci.sh

require_cmd aws jq

drain() {
  local queue_name="$1"
  local url
  url=$(floci_aws sqs get-queue-url --queue-name "$queue_name" --query QueueUrl --output text 2>/dev/null || true)

  echo "--- ${queue_name}"
  if [ -z "$url" ] || [ "$url" = "None" ]; then
    echo "not created - run ./scripts/sns/setup.sh"
    return
  fi

  local messages
  messages=$(floci_aws sqs receive-message \
    --queue-url "$url" \
    --max-number-of-messages 10 \
    --wait-time-seconds 5 \
    --output json 2>/dev/null || echo '{}')

  if ! jq -e '.Messages' >/dev/null <<<"$messages"; then
    echo "(no messages)"
    return
  fi

  # SNS wraps the published payload in its own envelope, so .Body is JSON containing a
  # .Message string that is itself JSON. Hence the double parse.
  jq -r '.Messages[] | (.Body | fromjson | .Message | fromjson)' <<<"$messages"

  # Delete what we read so a second run shows only new events.
  jq -r '.Messages[].ReceiptHandle' <<<"$messages" | while read -r handle; do
    floci_aws sqs delete-message --queue-url "$url" --receipt-handle "$handle"
  done
}

drain "$NOTIFICATIONS_QUEUE_NAME"
echo
drain "$ANALYTICS_QUEUE_NAME"
