// The storefront. It is a plain static file - no build step, no framework - because the
// point of the episode is where it is served from, not what it is written in.
//
// FLOCICART_API_BASE comes from config.js, which upload.sh generates with the real API
// URL. The API id changes whenever the API is recreated, so it cannot be hardcoded here.

const out = document.getElementById("out");
const apiBase = window.FLOCICART_API_BASE;

async function main() {
  if (!apiBase) {
    out.textContent =
      "No API base configured.\nRun scripts/apigw/create-http-api.sh, then scripts/s3/upload.sh.";
    return;
  }

  try {
    const res = await fetch(`${apiBase}/products`);
    if (!res.ok) {
      out.textContent = `API returned ${res.status} ${res.statusText}`;
      return;
    }
    out.textContent = JSON.stringify(await res.json(), null, 2);
  } catch (err) {
    // A fetch that rejects rather than returning a status is almost always CORS or a
    // dead endpoint, so say that instead of printing a bare "TypeError".
    out.textContent = `Request failed: ${err.message}\nCheck that the API is running and allows this origin.`;
  }
}

main();
