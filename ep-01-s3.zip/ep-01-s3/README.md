# Ep 01 - Floci Setup and Node.js Scaffold

Difficulty: beginner · Git tag: `ep-01-setup-scaffold`

## Where we left off

Episode 00 only covered the architecture and the roadmap - no code yet.

## What this episode adds

- A local Floci runtime on `http://localhost:4566`, started with Docker Compose
- A Node.js ESM project with AWS SDK v3 clients pointed at that single endpoint
- A smoke test that proves two different AWS services answer on that one port
- A cleanup script so you can reset without restarting the emulator

## Prerequisites

- Docker with Compose v2 (`docker compose version`)
- Node.js 20 or newer (`node --version`)

## Files in this episode

| Path | Purpose |
| --- | --- |
| `project/compose.yaml` | Runs the Floci container on port 4566 |
| `project/.env.example` | The four env vars that point the SDK at Floci |
| `project/src/config/awsClients.mjs` | Shared, pre-configured AWS SDK v3 clients |
| `project/src/config/resources.mjs` | Resource names shared by the scripts |
| `project/scripts/smoke-sdk.mjs` | Connectivity check against S3 + DynamoDB |
| `project/scripts/cleanup.mjs` | Deletes the resources this episode created |

## Run instructions

1. Open a terminal in this episode's project.

```bash
cd project
```

2. Start Floci.

```bash
npm run floci:up
```

3. Export the local AWS variables (or `cp .env.example .env && source .env`).

```bash
export AWS_ENDPOINT_URL=http://localhost:4566
export AWS_DEFAULT_REGION=us-east-1
export AWS_ACCESS_KEY_ID=test
export AWS_SECRET_ACCESS_KEY=test
```

4. Install dependencies and run the smoke test.

```bash
npm install
npm run smoke:sdk
```

Expected output:

```text
Endpoint: http://localhost:4566
Region:   us-east-1
Created bucket: flocicart-ep01-smoke
Buckets: [ 'flocicart-ep01-smoke' ]
Tables: []

Floci is reachable. Run `npm run cleanup` to remove the smoke bucket.
```

The empty table list is expected - DynamoDB answered, it just has no tables yet.

## Cleanup

```bash
# Remove the resources created above, keep Floci running
npm run cleanup

# Stop the emulator entirely
npm run floci:down
```

## Common errors

| Error | Fix |
| --- | --- |
| `Cannot reach Floci at http://localhost:4566` | The container is not up or still booting. Run `npm run floci:up`, then watch `npm run floci:logs`. |
| `bind: address already in use` | Something else owns port 4566. Stop it, or change the host side of the port mapping in `compose.yaml`. |
| `permission denied ... /var/run/docker.sock` | Your user cannot reach the Docker socket. Add yourself to the `docker` group and log back in. |

## What is next

Episode 02 packages our first Node.js Lambda, deploys it to Floci, invokes it, and reads its logs.
