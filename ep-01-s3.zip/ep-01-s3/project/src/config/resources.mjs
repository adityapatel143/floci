// Names of the AWS resources this episode creates.
// Shared so the smoke test and the cleanup script can never drift apart.

export const SMOKE_BUCKET = process.env.SMOKE_BUCKET || "flocicart-ep01-smoke";
