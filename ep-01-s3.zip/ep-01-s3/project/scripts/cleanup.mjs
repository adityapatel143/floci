// Removes everything this episode created inside Floci, without stopping the container.
//
// Use this when you want to re-record or re-run the episode from a clean slate but keep
// the emulator running. To wipe absolutely everything instead, run `npm run floci:down`.

import {
  DeleteBucketCommand,
  DeleteObjectsCommand,
  ListObjectsV2Command
} from "@aws-sdk/client-s3";
import { s3, endpoint } from "../src/config/awsClients.mjs";
import { SMOKE_BUCKET } from "../src/config/resources.mjs";

console.log(`Cleaning up on ${endpoint}`);

try {
  // S3 refuses to delete a non-empty bucket, so drain it first. Listing is paginated,
  // hence the loop rather than a single call.
  let continuationToken;
  do {
    const listed = await s3.send(
      new ListObjectsV2Command({ Bucket: SMOKE_BUCKET, ContinuationToken: continuationToken })
    );
    const objects = (listed.Contents || []).map((o) => ({ Key: o.Key }));

    if (objects.length > 0) {
      await s3.send(
        new DeleteObjectsCommand({ Bucket: SMOKE_BUCKET, Delete: { Objects: objects } })
      );
      console.log(`Deleted ${objects.length} object(s) from ${SMOKE_BUCKET}`);
    }

    continuationToken = listed.IsTruncated ? listed.NextContinuationToken : undefined;
  } while (continuationToken);

  await s3.send(new DeleteBucketCommand({ Bucket: SMOKE_BUCKET }));
  console.log(`Deleted bucket: ${SMOKE_BUCKET}`);
} catch (err) {
  // Cleanup must be idempotent: nothing to delete is a success, not an error.
  if (err?.name === "NoSuchBucket") {
    console.log(`Bucket already gone: ${SMOKE_BUCKET}`);
  } else if (["ECONNREFUSED", "ENOTFOUND"].includes(err?.cause?.code || err?.code)) {
    console.log("Floci is not running, so there is nothing to clean up.");
  } else {
    console.error("Cleanup failed:", err?.name || "Error", "-", err?.message);
    process.exit(1);
  }
}

console.log("Cleanup complete.");
